/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

/**
 *
 * @author ayele
 */
public class SesionVenta {

    private static double cambioVenta;
     private static int ultimoIdVenta = -1;
    private static double ultimoCambio = 0;

    public static void setCambioVenta(double cambio) {
        cambioVenta = cambio;
    }

    public static double getCambioVenta() {
        return cambioVenta;
    }


    public static void setUltimoIdVenta(int id) {
        ultimoIdVenta = id;
    }

    public static int getUltimoIdVenta() {
        return ultimoIdVenta;
    }

    public static void setUltimoCambio(double c) {
        ultimoCambio = c;
    }

    public static double getUltimoCambio() {
        return ultimoCambio;
    }
}

