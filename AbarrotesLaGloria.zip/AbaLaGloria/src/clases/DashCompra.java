/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

/**
 *
 * @author ayele
 */
import paquete.Conexion;
import javax.swing.*;
import java.awt.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.jfree.chart.*;
import org.jfree.chart.plot.*;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.chart.renderer.category.BarRenderer;

public class DashCompra extends JPanel {

    // PALETA DE COLORES
    private final Color C_VERDE = Color.decode("#6E8F85");
    private final Color C_VERDE_PASTEL = Color.decode("#E4FFD4");
    private final Color C_AMARILLO = Color.decode("#EBE7A7");
    private final Color C_NARANJA = Color.decode("#EDC68E");
    private final Color C_BEIGE = Color.decode("#A49E7E");

    public JPanel panelComprasResumen;
    public JPanel panelComprasTop;

    public DashCompra() {
        setLayout(new GridLayout(1, 2, 10, 10));
        setBackground(new Color(0,0,0,0));

        panelComprasResumen = crearPanelComprasResumen();
        panelComprasTop = crearPanelComprasTop();

        add(panelComprasResumen);
        add(panelComprasTop);
    }

    // PANEL 1: RESUMEN DE COMPRAS
    private JPanel crearPanelComprasResumen() {
        JPanel p = new JPanel(new BorderLayout());
        p.setPreferredSize(new Dimension(410, 550));
        p.setBackground(C_VERDE_PASTEL);
        p.setBorder(BorderFactory.createLineBorder(C_VERDE, 3, true));

        JPanel info = new JPanel(new GridLayout(5, 1, 8, 8));
        info.setBackground(new Color(0,0,0,0));

        info.add(crearTarjeta("Compras del mes", obtenerTotalComprasMes()));
        info.add(crearTarjeta("Compra más alta", obtenerCompraMasAlta()));
        info.add(crearTarjeta("Proveedores activos", obtenerTotalProveedores()));
        info.add(crearTarjeta("Compras del día", obtenerComprasHoy()));
        info.add(crearTarjeta("Promedio compra", obtenerPromedioCompra()));

        p.add(info, BorderLayout.NORTH);
        p.add(crearGraficaComprasMensuales(), BorderLayout.CENTER);

        return p;
    }

    // PANEL 2: TOP PROVEEDORES / PRODUCTOS
    private JPanel crearPanelComprasTop() {
        JPanel p = new JPanel(new BorderLayout());
        p.setPreferredSize(new Dimension(410, 550));
        p.setBackground(C_AMARILLO);
        p.setBorder(BorderFactory.createLineBorder(C_BEIGE, 3, true));

        JPanel info = new JPanel(new GridLayout(5, 1, 8, 8));
        info.setBackground(new Color(0,0,0,0));

        info.add(crearTarjeta("Proveedor top", obtenerProveedorTop()));
        info.add(crearTarjeta("Producto más comprado", obtenerProductoMasComprado()));
        info.add(crearTarjeta("Categoría más comprada", obtenerCategoriaMasComprada()));
        info.add(crearTarjeta("Método pago más usado", obtenerMetodoPagoCompras()));
        info.add(crearTarjeta("Total compras", obtenerCantidadCompras()));

        p.add(info, BorderLayout.NORTH);
        p.add(crearGraficaCategoriasCompras(), BorderLayout.CENTER);

        return p;
    }

    // -----------------------------
    // TARJETAS
    // -----------------------------
    private JPanel crearTarjeta(String titulo, String valor) {
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(C_NARANJA);
        card.setBorder(BorderFactory.createLineBorder(C_VERDE, 2, true));

        JLabel lt = new JLabel(titulo, SwingConstants.CENTER);
        lt.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lt.setForeground(C_VERDE);

        JLabel lv = new JLabel(valor, SwingConstants.CENTER);
        lv.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lv.setForeground(C_VERDE);

        card.add(lt, BorderLayout.NORTH);
        card.add(lv, BorderLayout.CENTER);

        return card;
    }

    // -----------------------------
    // CONSULTAS SQL
    // -----------------------------
    private String consultaSimple(String sql, String col) {
        try {
            ResultSet rs = Conexion.ejecutarConsulta(sql);
            if (rs != null && rs.next()) return rs.getString(col);
        } catch (SQLException e) {
            System.out.println("Error consulta: " + e.getMessage());
        }
        return "N/A";
    }

    private String obtenerTotalComprasMes() {
        return consultaSimple("SELECT SUM(total) AS t FROM compra WHERE MONTH(fecha)=MONTH(NOW())", "t");
    }
    private String obtenerCompraMasAlta() {
        return consultaSimple("SELECT MAX(total) AS t FROM compra", "t");
    }
    private String obtenerComprasHoy() {
        return consultaSimple("SELECT COUNT(*) AS t FROM compra WHERE DATE(fecha)=CURDATE()", "t");
    }
    private String obtenerPromedioCompra() {
        return consultaSimple("SELECT AVG(total) AS t FROM compra", "t");
    }
    private String obtenerTotalProveedores() {
        return consultaSimple("SELECT COUNT(*) AS t FROM proveedor WHERE estatus=1", "t");
    }
    private String obtenerProveedorTop() {
        String sql = """
            SELECT p.nombre_comercial, COUNT(*) AS total
            FROM detalle_compra dc
            INNER JOIN compra c ON c.id_compra = dc.id_compra
            INNER JOIN proveedor p ON p.id_proveedor = c.id_proveedor
            GROUP BY p.id_proveedor
            ORDER BY total DESC
            LIMIT 1
        """;
        return consultaSimple(sql, "nombre_comercial");
    }
    private String obtenerProductoMasComprado() {
        String sql = """
            SELECT p.nombre, SUM(dc.cantidad) AS total
            FROM detalle_compra dc
            INNER JOIN producto p ON p.id_producto = dc.id_producto
            GROUP BY p.id_producto
            ORDER BY total DESC LIMIT 1
        """;
        return consultaSimple(sql, "nombre");
    }
    private String obtenerCategoriaMasComprada() {
        String sql = """
            SELECT tp.nombre_tipo, SUM(dc.cantidad) AS total
            FROM detalle_compra dc
            INNER JOIN producto p ON p.id_producto = dc.id_producto
            INNER JOIN tipo_producto tp ON tp.id_tipo_producto = p.id_tipo_producto
            GROUP BY tp.id_tipo_producto
            ORDER BY total DESC LIMIT 1
        """;
        return consultaSimple(sql, "nombre_tipo");
    }
    private String obtenerMetodoPagoCompras() {
        String sql = """
            SELECT mp.nombre_metodo, COUNT(*) AS total
            FROM compra c
            INNER JOIN metodo_pago mp ON mp.id_metodo_pago = c.id_metodo_pago
            GROUP BY mp.id_metodo_pago
            ORDER BY total DESC LIMIT 1
        """;
        return consultaSimple(sql, "nombre_metodo");
    }
    private String obtenerCantidadCompras() {
        return consultaSimple("SELECT COUNT(*) AS t FROM compra", "t");
    }

    // -----------------------------
    // GRAFICA BARRAS: Compras mensuales
    // -----------------------------
    private JPanel crearGraficaComprasMensuales() {
        DefaultCategoryDataset data = new DefaultCategoryDataset();

        try {
            ResultSet rs = Conexion.ejecutarConsulta("""
                SELECT MONTH(fecha) AS mes, SUM(total) AS total
                FROM compra
                GROUP BY MONTH(fecha)
            """);
            while (rs != null && rs.next()) {
                data.addValue(rs.getDouble("total"), "Compras", "Mes " + rs.getInt("mes"));
            }
        } catch (Exception e) {
            System.out.println("Error grafica compras mensuales: " + e.getMessage());
        }

        JFreeChart chart = ChartFactory.createBarChart(
            "Compras Mensuales", "Mes", "Total", data,
            PlotOrientation.VERTICAL, false, true, false
        );

        chart.setBackgroundPaint(C_AMARILLO);
        CategoryPlot plot = chart.getCategoryPlot();
        plot.setBackgroundPaint(C_VERDE_PASTEL);
        plot.setDomainGridlinePaint(C_VERDE);
        plot.setRangeGridlinePaint(C_VERDE);

        BarRenderer renderer = (BarRenderer) plot.getRenderer();
        renderer.setSeriesPaint(0, C_NARANJA);

        return new ChartPanel(chart);
    }

    // -----------------------------
    // GRAFICA PIE: Categorías compradas
    // -----------------------------
    private JPanel crearGraficaCategoriasCompras() {
        DefaultPieDataset data = new DefaultPieDataset();
        try {
            ResultSet rs = Conexion.ejecutarConsulta("""
                SELECT tp.nombre_tipo AS nombre, SUM(dc.cantidad) AS total
                FROM detalle_compra dc
                INNER JOIN producto p ON p.id_producto = dc.id_producto
                INNER JOIN tipo_producto tp ON tp.id_tipo_producto = p.id_tipo_producto
                GROUP BY tp.id_tipo_producto
            """);
            while (rs != null && rs.next()) {
                data.setValue(rs.getString("nombre"), rs.getInt("total"));
            }
        } catch (Exception e) {
            System.out.println("Error grafica categorias compras: " + e.getMessage());
        }

        JFreeChart chart = ChartFactory.createPieChart(
            "Categorías Compradas",
            data,
            true,
            true,
            false
        );

        PiePlot plot = (PiePlot) chart.getPlot();

        // COLORES PERSONALIZADOS
        Color[] colores = {C_VERDE_PASTEL, C_AMARILLO, C_NARANJA, C_BEIGE, C_VERDE};
        int i = 0;
        for (Object key : data.getKeys()) {
            plot.setSectionPaint((Comparable) key, colores[i % colores.length]);
            i++;
        }

        // Mostrar porcentaje
        plot.setLabelGenerator(new org.jfree.chart.labels.StandardPieSectionLabelGenerator(
            "{0}: {1} ({2})"
        ));

        plot.setBackgroundPaint(Color.WHITE);
        plot.setOutlinePaint(C_VERDE);
        plot.setLabelBackgroundPaint(Color.WHITE);
        plot.setLabelOutlinePaint(C_VERDE);
        plot.setLabelShadowPaint(null);

        ChartPanel cp = new ChartPanel(chart);
        cp.setPreferredSize(new Dimension(400, 250));
        return cp;
    }
}

