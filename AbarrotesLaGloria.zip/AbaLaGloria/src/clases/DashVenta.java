/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

/**
 *
 * @author ayele
 */
import paquete.Conexion;
import java.sql.ResultSet;
import javax.swing.*;
import java.awt.*;
import org.jfree.chart.*;
import org.jfree.chart.plot.*;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.jfree.chart.renderer.category.BarRenderer;

public class DashVenta extends JPanel {

    // PALETA DE COLORES
    private final Color C_VERDE = Color.decode("#6E8F85");
    private final Color C_VERDE_PASTEL = Color.decode("#E4FFD4");
    private final Color C_AMARILLO = Color.decode("#EBE7A7");
    private final Color C_NARANJA = Color.decode("#EDC68E");
    private final Color C_BEIGE = Color.decode("#A49E7E");

    public JPanel panelVentasResumen;
    public JPanel panelVentasTop;

    public DashVenta() {
        setLayout(new GridLayout(1, 2, 10, 10));
        setBackground(new Color(0,0,0,0));

        panelVentasResumen = crearPanelVentasResumen();
        panelVentasTop = crearPanelVentasTop();

        add(panelVentasResumen);
        add(panelVentasTop);
    }

    // ---------------------------------------------------------
    // PANEL 1: RESUMEN DE VENTAS
    // ---------------------------------------------------------
    private JPanel crearPanelVentasResumen() {
        JPanel p = new JPanel();
        p.setPreferredSize(new Dimension(410, 550));
        p.setLayout(new BorderLayout());
        p.setBackground(C_VERDE_PASTEL);
        p.setBorder(BorderFactory.createLineBorder(C_VERDE, 3, true));

        JPanel info = new JPanel();
        info.setLayout(new GridLayout(5, 1, 8, 8));
        info.setBackground(new Color(0,0,0,0));

        info.add(crearTarjeta("Ventas del mes", obtenerTotalVentasMes()));
        info.add(crearTarjeta("Venta más alta", obtenerVentaMasAlta()));
        info.add(crearTarjeta("Producto más vendido", obtenerProductoMasVendido()));
        info.add(crearTarjeta("Ticket Promedio", obtenerTicketPromedio()));
        info.add(crearTarjeta("Ventas del día", obtenerVentasHoy()));

        p.add(info, BorderLayout.NORTH);
        p.add(crearGraficaVentasMensuales(), BorderLayout.CENTER);

        return p;
    }

    // ---------------------------------------------------------
    // PANEL 2: TOP VENTAS
    // ---------------------------------------------------------
    private JPanel crearPanelVentasTop() {
        JPanel p = new JPanel();
        p.setPreferredSize(new Dimension(410, 550));
        p.setLayout(new BorderLayout());
        p.setBackground(C_AMARILLO);
        p.setBorder(BorderFactory.createLineBorder(C_BEIGE, 3, true));

        JPanel info = new JPanel();
        info.setLayout(new GridLayout(5, 1, 8, 8));
        info.setBackground(new Color(0,0,0,0));

        info.add(crearTarjeta("Cliente frecuente", obtenerClienteFrecuente()));
        info.add(crearTarjeta("Producto más rentable", obtenerProductoMasRentable()));
        info.add(crearTarjeta("Categoría más vendida", obtenerCategoriaMasVendida()));
        info.add(crearTarjeta("Método pago más usado", obtenerMetodoPago()));
        info.add(crearTarjeta("Total ventas", obtenerCantidadVentas()));

        p.add(info, BorderLayout.NORTH);
        p.add(crearGraficaCategorias(), BorderLayout.CENTER);

        return p;
    }

    // ---------------------------------------------------------
    // TARJETAS BONITAS
    // ---------------------------------------------------------
    private JPanel crearTarjeta(String titulo, String valor) {
        JPanel card = new JPanel();
        card.setLayout(new BorderLayout());
        card.setBackground(C_NARANJA);
        card.setBorder(BorderFactory.createLineBorder(C_VERDE, 2, true));

        JLabel lt = new JLabel(titulo);
        lt.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lt.setHorizontalAlignment(SwingConstants.CENTER);
        lt.setForeground(C_VERDE);

        JLabel lv = new JLabel(valor);
        lv.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lv.setHorizontalAlignment(SwingConstants.CENTER);
        lv.setForeground(C_VERDE);

        card.add(lt, BorderLayout.NORTH);
        card.add(lv, BorderLayout.CENTER);

        return card;
    }


    // ---------------------------------------------------------
    // CONSULTAS SQL
    // ---------------------------------------------------------
    private String consultaSimple(String sql, String col) {
        try {
            ResultSet rs = Conexion.ejecutarConsulta(sql);
            if (rs != null && rs.next()) return rs.getString(col);
        } catch (SQLException e) {
            System.out.println("Error consulta: " + e.getMessage());
        }
        return "N/A";
    }

    private String obtenerTotalVentasMes() {
        return consultaSimple("SELECT SUM(total) AS t FROM venta WHERE MONTH(fecha)=MONTH(NOW())", "t");
    }
    private String obtenerVentaMasAlta() {
        return consultaSimple("SELECT MAX(total) AS t FROM venta", "t");
    }
    private String obtenerVentasHoy() {
        return consultaSimple("SELECT COUNT(*) AS t FROM venta WHERE DATE(fecha)=CURDATE()", "t");
    }
    private String obtenerTicketPromedio() {
        return consultaSimple("SELECT AVG(total) AS t FROM venta", "t");
    }
    private String obtenerProductoMasVendido() {
        return consultaSimple("""
            SELECT p.nombre, SUM(dv.cantidad) AS total
            FROM detalle_venta dv
            INNER JOIN producto p ON p.id_producto = dv.id_producto
            GROUP BY p.id_producto ORDER BY total DESC LIMIT 1
        """, "nombre");
    }
    private String obtenerClienteFrecuente() {
        return consultaSimple("""
            SELECT c.nombre, COUNT(*) AS total
            FROM venta v
            INNER JOIN cliente c ON c.id_cliente = v.id_cliente
            GROUP BY c.id_cliente ORDER BY total DESC LIMIT 1
        """, "nombre");
    }
    private String obtenerProductoMasRentable() {
        return consultaSimple("""
            SELECT p.nombre, SUM(dv.subtotal) AS total
            FROM detalle_venta dv
            INNER JOIN producto p ON p.id_producto = dv.id_producto
            GROUP BY p.id_producto ORDER BY total DESC LIMIT 1
        """, "nombre");
    }

    private String obtenerCategoriaMasVendida() {
        return consultaSimple("""
            SELECT tp.nombre_tipo, SUM(dv.cantidad) AS total
            FROM detalle_venta dv
            INNER JOIN producto p ON p.id_producto = dv.id_producto
            INNER JOIN tipo_producto tp ON tp.id_tipo_producto = p.id_tipo_producto
            GROUP BY tp.id_tipo_producto ORDER BY total DESC LIMIT 1
        """, "nombre_tipo");
    }

    private String obtenerMetodoPago() {
        return consultaSimple("""
            SELECT mp.nombre_metodo, COUNT(*) AS total
            FROM venta v
            INNER JOIN metodo_pago mp ON mp.id_metodo_pago = v.id_metodo_pago
            GROUP BY mp.id_metodo_pago ORDER BY total DESC LIMIT 1 
        """, "nombre_metodo");
    }

    private String obtenerCantidadVentas() {
        return consultaSimple("SELECT COUNT(*) AS t FROM venta", "t");
    }

    // ---------------------------------------------------------
    // GRÁFICA DE BARRAS
    // ---------------------------------------------------------
    private JPanel crearGraficaVentasMensuales() {
        DefaultCategoryDataset data = new DefaultCategoryDataset();

        try {
            ResultSet rs = Conexion.ejecutarConsulta("""
                SELECT MONTH(fecha) AS mes, SUM(total) AS total
                FROM venta GROUP BY MONTH(fecha)
            """);

            while (rs != null && rs.next()) {
                data.addValue(rs.getDouble("total"), "Ventas", "Mes " + rs.getInt("mes"));
            }

        } catch (Exception e) {
            System.out.println("Error grafica mensual: " + e.getMessage());
        }

        JFreeChart chart = ChartFactory.createBarChart(
                "Ventas Mensuales", "Mes", "Total", data,
                PlotOrientation.VERTICAL, false, true, false);

        chart.setBackgroundPaint(C_AMARILLO);

        CategoryPlot plot = chart.getCategoryPlot();
        plot.setBackgroundPaint(C_VERDE_PASTEL);
        plot.setDomainGridlinePaint(C_VERDE);
        plot.setRangeGridlinePaint(C_VERDE);

        BarRenderer renderer = (BarRenderer) plot.getRenderer();
        renderer.setSeriesPaint(0, C_NARANJA);

        return new ChartPanel(chart);
    }

    // ---------------------------------------------------------
    // GRÁFICA PIE
    // ---------------------------------------------------------
   private JPanel crearGraficaCategorias() {
    DefaultPieDataset data = new DefaultPieDataset();

    try {
        ResultSet rs = Conexion.ejecutarConsulta("""
            SELECT tp.nombre_tipo AS nombre, SUM(dv.cantidad) AS total
            FROM detalle_venta dv
            INNER JOIN producto p ON p.id_producto = dv.id_producto
            INNER JOIN tipo_producto tp ON tp.id_tipo_producto = p.id_tipo_producto
            GROUP BY tp.id_tipo_producto
        """);

        while (rs != null && rs.next()) {
            data.setValue(rs.getString("nombre"), rs.getInt("total"));
        }

    } catch (Exception e) {
        System.out.println("Error grafica categorias: " + e.getMessage());
    }

    JFreeChart chart = ChartFactory.createPieChart(
            "Categorías Más Vendidas",
            data,
            true,
            true,
            false
    );

    PiePlot plot = (PiePlot) chart.getPlot();

    // Colores de tu paleta
    Color c1 = Color.decode("#E4FFD4"); // verde suave
    Color c2 = Color.decode("#EBE7A7"); // amarillo pastel
    Color c3 = Color.decode("#EDC68E"); // durazno
    Color c4 = Color.decode("#A49E7E"); // café claro
    Color c5 = Color.decode("#6E8F85"); // verde oscuro

    int i = 0;
    for (Object key : data.getKeys()) {
        Color color = switch (i % 5) {
            case 0 -> c1;
            case 1 -> c2;
            case 2 -> c3;
            case 3 -> c4;
            default -> c5;
        };
        plot.setSectionPaint((Comparable) key, color);
        i++;
    }

    // Mostrar porcentaje
    plot.setLabelGenerator(new org.jfree.chart.labels.StandardPieSectionLabelGenerator(
        "{0}: {1} ({2})")); // {0}=nombre, {1}=valor, {2}=porcentaje

    plot.setBackgroundPaint(Color.WHITE);
    plot.setOutlinePaint(c5);
    plot.setLabelBackgroundPaint(Color.WHITE);
    plot.setLabelOutlinePaint(c5);
    plot.setLabelShadowPaint(null);

    ChartPanel cp = new ChartPanel(chart);
    cp.setPreferredSize(new Dimension(400, 250));

    return cp;
}

}
