/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

/**
 *
 * @author ayele
 */
import paquete.Conexion;
import java.awt.*;
import javax.swing.*;
import java.sql.*;
import org.jfree.chart.*;
import org.jfree.chart.labels.StandardPieSectionLabelGenerator;
import org.jfree.chart.plot.PiePlot;
import org.jfree.data.general.DefaultPieDataset;

public class DashClientesProveedores extends JPanel {

    private JLabel lblTotalClientes, lblClienteFrecuente;
    private JLabel lblTotalProveedores, lblProveedorTop;

    public DashClientesProveedores() {
        setLayout(new GridLayout(1, 2, 10, 10)); // Dos paneles lado a lado
        setBackground(Color.WHITE);

        // Panel clientes
        JPanel panelCliente = crearPanelCliente();
        // Panel proveedores
        JPanel panelProveedor = crearPanelProveedor();

        add(panelCliente);
        add(panelProveedor);
    }

    private JPanel crearPanelCliente() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setPreferredSize(new Dimension(410, 550));
        panel.setBackground(Color.decode("#EBE7A7"));

        // Tarjetas
        JPanel tarjetas = new JPanel(new GridLayout(2, 1, 10, 10));
        tarjetas.setBackground(Color.decode("#E4FFD4"));

        lblTotalClientes = crearCard("Total Clientes", "#EBE7A7");
        lblClienteFrecuente = crearCard("Cliente Frecuente", "#EDC68E");

        tarjetas.add(lblTotalClientes);
        tarjetas.add(lblClienteFrecuente);

        // Gráfica
        JPanel grafica = crearGraficaPieClientes();

        panel.add(tarjetas, BorderLayout.NORTH);
        panel.add(grafica, BorderLayout.CENTER);

        cargarDatosClientes();

        return panel;
    }

    private JPanel crearPanelProveedor() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setPreferredSize(new Dimension(410, 550));
        panel.setBackground(Color.decode("#EBE7A7"));

        // Tarjetas
        JPanel tarjetas = new JPanel(new GridLayout(2, 1, 10, 10));
        tarjetas.setBackground(Color.decode("#E4FFD4"));

        lblTotalProveedores = crearCard("Total Proveedores", "#EBE7A7");
        lblProveedorTop = crearCard("Proveedor Top", "#EDC68E");

        tarjetas.add(lblTotalProveedores);
        tarjetas.add(lblProveedorTop);

        // Gráfica
        JPanel grafica = crearGraficaPieProveedores();

        panel.add(tarjetas, BorderLayout.NORTH);
        panel.add(grafica, BorderLayout.CENTER);

        cargarDatosProveedores();

        return panel;
    }

    private JLabel crearCard(String titulo, String colorHex) {
        JPanel card = new JPanel();
        card.setBackground(Color.decode(colorHex));
        card.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        card.setLayout(new BorderLayout());

        JLabel lblTitulo = new JLabel(titulo, SwingConstants.CENTER);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 16));
        lblTitulo.setForeground(Color.BLACK);

        JLabel lblValor = new JLabel("...", SwingConstants.CENTER);
        lblValor.setFont(new Font("Arial", Font.BOLD, 24));
        lblValor.setForeground(Color.BLACK);

        card.add(lblTitulo, BorderLayout.NORTH);
        card.add(lblValor, BorderLayout.CENTER);

        return lblValor;
    }

    private JPanel crearGraficaPieClientes() {
    DefaultPieDataset dataset = new DefaultPieDataset();

    try {
        ResultSet rsClientes = Conexion.ejecutarConsulta("SELECT COUNT(*) AS total FROM cliente WHERE estatus = 1");
        if (rsClientes != null && rsClientes.next()) dataset.setValue("Clientes Activos", rsClientes.getInt("total"));

        ResultSet rsVentas = Conexion.ejecutarConsulta("SELECT COUNT(*) AS total FROM venta WHERE estatus = 1");
        if (rsVentas != null && rsVentas.next()) dataset.setValue("Ventas Activas", rsVentas.getInt("total"));

    } catch (Exception e) {
        e.printStackTrace();
    }

    JFreeChart chart = ChartFactory.createPieChart(
            "Clientes y Ventas",
            dataset,
            true,
            true,
            false
    );

    PiePlot plot = (PiePlot) chart.getPlot();

    // Colores
    plot.setSectionPaint("Clientes Activos", Color.decode("#EBE7A7"));
    plot.setSectionPaint("Ventas Activas", Color.decode("#EDC68E"));
    plot.setBackgroundPaint(Color.decode("#E4FFD4"));

    // Mostrar cantidades y porcentajes
    plot.setLabelGenerator(new StandardPieSectionLabelGenerator("{0}: {1} ({2})"));

    return new ChartPanel(chart);
}


   private JPanel crearGraficaPieProveedores() {
    DefaultPieDataset dataset = new DefaultPieDataset();

    try {
        ResultSet rsProveedores = Conexion.ejecutarConsulta("SELECT COUNT(*) AS total FROM proveedor WHERE estatus = 1");
        if (rsProveedores != null && rsProveedores.next()) dataset.setValue("Proveedores Activos", rsProveedores.getInt("total"));

        ResultSet rsCompras = Conexion.ejecutarConsulta("SELECT COUNT(*) AS total FROM detalle_compra");
        if (rsCompras != null && rsCompras.next()) dataset.setValue("Compras Registradas", rsCompras.getInt("total"));

    } catch (Exception e) {
        e.printStackTrace();
    }

    JFreeChart chart = ChartFactory.createPieChart(
            "Proveedores y Compras",
            dataset,
            true,
            true,
            false
    );

    PiePlot plot = (PiePlot) chart.getPlot();

    // Colores
    plot.setSectionPaint("Proveedores Activos", Color.decode("#EBE7A7"));
    plot.setSectionPaint("Compras Registradas", Color.decode("#EDC68E"));
    plot.setBackgroundPaint(Color.decode("#EBE7A7"));

    // Mostrar cantidades y porcentajes
    plot.setLabelGenerator(new StandardPieSectionLabelGenerator("{0}: {1} ({2})"));

    return new ChartPanel(chart);
}


    private void cargarDatosClientes() {
        try {
            ResultSet rsTotal = Conexion.ejecutarConsulta("SELECT COUNT(*) AS total FROM cliente WHERE estatus = 1");
            if (rsTotal != null && rsTotal.next()) lblTotalClientes.setText("" + rsTotal.getInt("total"));

            // Cliente más frecuente
            String clienteTop = Conexion.obtenerRegistroMasFrecuente(
                    "venta", "cliente", "id_cliente", "id_cliente", "nombre", "estatus"
            );
            lblClienteFrecuente.setText(clienteTop);

        } catch (Exception e) {
            System.err.println("Error al cargar datos clientes: " + e.getMessage());
        }
    }

    private void cargarDatosProveedores() {
        try {
            ResultSet rsTotal = Conexion.ejecutarConsulta("SELECT COUNT(*) AS total FROM proveedor WHERE estatus = 1");
            if (rsTotal != null && rsTotal.next()) lblTotalProveedores.setText("" + rsTotal.getInt("total"));

            // Proveedor con más compras (relación indirecta)
            String proveedorTop = "N/A";
            ResultSet rs = Conexion.ejecutarConsulta(
                "SELECT p.nombre_comercial, COUNT(*) AS total " +
                "FROM detalle_compra dc " +
                "INNER JOIN compra c ON c.id_compra = dc.id_compra " +
                "INNER JOIN proveedor p ON p.id_proveedor = c.id_proveedor " +
                "GROUP BY p.id_proveedor ORDER BY total DESC LIMIT 1"
            );
            if (rs != null && rs.next()) proveedorTop = rs.getString("nombre_comercial");
            lblProveedorTop.setText(proveedorTop);

        } catch (Exception e) {
            System.err.println("Error al cargar datos proveedores: " + e.getMessage());
        }
    }
}
