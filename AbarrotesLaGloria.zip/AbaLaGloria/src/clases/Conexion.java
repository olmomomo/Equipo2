/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package paquete;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Map;

/**
 *
 * @author ayele
 */


public class Conexion {

    // 🔹 Instancia única (patrón Singleton)
    private static Connection conexion = null;

    // 🔹 Parámetros de conexión
    private static final String URL = "jdbc:mysql://127.0.0.1:3306/AbaLaGloria?useSSL=false&serverTimezone=UTC&useUnicode=true&characterEncoding=UTF-8";
    private static final String USUARIO = "root";
    private static final String CONTRASEÑA = "Nami3003";

    // 🔹 Constructor privado (solo se puede instanciar desde dentro)
    private Conexion() {
        
    }

     // 🔹 método único para obtener la conexión
    public static Connection getConexion() {
        if (conexion == null) {
            try {
                conexion = DriverManager.getConnection(URL, USUARIO, CONTRASEÑA);
                System.out.println("✅ Conexión exitosa a la base de datos.");
            } catch (SQLException e) {
                System.err.println("❌ Error al conectar: " + e.getMessage());
            }
        }
        return conexion;
    }
    
    public static int obtenerUltimoId() {
        int id = -1;
        try {
            ResultSet rs = ejecutarConsulta("SELECT LAST_INSERT_ID() AS id");
            if (rs != null && rs.next()) {
                id = rs.getInt("id");
            }
        } catch (SQLException e) {
            System.err.println("❌ Error al obtener último ID: " + e.getMessage());
        }
        return id;
    }
    

    // 🔹 Cierra la conexión (cuando se cierra el sistema)
    public static void cerrarConexion() {
        try {
            if (conexion != null && !conexion.isClosed()) {
                conexion.close();
                System.out.println("🔒 Conexión cerrada correctamente.");
            }
        } catch (SQLException e) {
            System.err.println("❌ Error al cerrar la conexión: " + e.getMessage());
        }
    }

    // ----------------------------------------------------
    // 🔸 MÉTODOS GENÉRICOS DE CONSULTA / ACTUALIZACIÓN 🔸
    // ----------------------------------------------------

    public static boolean insertar(String tabla, String columnas, String valores, Object... parametros) {
        String sql = "INSERT INTO " + tabla + " (" + columnas + ") VALUES (" + valores + ")";
        try (PreparedStatement stmt = getConexion().prepareStatement(sql)) {
            for (int i = 0; i < parametros.length; i++) {
                stmt.setObject(i + 1, parametros[i]);
            }
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.err.println("Error al insertar en " + tabla + ": " + e.getMessage());
            return false;
        }
    }

    public static boolean actualizar(String tabla, String setClause, String whereClause, Object... parametros) {
        String sql = "UPDATE " + tabla + " SET " + setClause + " WHERE " + whereClause;
        try (PreparedStatement stmt = getConexion().prepareStatement(sql)) {
            for (int i = 0; i < parametros.length; i++) {
                stmt.setObject(i + 1, parametros[i]);
            }
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.err.println("Error al actualizar en " + tabla + ": " + e.getMessage());
            return false;
        }
    }

    public static boolean eliminar(String tabla, String whereClause, Object... parametros) {
        String sql = "DELETE FROM " + tabla + " WHERE " + whereClause;
        try (PreparedStatement stmt = getConexion().prepareStatement(sql)) {
            for (int i = 0; i < parametros.length; i++) {
                stmt.setObject(i + 1, parametros[i]);
            }
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.err.println("Error al eliminar de " + tabla + ": " + e.getMessage());
            return false;
        }
    }

    public static ResultSet consultarTodo(String tabla) {
        String sql = "SELECT * FROM " + tabla;
        try {
            PreparedStatement stmt = getConexion().prepareStatement(sql);
            return stmt.executeQuery();
        } catch (SQLException e) {
            System.err.println("Error al consultar " + tabla + ": " + e.getMessage());
            return null;
        }
    }

    public static ResultSet buscarPorId(String tabla, String campoID, Object id) {
        String sql = "SELECT * FROM " + tabla + " WHERE " + campoID + " = ?";
        try {
            PreparedStatement stmt = getConexion().prepareStatement(sql);
            stmt.setObject(1, id);
            return stmt.executeQuery();
        } catch (SQLException e) {
            System.err.println("Error al buscar en " + tabla + ": " + e.getMessage());
            return null;
        }
    }

    public  static ResultSet ejecutarConsulta(String sql, Object... parametros) {
        try {
            PreparedStatement stmt = getConexion().prepareStatement(sql);
            for (int i = 0; i < parametros.length; i++) {
                stmt.setObject(i + 1, parametros[i]);
            }
            return stmt.executeQuery();
        } catch (SQLException e) {
            System.err.println("Error al ejecutar la consulta: " + e.getMessage());
            return null;
        }
    }

    public static  ResultSet buscarPorCampos(String tabla, String[] campos, Object[] valores) {
        if (campos.length != valores.length)
            throw new IllegalArgumentException("Los arrays deben tener la misma longitud.");

        StringBuilder sql = new StringBuilder("SELECT * FROM " + tabla + " WHERE ");
        for (int i = 0; i < campos.length; i++) {
            sql.append(campos[i]).append(" = ?");
            if (i < campos.length - 1) sql.append(" AND ");
        }

        try {
            PreparedStatement stmt = getConexion().prepareStatement(sql.toString());
            for (int i = 0; i < valores.length; i++) {
                stmt.setObject(i + 1, valores[i]);
            }
            return stmt.executeQuery();
        } catch (SQLException e) {
            System.err.println("Error en búsqueda múltiple: " + e.getMessage());
            return null;
        }
    }

    public static  boolean actualizarPorCampo(String tabla, Map<String, Object> campos, String campoClave, Object valorClave) {
        StringBuilder sql = new StringBuilder("UPDATE " + tabla + " SET ");
        int count = 0;
        for (String campo : campos.keySet()) {
            sql.append(campo).append(" = ?");
            if (++count < campos.size()) sql.append(", ");
        }
        sql.append(" WHERE ").append(campoClave).append(" = ?");

        try (PreparedStatement stmt = getConexion().prepareStatement(sql.toString())) {
            int index = 1;
            for (Object val : campos.values()) {
                stmt.setObject(index++, val);
            }
            stmt.setObject(index, valorClave);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al actualizar en " + tabla + ": " + e.getMessage());
            return false;
        }
    }

    public static ResultSet showColumnsLike(String tabla, String filtroLike) {
        String sql = "SHOW COLUMNS FROM " + tabla + " LIKE ?";
        try {
            PreparedStatement stmt = getConexion().prepareStatement(sql);
            stmt.setString(1, filtroLike);
            return stmt.executeQuery();
        } catch (SQLException e) {
            System.err.println("Error en showColumnsLike: " + e.getMessage());
            return null;
        }
    }

    public static ResultSet describeTable(String tabla) {
        String sql = "DESCRIBE " + tabla;
        try {
            PreparedStatement stmt = getConexion().prepareStatement(sql);
            return stmt.executeQuery();
        } catch (SQLException e) {
            System.err.println("Error en describeTable: " + e.getMessage());
            return null;
        }
    }

    public static ResultSet showWithFilter(String filtro) {
        String sql = "SHOW COLUMNS FROM usuario LIKE ?";
        try {
            PreparedStatement stmt = getConexion().prepareStatement(sql);
            stmt.setString(1, filtro);
            return stmt.executeQuery();
        } catch (SQLException e) {
            System.err.println("Error en showWithFilter: " + e.getMessage());
            return null;
        }}
    
        
  public static ResultSet buscarTodosOrdenado(String tabla, String columna, String orden) {
    try {
        String sql = "SELECT * FROM " + tabla + " ORDER BY " + columna + " " + orden;
        PreparedStatement ps = getConexion().prepareStatement(sql);
        return ps.executeQuery();
    } catch (SQLException ex) {
        System.out.println("Error en buscarTodosOrdenado: " + ex.getMessage());
        return null;
    }
}
  
  public static ResultSet buscarPorCamposOrdenado(String tabla, String[] campos, Object[] valores,
                                                String columnaOrden, String orden) {

    if (campos.length != valores.length) {
        throw new IllegalArgumentException("Los arrays deben tener la misma longitud.");
    }

    StringBuilder sql = new StringBuilder("SELECT * FROM " + tabla + " WHERE ");

    // Crear el WHERE dinámico
    for (int i = 0; i < campos.length; i++) {
        sql.append(campos[i]).append(" = ?");
        if (i < campos.length - 1) sql.append(" AND ");
    }

    // Agregar ORDER BY
    sql.append(" ORDER BY ").append(columnaOrden).append(" ").append(orden);

    try {
        PreparedStatement stmt = getConexion().prepareStatement(sql.toString());
        for (int i = 0; i < valores.length; i++) {
            stmt.setObject(i + 1, valores[i]);
        }
        return stmt.executeQuery();
    } catch (SQLException e) {
        System.err.println("Error en buscarPorCamposOrdenado: " + e.getMessage());
        return null;
    }
}

  public static void iniciarTransaccion() throws SQLException {
    getConexion().setAutoCommit(false);
}

public static void confirmarTransaccion() throws SQLException {
    getConexion().commit();
}

public static void revertirTransaccion() throws SQLException {
    getConexion().rollback();
}

public static int contarRegistrosActivos(String tabla, String campoEstado) {
    int total = 0;
    try {
        String sql = "SELECT COUNT(*) AS total FROM " + tabla + " WHERE " + campoEstado + " = 1";
        ResultSet rs = ejecutarConsulta(sql);
        if (rs != null && rs.next()) total = rs.getInt("total");
    } catch (SQLException e) {
        System.err.println("Error en contarRegistrosActivos: " + e.getMessage());
    }
    return total;
}

public static String obtenerRegistroMasFrecuente(
        String tablaRelacion,
        String tablaReferencia,
        String idReferenciaRelacion,
        String idReferenciaTabla,
        String nombreColumna,
        String filtroEstadoRelacion) {

    try {
        String sql = "SELECT r." + nombreColumna + ", COUNT(*) AS total " +
                     "FROM " + tablaRelacion + " rel " +
                     "INNER JOIN " + tablaReferencia + " r ON r." + idReferenciaTabla + " = rel." + idReferenciaRelacion +
                     (filtroEstadoRelacion != null ? " WHERE rel." + filtroEstadoRelacion + " = 1" : "") +
                     " GROUP BY r." + idReferenciaTabla + 
                     " ORDER BY total DESC LIMIT 1";

        ResultSet rs = ejecutarConsulta(sql);
        if (rs != null && rs.next()) return rs.getString(nombreColumna);

    } catch (SQLException e) {
        System.err.println("Error en obtenerRegistroMasFrecuente: " + e.getMessage());
    }

    return "N/A";
}

public static String obtenerProveedorTop() {
    try {
        String sql = "SELECT p.nombre_comercial, COUNT(*) AS total " +
                     "FROM detalle_compra dc " +
                     "INNER JOIN compra c ON dc.id_compra = c.id_compra " +
                     "INNER JOIN proveedor p ON c.id_proveedor = p.id_proveedor " +
                     "GROUP BY p.id_proveedor " +
                     "ORDER BY total DESC LIMIT 1";

        ResultSet rs = ejecutarConsulta(sql);
        if (rs != null && rs.next()) return rs.getString("nombre_comercial");

    } catch (SQLException e) {
        System.err.println("Error en obtenerProveedorTop: " + e.getMessage());
    }

    return "N/A";
}


public static int[] obtenerTotalesParaGrafica(String[] tablas, String campoEstado) {
    int[] resultados = new int[tablas.length];

    for (int i = 0; i < tablas.length; i++) {
        resultados[i] = contarRegistrosActivos(tablas[i], campoEstado);
    }

    return resultados;
}

public static ResultSet obtenerComprasConProductosOrdenadas(String columnaOrden, String orden) {

    String orderBy;

    if (columnaOrden.equals("productos")) {
        // Ordenar por el texto concatenado de productos
        orderBy = "GROUP_CONCAT(p.nombre ORDER BY p.nombre SEPARATOR ', ') " + orden;
    } else {
        orderBy = columnaOrden + " " + orden;
    }

    String sql = "SELECT c.id_compra, c.fecha, c.total, " +
                 "GROUP_CONCAT(p.nombre ORDER BY p.nombre SEPARATOR ', ') AS productos " +
                 "FROM compra c " +
                 "INNER JOIN detalle_compra dc ON c.id_compra = dc.id_compra " +
                 "INNER JOIN producto p ON dc.id_producto = p.id_producto " +
                 "GROUP BY c.id_compra, c.fecha, c.total " +
                 "ORDER BY " + orderBy;

    try {
        PreparedStatement ps = Conexion.getConexion().prepareStatement(sql);
        return ps.executeQuery();
    } catch (SQLException ex) {
        System.err.println("Error en obtenerComprasConProductosOrdenadas: " + ex.getMessage());
        return null;
    }
}


public static ResultSet obtenerVentasConProductosOrdenadas(String columnaOrden, String orden) {

    String orderBy;

    if (columnaOrden.equals("productos")) {
        // Ordenar por el texto concatenado (A-Z o Z-A)
        orderBy = "GROUP_CONCAT(p.nombre ORDER BY p.nombre SEPARATOR ', ') " + orden;
    } else {
        // Ordenar por ID u otra columna normal
        orderBy = columnaOrden + " " + orden;
    }

    String sql = "SELECT v.id_venta, v.fecha, v.total, " +
                 "GROUP_CONCAT(p.nombre ORDER BY p.nombre SEPARATOR ', ') AS productos " +
                 "FROM venta v " +
                 "INNER JOIN detalle_venta dv ON v.id_venta = dv.id_venta " +
                 "INNER JOIN producto p ON dv.id_producto = p.id_producto " +
                 "GROUP BY v.id_venta, v.fecha, v.total " +
                 "ORDER BY " + orderBy;

    try {
        PreparedStatement ps = Conexion.getConexion().prepareStatement(sql);
        return ps.executeQuery();
    } catch (SQLException ex) {
        System.err.println("Error en obtenerVentasConProductosOrdenadas: " + ex.getMessage());
        return null;
    }
}



}