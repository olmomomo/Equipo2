/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package frames;

import clases.Sesion;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.KeyEvent;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import menulateral.SideMenuItem;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.ImageIcon;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;
import paquete.Conexion;

/**
 *
 * @author ayele
 */
public class AgregarCompra extends javax.swing.JFrame {

      private int idProveedorSeleccionado = -1;
    /**
     * Creates new form AgregarCompra
     */
    public AgregarCompra() {
        initComponents();
        cargarProveedoresOrdenados("Ordenar A-Z");
        cargarMetodo();
       inicializarComponentesAdicionales(); // <- Esta línea nueva
        //CargarProductos();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        txtFecha.setText(LocalDate.now().format(formatter));
        int rol = Sesion.getRol();

        ImageIcon iconoA = new ImageIcon(getClass().getResource("/imagenes/abajo.png"));
        Image imagenAct = iconoA.getImage().getScaledInstance(32, 32, Image.SCALE_SMOOTH);
        ImageIcon iconoEditar = new ImageIcon(imagenAct);
        btnAgregarCompra.setIcon(iconoEditar);
        btnAgregarCompra.setText("Guardar Información");
        btnAgregarCompra.setHorizontalTextPosition(SwingConstants.RIGHT);  // Texto a la derecha del ícono
        btnAgregarCompra.setVerticalTextPosition(SwingConstants.CENTER);
        
        ImageIcon iconoB = new ImageIcon(getClass().getResource("/imagenes/quitar-del-carrito.png"));
        Image imagenQuitar = iconoB.getImage().getScaledInstance(32, 32, Image.SCALE_SMOOTH);
        ImageIcon iconoQuitarP = new ImageIcon(imagenQuitar);
        btnQuitarProdu.setIcon(iconoQuitarP);
        btnQuitarProdu.setText("Eliminar producto");
        btnQuitarProdu.setHorizontalTextPosition(SwingConstants.RIGHT);  // Texto a la derecha del ícono
        btnQuitarProdu.setVerticalTextPosition(SwingConstants.CENTER);
        
        ImageIcon iconoC = new ImageIcon(getClass().getResource("/imagenes/quitar-del-carrito.png"));
        Image imagenT = iconoC.getImage().getScaledInstance(32, 32, Image.SCALE_SMOOTH);
        ImageIcon iconoTicket = new ImageIcon(imagenT);
        btnImprimirTicket.setIcon(iconoTicket);
        btnImprimirTicket.setText("Imprimir ticket");
        btnImprimirTicket.setHorizontalTextPosition(SwingConstants.RIGHT);  // Texto a la derecha del ícono
        btnImprimirTicket.setVerticalTextPosition(SwingConstants.CENTER);
// 🔹 Configurar visibilidad según el rol
for (SideMenuItem item : sideMenu.getModel().getItems()) {

    String nombre = item.getText();

    // Por defecto, todos visibles
    boolean visible = true;

    switch (rol) {
        case 1: // Admin
        case 2: // Gerente
            visible = true; // todos visibles
            break;

        case 3: // Cajero
            visible = nombre.equals("Ventas") ||
                      nombre.equals("Configuración") ||
                      nombre.equals("Ayuda") ||
                      nombre.equals("Salir");
            break;

        case 4: // Almacenista
            visible = nombre.equals("Productos") ||
                      nombre.equals("Configuración") ||
                      nombre.equals("Ayuda") ||
                      nombre.equals("Salir");
            break;
    }

    item.setShown(visible);
    item.setEnabled(visible);

    // 🔹 Caso especial: Configuración → Mi Perfil
    if ("Configuración".equals(nombre)) {
        for (SideMenuItem child : item.getChildren()) {
            if ("Mi Perfil".equals(child.getText())) {

                // Acción de "Mi Perfil"
                sideMenu.setMenuItemAction("Mi Perfil", e -> {
                    new MiPerfil().setVisible(true);
                    this.dispose();
                });

                // Ocultar si no debe verlo
                boolean visiblePerfil = (rol == 1 || rol == 2 || rol == 3 || rol == 4);
                child.setShown(visiblePerfil);
                child.setEnabled(visiblePerfil);
            }
        }
    }
}
    // 🔹 Acciones generales de menú
sideMenu.setMenuItemAction("Inicio", e -> {
    
    if (rol == 1) {
            new InicioAdmin().setVisible(true);
        } else {
            new InicioGene().setVisible(true);
        }
        this.dispose();
    
});


sideMenu.setMenuItemAction("Productos", e -> {
    new Producto().setVisible(true);
    this.dispose();
});

sideMenu.setMenuItemAction("Proveedores", e -> {
    new Proveedor().setVisible(true);
    this.dispose();
});

sideMenu.setMenuItemAction("Compras", e -> {
    new Compra().setVisible(true);
    this.dispose();
});

sideMenu.setMenuItemAction("Ventas", e -> {
    new Venta().setVisible(true);
    this.dispose();
});

sideMenu.setMenuItemAction("Ayuda", e -> {
    new Ayuda().setVisible(true);
    this.dispose();
});

sideMenu.setMenuItemAction("Salir", e -> {
    new Login().setVisible(true);
    this.dispose();
});


    }
    
    
    
     private void inicializarComponentesAdicionales() {
    txtIdCompra = new javax.swing.JTextField();
    txtIdCompra.setVisible(true); // Lo hacemos invisible
    txtNombre.add(txtIdCompra); // Lo agregamos al panel principal
}

     private void cargarProveedoresOrdenados(String opcion) {
    DefaultTableModel modelo = (DefaultTableModel) tablaDeProveedores.getModel();
    modelo.setRowCount(0); // Limpiar tabla

    String ordenSQL;

    switch (opcion) {
        case "A-Z":
            ordenSQL = "ASC";
            break;
        case "Z-A":
            ordenSQL = "DESC";
            break;
        default:
            ordenSQL = "ASC";
            break;
    }

    try {
        // Usando tu clase Conexion sin SQL directo
        ResultSet rs = Conexion.buscarTodosOrdenado(
                "proveedor",
                "nombre_comercial",
                ordenSQL
        );

        while (rs != null && rs.next()) {
            Object[] fila = new Object[3];
            fila[0] = rs.getInt("id_proveedor");
            fila[1] = rs.getString("nombre_comercial");
            fila[2] = rs.getInt("estatus");
            int estadoInt = rs.getInt("estatus");
           String estado = (estadoInt == 1) ? "ACTIVO" : "INACTIVO";
            modelo.addRow(fila);
           
            
           
        }

        
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(this, "Error al cargar proveedores: " + ex.getMessage());
    }

    System.out.println("Orden SQL: " + ordenSQL);
}

     private void cargarProductos(int idProveedor) {
    DefaultTableModel modelo = (DefaultTableModel) tablaCompras.getModel();
    modelo.setRowCount(0); // Limpiar tabla

    try {
        // Usando la clase Conexion
        ResultSet rs = Conexion.buscarPorCamposOrdenado(
                "producto",
                new String[]{"id_proveedor"},
                new Object[]{idProveedor},
                "nombre",  // ordenar por nombre
                "ASC"
        );

        while (rs != null && rs.next()) {
            Object[] fila = new Object[5];
            fila[0] = rs.getInt("id_producto");
            fila[1] = rs.getString("nombre");
            fila[2] = rs.getString("marca");
            fila[3] = rs.getInt("stock");
            fila[4] = rs.getDouble("precio");
            modelo.addRow(fila);
        }

    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(this, "Error al cargar productos: " + ex.getMessage());
    }
}

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        sideMenu = new menulateral.SideMenuComponent();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        txtIdProducto = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        txtNombre = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        txMarca = new javax.swing.JTextField();
        txtStock = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        txtPrecio = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        txtSub = new javax.swing.JTextField();
        jLabel18 = new javax.swing.JLabel();
        totalCompra = new javax.swing.JTextField();
        jLabel19 = new javax.swing.JLabel();
        txtFecha = new javax.swing.JTextField();
        txtCantidad = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        jScrollPane7 = new javax.swing.JScrollPane();
        tablaDeProveedores = new javax.swing.JTable();
        seleccionarProveedor = new javax.swing.JButton();
        txtIdCompra = new javax.swing.JTextField();
        jScrollPane6 = new javax.swing.JScrollPane();
        tablaCompras = new javax.swing.JTable();
        jScrollPane5 = new javax.swing.JScrollPane();
        tablaDeCompra = new javax.swing.JTable();
        btnAgregarCompra = new javax.swing.JButton();
        btnQuitarProdu = new javax.swing.JButton();
        btnImprimirTicket = new javax.swing.JButton();
        cmbMetodo = new javax.swing.JComboBox<>();
        jLabel21 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(164, 158, 126));

        sideMenu.setBackgroundColor(new java.awt.Color(228, 255, 212));
        sideMenu.setHoverColor(new java.awt.Color(228, 255, 212));
        sideMenu.setModel(new menulateral.SideMenuModel() {{ addItem(new menulateral.SideMenuItem("Inicio", "C:\\Users\\ayele\\Downloads\\hogar.png", "Ir a Inicio")); addItem(new menulateral.SideMenuItem("Productos", "C:\\Users\\ayele\\Downloads\\abarrotes-tienda.png", "Ir al almacén")); addItem(new menulateral.SideMenuItem("Proveedores", "C:\\Users\\ayele\\Downloads\\gestion-de-la-cadena-de-suministro.png", "Ir a proveedores ")); addItem(new menulateral.SideMenuItem("Compras", "C:\\Users\\ayele\\Downloads\\agregar-producto.png", "Ir a realizar compras")); addItem(new menulateral.SideMenuItem("Ventas", "C:\\Users\\ayele\\Downloads\\carrito-de-compras (1).png", "Ir a realizar ventas ")); addItem(new menulateral.SideMenuItem("Configuración", "C:\\Users\\ayele\\Downloads\\configuracion-del-usuario.png", "Ir a configuración")); menulateral.SideMenuItem item6994 = getItem(5); menulateral.SideMenuItem item4983 = new menulateral.SideMenuItem("Mi Perfil", "C:\\Users\\ayele\\Downloads\\avatar-de-usuario.png", "Ir a mi perfil"); item6994.addChild(item4983); addItem(new menulateral.SideMenuItem("Ayuda", "C:\\Users\\ayele\\Downloads\\ayuda.png", "Ayuda")); addItem(new menulateral.SideMenuItem("Salir", "C:\\Users\\ayele\\Downloads\\cerrar sesion (1).png", "Ir a login")); }});

        jLabel11.setFont(new java.awt.Font("Segoe UI Historic", 1, 18)); // NOI18N
        jLabel11.setText("AGREGAR COMPRA");

        jLabel12.setText("ID del producto");

        jLabel13.setText("Nombre");

        jLabel14.setText("Marca");

        jLabel15.setText("Stock");

        jLabel20.setText("Precio");

        txtPrecio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPrecioActionPerformed(evt);
            }
        });

        jLabel17.setText("Subtotal");

        txtSub.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtSubActionPerformed(evt);
            }
        });

        jLabel18.setText("Total");

        totalCompra.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                totalCompraActionPerformed(evt);
            }
        });

        jLabel19.setText("Fecha");

        txtCantidad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCantidadActionPerformed(evt);
            }
        });
        txtCantidad.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtCantidadKeyPressed(evt);
            }
        });

        jLabel16.setText("Cantidad");

        tablaDeProveedores.setBackground(new java.awt.Color(228, 255, 212));
        tablaDeProveedores.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "NOMBRE COMERCIAL", "ESTATUS"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Object.class, java.lang.Object.class, java.lang.Integer.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        tablaDeProveedores.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaDeProveedoresMouseClicked(evt);
            }
        });
        jScrollPane7.setViewportView(tablaDeProveedores);

        seleccionarProveedor.setBackground(new java.awt.Color(237, 198, 142));
        seleccionarProveedor.setText("Seleccionar Proveedor");
        seleccionarProveedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                seleccionarProveedorActionPerformed(evt);
            }
        });

        tablaCompras.setBackground(new java.awt.Color(235, 231, 167));
        tablaCompras.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID PRODUCTO", "NOMBRE", "MARCA", "STOCK", "PRECIO"
            }
        ));
        tablaCompras.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaComprasMouseClicked(evt);
            }
        });
        tablaCompras.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                tablaComprasPropertyChange(evt);
            }
        });
        jScrollPane6.setViewportView(tablaCompras);

        tablaDeCompra.setBackground(new java.awt.Color(235, 231, 167));
        tablaDeCompra.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID PRODUCTO", "NOMBRE", "CANTIDAD ", "PRECIO "
            }
        ));
        jScrollPane5.setViewportView(tablaDeCompra);

        btnAgregarCompra.setBackground(new java.awt.Color(237, 198, 142));
        btnAgregarCompra.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarCompraActionPerformed(evt);
            }
        });

        btnQuitarProdu.setBackground(new java.awt.Color(237, 198, 142));
        btnQuitarProdu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnQuitarProduActionPerformed(evt);
            }
        });

        btnImprimirTicket.setBackground(new java.awt.Color(237, 198, 142));
        btnImprimirTicket.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnImprimirTicketActionPerformed(evt);
            }
        });

        cmbMetodo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel21.setText("Método de pago ");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(sideMenu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(429, 429, 429)
                        .addComponent(jLabel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(61, 61, 61)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(btnAgregarCompra, javax.swing.GroupLayout.PREFERRED_SIZE, 229, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(68, 68, 68)
                                .addComponent(btnQuitarProdu, javax.swing.GroupLayout.PREFERRED_SIZE, 260, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(52, 52, 52)
                                .addComponent(btnImprimirTicket, javax.swing.GroupLayout.PREFERRED_SIZE, 211, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(txtIdProducto)
                                    .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(40, 40, 40)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(53, 53, 53)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txMarca, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(46, 46, 46)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtStock, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 755, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(29, 29, 29)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(txtIdCompra, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(seleccionarProveedor)))
                                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 921, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 921, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(txtCantidad, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(txtSub, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(28, 28, 28)
                                    .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(totalCompra, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(33, 33, 33)
                                    .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(txtFecha, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                            .addGap(37, 37, 37)
                                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(txtPrecio, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGap(15, 15, 15))
                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(cmbMetodo, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                        .addContainerGap(55, Short.MAX_VALUE))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(sideMenu, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel12)
                            .addComponent(jLabel13)
                            .addComponent(jLabel14)
                            .addComponent(jLabel15)
                            .addComponent(jLabel20))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtIdProducto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txMarca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtStock, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtPrecio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel21)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel16)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtCantidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel17, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel18)
                                    .addComponent(totalCompra, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtFecha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel19)
                                    .addComponent(txtSub, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(cmbMetodo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(49, 49, 49)
                                .addComponent(seleccionarProveedor)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtIdCompra, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(25, 25, 25)
                        .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnAgregarCompra, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(btnQuitarProdu, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(btnImprimirTicket, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 44, Short.MAX_VALUE)))
                .addContainerGap())
        );

        getContentPane().add(jPanel1, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cargarMetodo() {
    try {
        // Limpiar cualquier ítem previo del JComboBox
        cmbMetodo.removeAllItems();

        // Usar la clase Conexion para obtener todos los roles
        ResultSet rs = Conexion.consultarTodo("metodo_pago");

        // Agregar los roles al JComboBox
        while (rs != null && rs.next()) {
            cmbMetodo.addItem(rs.getString("nombre_metodo"));
        }

      

    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Error al cargar los metodos: " + e.getMessage());
    }
}
    
    private void txtPrecioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPrecioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPrecioActionPerformed

    private void txtSubActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSubActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtSubActionPerformed

    private void totalCompraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_totalCompraActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_totalCompraActionPerformed

    private void txtCantidadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCantidadActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCantidadActionPerformed

    private void txtCantidadKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCantidadKeyPressed
        // TODO add your handling code here:
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            agregarProductoATabla();
        }
    }//GEN-LAST:event_txtCantidadKeyPressed

    private void tablaDeProveedoresMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaDeProveedoresMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_tablaDeProveedoresMouseClicked

    private void agregarProductoATabla() {
    try {
        // Validar campos
        if (txtCantidad.getText().trim().isEmpty() || txtPrecio.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Ingrese cantidad y precio");
            return;
        }

        int cantidad = Integer.parseInt(txtCantidad.getText().trim());
        double precio = Double.parseDouble(txtPrecio.getText().trim());

        if (cantidad <= 0) {
            JOptionPane.showMessageDialog(this, "La cantidad debe ser mayor a cero");
            return;
        }

        // Calcular subtotal
        double subtotal = cantidad * precio;
        txtSub.setText(String.format("%.2f", subtotal));

        // Agregar a la tabla
        DefaultTableModel modelo = (DefaultTableModel) tablaDeCompra.getModel();
        modelo.addRow(new Object[]{
            txtIdProducto.getText(),
            txtNombre.getText(),
            cantidad,
            precio
        });

        // Calcular total
        calcularTotalCompra();

        // Limpiar y preparar para siguiente producto
        txtCantidad.setText("");
        txtCantidad.requestFocus();

    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(this, "Ingrese valores numéricos válidos");
    }
}
    private void seleccionarProveedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_seleccionarProveedorActionPerformed
        // TODO add your handling code here
        int filaSeleccionada = tablaDeProveedores.getSelectedRow();

    if (filaSeleccionada != -1) {
        Object valorId = tablaDeProveedores.getValueAt(filaSeleccionada, 0);

        if (valorId != null) {
            try {
                // Guardamos el ID del proveedor seleccionado
                idProveedorSeleccionado = Integer.parseInt(valorId.toString());

                // Cargar productos de ese proveedor
                cargarProductos(idProveedorSeleccionado);

            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "El ID del proveedor no es válido.");
            }
        } else {
            JOptionPane.showMessageDialog(this, "El ID del proveedor no puede ser nulo.");
        }
    } else {
        JOptionPane.showMessageDialog(this, "Por favor selecciona un proveedor.");
    }
    }//GEN-LAST:event_seleccionarProveedorActionPerformed

    private void tablaComprasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaComprasMouseClicked
        // TODO add your handling code here:
        int fila = tablaCompras.getSelectedRow();
        if (fila != -1) {
            txtIdProducto.setText(tablaCompras.getValueAt(fila, 0).toString());
            txtNombre.setText(tablaCompras.getValueAt(fila, 1).toString());
            txMarca.setText(tablaCompras.getValueAt(fila, 2).toString());
            txtStock.setText(tablaCompras.getValueAt(fila, 3).toString());
            txtPrecio.setText(tablaCompras.getValueAt(fila, 4).toString());
        }
    }//GEN-LAST:event_tablaComprasMouseClicked

    private void tablaComprasPropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_tablaComprasPropertyChange
        // TODO add your handling code here:
    }//GEN-LAST:event_tablaComprasPropertyChange

    private void btnAgregarCompraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarCompraActionPerformed
        // TODO add your handling code here:                                      

    if (tablaDeCompra.getRowCount() == 0) {
        JOptionPane.showMessageDialog(this, "No hay productos agregados a la compra", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    if (idProveedorSeleccionado == -1) {
        JOptionPane.showMessageDialog(this, "Debe seleccionar un proveedor antes de registrar la compra.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    String metodoPago = cmbMetodo.getSelectedItem() != null ? cmbMetodo.getSelectedItem().toString().trim() : null;
    if (metodoPago == null || metodoPago.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Debe seleccionar un método de pago.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    DefaultTableModel modelo = (DefaultTableModel) tablaDeCompra.getModel();
    
    // Validar cantidades y precios
    for (int i = 0; i < modelo.getRowCount(); i++) {
        try {
            int cantidad = Integer.parseInt(modelo.getValueAt(i, 2).toString());
            double precioUnitario = Double.parseDouble(modelo.getValueAt(i, 3).toString());

            if (cantidad <= 0) {
                JOptionPane.showMessageDialog(this, "La cantidad de productos debe ser mayor que 0 (fila " + (i+1) + ").", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (precioUnitario < 0) {
                JOptionPane.showMessageDialog(this, "El precio unitario no puede ser negativo (fila " + (i+1) + ").", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Cantidad o precio inválido en la fila " + (i+1) + ".", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
    }

    // Validar que el total ingresado sea correcto
    double totalCalculado = 0;
    for (int i = 0; i < modelo.getRowCount(); i++) {
        int cantidad = Integer.parseInt(modelo.getValueAt(i, 2).toString());
        double precioUnitario = Double.parseDouble(modelo.getValueAt(i, 3).toString());
        totalCalculado += cantidad * precioUnitario;
    }

    double totalIngresado;
    try {
        totalIngresado = Double.parseDouble(totalCompra.getText());
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(this, "Total de la compra inválido.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    if (Math.abs(totalCalculado - totalIngresado) > 0.01) { // diferencia tolerable
        JOptionPane.showMessageDialog(this, "El total ingresado no coincide con la suma de los productos.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    try {
        // Iniciar transacción
        Conexion.iniciarTransaccion();

        int idUsuario = Sesion.getIdUsuario();

        // Obtener ID del método de pago
        String[] camposMetodo = {"nombre_metodo"};
        Object[] valoresMetodo = {metodoPago};
        ResultSet rsMetodo = Conexion.buscarPorCampos("metodo_pago", camposMetodo, valoresMetodo);
        int metodoId = -1;
        if (rsMetodo != null && rsMetodo.next()) {
            metodoId = rsMetodo.getInt("id_metodo_pago");
        } else {
            JOptionPane.showMessageDialog(this, "Método de pago no encontrado en la base de datos.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Insertar compra principal
        boolean compraInsertada = Conexion.insertar(
                "compra",
                "fecha, total, id_proveedor, id_usuario, id_metodo_pago",
                "?, ?, ?, ?, ?",
                txtFecha.getText(),
                totalIngresado,
                idProveedorSeleccionado,
                idUsuario,
                metodoId
        );

        if (!compraInsertada) {
            throw new SQLException("No se pudo insertar la compra.");
        }

        int idCompra = Conexion.obtenerUltimoId();
        if (idCompra <= 0) {
            throw new SQLException("No se pudo obtener el ID de la compra.");
        }
        txtIdCompra.setText(String.valueOf(idCompra));

        // Insertar detalles de compra
        for (int i = 0; i < modelo.getRowCount(); i++) {
            int idProducto = Integer.parseInt(modelo.getValueAt(i, 0).toString());
            int cantidad   = Integer.parseInt(modelo.getValueAt(i, 2).toString());
            double precioUnitario = Double.parseDouble(modelo.getValueAt(i, 3).toString());

            boolean detalleInsertado = Conexion.insertar(
                "detalle_compra",
                "id_compra, id_producto, cantidad, precio_unitario",
                "?, ?, ?, ?",
                idCompra,
                idProducto,
                cantidad,
                precioUnitario
            );

            if (!detalleInsertado) {
                throw new SQLException("Error al insertar detalle de compra");
            }
        }

        // Actualizar stock
        for (int i = 0; i < modelo.getRowCount(); i++) {
            int idProducto = Integer.parseInt(modelo.getValueAt(i, 0).toString());
            int cantidad   = Integer.parseInt(modelo.getValueAt(i, 2).toString());

            boolean actualizado = Conexion.actualizar(
                    "producto",
                    "stock = stock + ?",
                    "id_producto = ?",
                    cantidad,
                    idProducto
            );

            if (!actualizado) {
                throw new SQLException("Error al actualizar stock de id_producto = " + idProducto);
            }
        }

        Conexion.confirmarTransaccion();
        JOptionPane.showMessageDialog(this, "Compra registrada con éxito!\nID: " + idCompra, "Éxito", JOptionPane.INFORMATION_MESSAGE);
        limpiarCampos();

    } catch (SQLException e) {
        try {
            if (Conexion.getConexion() != null) {
                Conexion.revertirTransaccion(); // Rollback
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        JOptionPane.showMessageDialog(this, "Error al registrar la compra: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        e.printStackTrace();
    }
    }//GEN-LAST:event_btnAgregarCompraActionPerformed

    private void limpiarTodo() {
    limpiarCampos();
    txtIdCompra.setText(""); // Esto limpia el ID de venta cuando realmente lo necesites
}
private void limpiarCampos() {
    txtIdProducto.setText("");
    txtNombre.setText("");
    txMarca.setText("");
    txtStock.setText("");
    txtPrecio.setText("");
    txtSub.setText("");
    totalCompra.setText("");
    txtFecha.setText(""); 
    ((DefaultTableModel) tablaDeCompra.getModel()).setRowCount(0);
    //CargarProductos(); // Refrescar la lista de productos con nuevos stocks
}
    private void btnQuitarProduActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnQuitarProduActionPerformed
        // TODO add your handling code here:
        int filaSeleccionada = tablaDeCompra.getSelectedRow();

        if (filaSeleccionada == -1) {
            JOptionPane.showMessageDialog(this, "Por favor seleccione un producto para quitar", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            // Obtener datos del producto a quitar
            int idProducto = Integer.parseInt(tablaDeCompra.getValueAt(filaSeleccionada, 0).toString());
            int Cantidad = Integer.parseInt(tablaDeCompra.getValueAt(filaSeleccionada, 2).toString());

            // Quitar de la tabla de venta
            DefaultTableModel modeloVenta = (DefaultTableModel) tablaDeCompra.getModel();
            modeloVenta.removeRow(filaSeleccionada);

            // Actualizar el stock en la tabla de productos (sumar la cantidad devuelta)
            DefaultTableModel modeloProductos = (DefaultTableModel) tablaCompras.getModel();
            for (int i = 0; i < modeloProductos.getRowCount(); i++) {
                int idTabla = Integer.parseInt(modeloProductos.getValueAt(i, 0).toString());
                if (idTabla == idProducto) {
                    int stockActual = Integer.parseInt(modeloProductos.getValueAt(i, 3).toString());
                    modeloProductos.setValueAt(stockActual + Cantidad, i, 3);
                    break;
                }
            }

            // Recalcular totales
            recalcularTotales();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Producto eliminado: " + e.getMessage(), "", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btnQuitarProduActionPerformed

    private void calcularTotalCompra() {
    DefaultTableModel modelo = (DefaultTableModel) tablaDeCompra.getModel();
    double total = 0;
    
    for (int i = 0; i < modelo.getRowCount(); i++) {
        int cantidad = Integer.parseInt(modelo.getValueAt(i, 2).toString());
        double precio = Double.parseDouble(modelo.getValueAt(i, 3).toString());
        total += cantidad * precio;
    }
    
    totalCompra.setText(String.format("%.2f", total));
}
    private void recalcularTotales() {
    DefaultTableModel modelo = (DefaultTableModel) tablaDeCompra.getModel();
    double total = 0.0;
    
    for (int i = 0; i < modelo.getRowCount(); i++) {
        int cantidad = Integer.parseInt(modelo.getValueAt(i, 2).toString());
        double precio = Double.parseDouble(modelo.getValueAt(i, 3).toString());
        total += cantidad * precio;
        
        // Opcional: Mostrar subtotal del último producto
        if (i == modelo.getRowCount() - 1) {
            txtSub.setText(String.format("%.2f", cantidad * precio));
        }
    }
    
    totalCompra.setText(String.format("%.2f", total));
}
 
    private void btnImprimirTicketActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnImprimirTicketActionPerformed
        // TODO add your handling code here:

    if (txtIdCompra.getText().isEmpty()) {
        JOptionPane.showMessageDialog(this,
            "No hay una compra registrada recientemente.\n" +
            "Por favor registre una compra primero.",
            "Advertencia", JOptionPane.WARNING_MESSAGE);
        return;
    }

    try {
        int idCompra = Integer.parseInt(txtIdCompra.getText());

        // ======================================================
        // 1. Obtener datos de la compra usando la clase Conexion
        // ======================================================
        ResultSet rsCompra = Conexion.buscarPorId("compra", "id_compra", idCompra);

        if (rsCompra == null || !rsCompra.next()) {
            JOptionPane.showMessageDialog(this,
                "No se encontró la compra con ID: " + idCompra,
                "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String fecha = rsCompra.getString("fecha");
        double totalCompra = rsCompra.getDouble("total");
        int idProveedor = rsCompra.getInt("id_proveedor");

        // ======================================================
        // 2. Obtener nombre del proveedor (sin SQL directo)
        // ======================================================
        ResultSet rsProv = Conexion.buscarPorId("proveedor", "id_proveedor", idProveedor);

        String proveedorNombre = "Desconocido";
        if (rsProv != null && rsProv.next()) {
            proveedorNombre = rsProv.getString("nombre_comercial");
        }

        // ======================================================
        // 3. Obtener detalles (JOIN simulado en dos consultas)
        // ======================================================
        ResultSet rsDetalles = Conexion.buscarPorCampos(
                "detalle_compra",
                new String[]{"id_compra"},
                new Object[]{idCompra}
        );

        if (rsDetalles == null) {
            JOptionPane.showMessageDialog(this,
                "No hay detalles asociados.",
                "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // ======================================================
        // Construcción del ticket
        // ======================================================
        StringBuilder ticket = new StringBuilder();

        ticket.append("============= ABA LA GLORIA =============\n");
        ticket.append("         *** TICKET DE COMPRA ***        \n");
        ticket.append("=========================================\n");
        ticket.append("Proveedor: ").append(proveedorNombre).append("\n");
        ticket.append("ID Compra: ").append(idCompra).append("\n");
        ticket.append("Fecha: ").append(fecha).append("\n");
        ticket.append("=========================================\n");
        ticket.append(String.format("%-5s %-20s %-7s %-10s\n",
                "Cant", "Producto", "P.Unit", "Subtotal"));
        ticket.append("-----------------------------------------\n");

        boolean tieneDetalles = false;

        while (rsDetalles.next()) {
            tieneDetalles = true;

            int idProducto = rsDetalles.getInt("id_producto");
            int cantidad = rsDetalles.getInt("cantidad");

            // Obtener datos del producto (sin SQL directo)
            ResultSet rsProd = Conexion.buscarPorId("producto", "id_producto", idProducto);

            if (rsProd != null && rsProd.next()) {
                String nombre = rsProd.getString("nombre");
                double precio = rsProd.getDouble("precio");
                double subtotal = precio * cantidad;

                ticket.append(String.format("%-5d %-20s $%-6.2f $%-8.2f\n",
                        cantidad, nombre, precio, subtotal));
            }
        }

        if (!tieneDetalles) {
            JOptionPane.showMessageDialog(this,
                "La compra no tiene productos registrados.",
                "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }

        ticket.append("=========================================\n");
        ticket.append(String.format("TOTAL A PAGAR: $%.2f\n", totalCompra));
        ticket.append("=========================================\n");
        ticket.append("   ¡Gracias por su compra con nosotros!   \n");
        ticket.append("=========================================\n");

        // ======================================================
        // Mostrar ticket
        // ======================================================
        JTextArea textArea = new JTextArea(ticket.toString());
        textArea.setEditable(false);
        textArea.setFont(new Font("Monospaced", Font.PLAIN, 12));

        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new Dimension(420, 480));

        JOptionPane.showMessageDialog(this,
            scrollPane,
            "Ticket de Compra #" + idCompra,
            JOptionPane.INFORMATION_MESSAGE);

    } catch (Exception e) {
        JOptionPane.showMessageDialog(this,
            "Error al imprimir el ticket: " + e.getMessage(),
            "Error", JOptionPane.ERROR_MESSAGE);
        e.printStackTrace();
    }

    }//GEN-LAST:event_btnImprimirTicketActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AgregarCompra.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AgregarCompra.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AgregarCompra.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AgregarCompra.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AgregarCompra().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAgregarCompra;
    private javax.swing.JButton btnImprimirTicket;
    private javax.swing.JButton btnQuitarProdu;
    private javax.swing.JComboBox<String> cmbMetodo;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JButton seleccionarProveedor;
    private menulateral.SideMenuComponent sideMenu;
    private javax.swing.JTable tablaCompras;
    private javax.swing.JTable tablaDeCompra;
    private javax.swing.JTable tablaDeProveedores;
    private javax.swing.JTextField totalCompra;
    private javax.swing.JTextField txMarca;
    private javax.swing.JTextField txtCantidad;
    private javax.swing.JTextField txtFecha;
    private javax.swing.JTextField txtIdCompra;
    private javax.swing.JTextField txtIdProducto;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtPrecio;
    private javax.swing.JTextField txtStock;
    private javax.swing.JTextField txtSub;
    // End of variables declaration//GEN-END:variables

}
