/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package frames;

import clases.CaptchaPanel;
import clases.Sesion;
import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;
import menulateral.SideMenuItem;
import paquete.Conexion;
import java.sql.ResultSet;
import java.util.LinkedHashMap;
import java.util.Map;
import javax.swing.JOptionPane;
import java.sql.SQLException;

/**
 *
 * @author yose2
 */
public class EditarProveedor extends javax.swing.JFrame {

    private int idProveedorActual ;
private int idDireccionActual ;
    /**
     * Creates new form EitarProveedor
     */
    public EditarProveedor(int idProveedor) {
        this.idProveedorActual = idProveedor;
        initComponents();
        cargarDatosProveedor(idProveedor);
         // Obtener rol actual
      int rol = Sesion.getRol();

// 🔹 Configurar visibilidad según el rol
for (SideMenuItem item : sideMenu.getModel().getItems()) {

    String nombre = item.getText();

    // Por defecto, todos visibles
    boolean visible = true;

    switch (rol) {
        case 1: // Admin
        case 2: // Gerente
            visible = true; // todos visibles
            break;

        case 3: // Cajero
            visible = nombre.equals("Ventas") ||
                      nombre.equals("Configuración") ||
                      nombre.equals("Ayuda") ||
                      nombre.equals("Salir");
            break;

        case 4: // Almacenista
            visible = nombre.equals("Productos") ||
                      nombre.equals("Configuración") ||
                      nombre.equals("Ayuda") ||
                      nombre.equals("Salir");
            break;
    }

    item.setShown(visible);
    item.setEnabled(visible);

    // 🔹 Caso especial: Configuración → Mi Perfil
    if ("Configuración".equals(nombre)) {
        for (SideMenuItem child : item.getChildren()) {
            if ("Mi Perfil".equals(child.getText())) {

                // Acción de "Mi Perfil"
                sideMenu.setMenuItemAction("Mi Perfil", e -> {
                    new MiPerfil().setVisible(true);
                    this.dispose();
                });

                // Ocultar si no debe verlo
                boolean visiblePerfil = (rol == 1 || rol == 2 || rol == 3 || rol == 4);
                child.setShown(visiblePerfil);
                child.setEnabled(visiblePerfil);
            }
        }
    }
}

// 🔹 Acciones generales de menú
sideMenu.setMenuItemAction("Inicio", e -> {
   if (rol == 1) {
            new InicioAdmin().setVisible(true);
        } else {
            new InicioGene().setVisible(true);
        }
        this.dispose();
});

sideMenu.setMenuItemAction("Productos", e -> {
    new Producto().setVisible(true);
    this.dispose();
});

sideMenu.setMenuItemAction("Proveedores", e -> {
    new Proveedor().setVisible(true);
    this.dispose();
});

sideMenu.setMenuItemAction("Compras", e -> {
    new Compra().setVisible(true);
    this.dispose();
});

sideMenu.setMenuItemAction("Ventas", e -> {
    new Venta().setVisible(true);
    this.dispose();
});

sideMenu.setMenuItemAction("Ayuda", e -> {
    new Ayuda().setVisible(true);
    this.dispose();
});

sideMenu.setMenuItemAction("Salir", e -> {
    new frames.Login().setVisible(true);
    this.dispose();
});
 
 ImageIcon iconoA = new ImageIcon(getClass().getResource("/imagenes/abajo.png"));
        Image imagenAct = iconoA.getImage().getScaledInstance(32, 32, Image.SCALE_SMOOTH);
        ImageIcon iconoEditar = new ImageIcon(imagenAct);
        btnGuardar.setIcon(iconoEditar);
        btnGuardar.setText("Guardar Información");
        btnGuardar.setHorizontalTextPosition(SwingConstants.RIGHT);  // Texto a la derecha del ícono
        btnGuardar.setVerticalTextPosition(SwingConstants.CENTER); 

    }

   private void cargarDatosProveedor(int proveedorId) {
    try {
        ResultSet rsProv = Conexion.buscarPorId("proveedor", "id_proveedor", proveedorId);
        if (rsProv != null && rsProv.next()) {
            txtRFC.setText(rsProv.getString("rfc"));
            txtNombre.setText(rsProv.getString("nombre_comercial"));
            txtTelefono.setText(rsProv.getString("telefono"));
            txtCorreo.setText(rsProv.getString("correo"));
            txtBanco.setText(rsProv.getString("banco"));
            txtClabe.setText(rsProv.getString("clabe"));
            
            int idDireccion = rsProv.getInt("id_direccion");
            if (idDireccion > 0) {
                ResultSet rsDir = Conexion.buscarPorId("direccion", "id_direccion", idDireccion);
                if (rsDir != null && rsDir.next()) {
                    txtCalleP.setText(rsDir.getString("calle"));
                    txtNumeroP.setText(rsDir.getString("numero"));
                    txtColoniaP.setText(rsDir.getString("colonia"));
                    txtCiudadP.setText(rsDir.getString("ciudad"));
                    txtCPp.setText(rsDir.getString("cpostal"));
                    txtEstadoP.setText(rsDir.getString("estado"));
                    txtPaisP.setText(rsDir.getString("pais"));
                }
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
}


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        sideMenu = new menulateral.SideMenuComponent();
        txtColoniaP = new javax.swing.JTextField();
        txtCiudadP = new javax.swing.JTextField();
        txtCPp = new javax.swing.JTextField();
        txtEstadoP = new javax.swing.JTextField();
        txtPaisP = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        txtNombre = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        txtRFC = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        jLabel53 = new javax.swing.JLabel();
        txtTelefono = new javax.swing.JTextField();
        jLabel54 = new javax.swing.JLabel();
        txtCorreo = new javax.swing.JTextField();
        jLabel55 = new javax.swing.JLabel();
        txtBanco = new javax.swing.JTextField();
        txtClabe = new javax.swing.JTextField();
        jLabel57 = new javax.swing.JLabel();
        txtCalleP = new javax.swing.JTextField();
        txtNumeroP = new javax.swing.JTextField();
        jLabel22 = new javax.swing.JLabel();
        btnRefrescar = new javax.swing.JButton();
        jLabel23 = new javax.swing.JLabel();
        txtCaptcha = new javax.swing.JTextField();
        captchaPanel = new CaptchaPanel();
        btnGuardar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(110, 143, 133));

        sideMenu.setBackgroundColor(new java.awt.Color(228, 255, 212));
        sideMenu.setHoverColor(new java.awt.Color(228, 255, 212));
        sideMenu.setModel(new menulateral.SideMenuModel() {{ addItem(new menulateral.SideMenuItem("Inicio", "C:\\Users\\ayele\\Downloads\\hogar.png", "Ir a Inicio")); addItem(new menulateral.SideMenuItem("Productos", "C:\\Users\\ayele\\Downloads\\abarrotes-tienda.png", "Ir al almacén")); addItem(new menulateral.SideMenuItem("Proveedores", "C:\\Users\\ayele\\Downloads\\gestion-de-la-cadena-de-suministro.png", "Ir a proveedores ")); addItem(new menulateral.SideMenuItem("Compras", "C:\\Users\\ayele\\Downloads\\agregar-producto.png", "Ir a realizar compras")); addItem(new menulateral.SideMenuItem("Ventas", "C:\\Users\\ayele\\Downloads\\carrito-de-compras (1).png", "Ir a realizar ventas ")); addItem(new menulateral.SideMenuItem("Configuración", "C:\\Users\\ayele\\Downloads\\configuracion-del-usuario.png", "Ir a configuración")); menulateral.SideMenuItem item2125 = getItem(5); menulateral.SideMenuItem item2507 = new menulateral.SideMenuItem("Mi Perfil", "C:\\Users\\ayele\\Downloads\\avatar-de-usuario.png", "Ir a mi perfil"); item2125.addChild(item2507); addItem(new menulateral.SideMenuItem("Ayuda", "C:\\Users\\ayele\\Downloads\\ayuda.png", "Ayuda")); addItem(new menulateral.SideMenuItem("Salir", "C:\\Users\\ayele\\Downloads\\cerrar sesion (1).png", "Ir a login")); }});

        txtCPp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCPpActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        jLabel5.setText("Nombre Comercial");

        jLabel6.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        jLabel6.setText("Telefono");

        jLabel7.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        jLabel7.setText("Correo");

        jLabel8.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        jLabel8.setText("RFC");

        jLabel9.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        jLabel9.setText("Banco");

        jLabel10.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        jLabel10.setText("Clabe");

        jLabel2.setFont(new java.awt.Font("Perpetua", 0, 18)); // NOI18N
        jLabel2.setText("EDITAR PROVEEDOR");

        jLabel11.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        jLabel11.setText("DIRECCION");

        txtNombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNombreActionPerformed(evt);
            }
        });

        jLabel12.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        jLabel12.setText("Calle");

        jLabel13.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        jLabel13.setText("Numero");

        jLabel14.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        jLabel14.setText("Colonia");

        jLabel53.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        jLabel53.setText("CodigoPostal");

        jLabel54.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        jLabel54.setText("Estado");

        jLabel55.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        jLabel55.setText("Ciudad");

        jLabel57.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        jLabel57.setText("Pais");

        txtCalleP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCallePActionPerformed(evt);
            }
        });

        jLabel22.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        jLabel22.setText("Introducir captcha");

        btnRefrescar.setBackground(new java.awt.Color(237, 198, 142));
        btnRefrescar.setText("Refrescar");
        btnRefrescar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRefrescarActionPerformed(evt);
            }
        });

        jLabel23.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        jLabel23.setText("Captcha");

        javax.swing.GroupLayout captchaPanelLayout = new javax.swing.GroupLayout(captchaPanel);
        captchaPanel.setLayout(captchaPanelLayout);
        captchaPanelLayout.setHorizontalGroup(
            captchaPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 180, Short.MAX_VALUE)
        );
        captchaPanelLayout.setVerticalGroup(
            captchaPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
        );

        btnGuardar.setBackground(new java.awt.Color(237, 198, 142));
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(sideMenu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(42, 42, 42)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtClabe, javax.swing.GroupLayout.PREFERRED_SIZE, 245, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(txtNombre)
                                        .addComponent(txtRFC)
                                        .addComponent(txtTelefono)
                                        .addComponent(txtCorreo)
                                        .addComponent(txtBanco, javax.swing.GroupLayout.PREFERRED_SIZE, 245, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(6, 6, 6)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 72, Short.MAX_VALUE)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(txtCalleP, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 226, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(txtNumeroP, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 226, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(txtColoniaP, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 226, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(txtCiudadP, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 226, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(txtCPp, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 226, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(txtEstadoP, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 226, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                            .addGap(6, 6, 6)
                                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(jLabel53, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(jLabel54, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel55, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(92, 92, 92))))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(captchaPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(btnRefrescar))
                                    .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtCaptcha, javax.swing.GroupLayout.PREFERRED_SIZE, 277, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtPaisP, javax.swing.GroupLayout.PREFERRED_SIZE, 226, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel57, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnGuardar, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(101, 101, 101))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 196, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(243, 243, 243))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(sideMenu, javax.swing.GroupLayout.DEFAULT_SIZE, 733, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel11)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(11, 11, 11)
                        .addComponent(jLabel5))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel12)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtCalleP, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(7, 7, 7)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(jLabel13))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtRFC, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtNumeroP, javax.swing.GroupLayout.DEFAULT_SIZE, 36, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(jLabel14))
                .addGap(8, 8, 8)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtTelefono, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtColoniaP, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(8, 8, 8)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(jLabel55))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtCorreo, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtCiudadP, javax.swing.GroupLayout.DEFAULT_SIZE, 37, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(jLabel53))
                .addGap(7, 7, 7)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtCPp)
                    .addComponent(txtBanco, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(19, 19, 19)
                        .addComponent(jLabel10)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtClabe, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel54)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtEstadoP, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(15, 15, 15)
                .addComponent(jLabel57)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel23)
                        .addGap(3, 3, 3)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnRefrescar)
                            .addComponent(captchaPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(txtPaisP, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel22)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtCaptcha, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(btnGuardar, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtCPpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCPpActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCPpActionPerformed

    private void txtNombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNombreActionPerformed

    private void txtCallePActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCallePActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCallePActionPerformed

    private void btnRefrescarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRefrescarActionPerformed
        // TODO add your handling code here:
        captchaPanel.generarCaptcha(); // método de tu clase captcha que genera nueva imagen
        txtCaptcha.setText(""); // limpiar campo de texto
    }//GEN-LAST:event_btnRefrescarActionPerformed

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
                                             
   try {
        // --- 1️⃣ Validar campos obligatorios ---
        if (txtRFC.getText().trim().isEmpty() || txtNombre.getText().trim().isEmpty() ||
            txtTelefono.getText().trim().isEmpty() || txtCorreo.getText().trim().isEmpty() ||
            txtCalleP.getText().trim().isEmpty() || txtNumeroP.getText().trim().isEmpty() ||
            txtColoniaP.getText().trim().isEmpty() || txtCiudadP.getText().trim().isEmpty() ||
            txtCPp.getText().trim().isEmpty() || txtEstadoP.getText().trim().isEmpty() ||
            txtPaisP.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "⚠️ Por favor completa todos los campos obligatorios.");
            return;
        }

        // --- 2️⃣ Validar CAPTCHA ---
        String captchaIngresado = txtCaptcha.getText().trim();
        if (!captchaIngresado.equals(captchaPanel.getCodigo())) {
            JOptionPane.showMessageDialog(this, "❌ Código CAPTCHA incorrecto. No se guardarán los cambios.");
            return;
        }

        // --- 3️⃣ Validar RFC ---
        String rfc = txtRFC.getText().trim().toUpperCase();
        if (!rfc.matches("[A-ZÑ&]{3,4}[0-9]{6}[A-Z0-9]{3}")) {
            JOptionPane.showMessageDialog(this, "⚠️ RFC inválido. Debe ser alfanumérico y 13 caracteres válidos, sin espacios ni símbolos especiales.");
            return;
        }

        // --- 4️⃣ Validar nombre comercial ---
        String nombreComercial = txtNombre.getText().trim();
        if (nombreComercial.length() > 100 || !nombreComercial.matches("[A-Za-z0-9 ]{1,100}")) {
            JOptionPane.showMessageDialog(this, "⚠️ Nombre comercial inválido. Máximo 100 caracteres, solo letras, números y espacios, sin símbolos ni espacios al inicio/final.");
            return;
        }

        // --- 5️⃣ Validar teléfono ---
        String telefono = txtTelefono.getText().trim();
        if (!telefono.matches("\\d+")) {
            JOptionPane.showMessageDialog(this, "⚠️ Teléfono inválido. Solo números, sin espacios ni símbolos.");
            return;
        }

        // --- 6️⃣ Validar CLABE ---
        String clabe = txtClabe.getText().trim();
        if (!clabe.matches("\\d{18}")) {
            JOptionPane.showMessageDialog(this, "⚠️ CLABE inválida. Debe tener 18 dígitos numéricos, sin espacios ni símbolos.");
            return;
        }

        // --- 7️⃣ Validar dirección ---
        String calle = txtCalleP.getText().trim();
        String numero = txtNumeroP.getText().trim();
        String colonia = txtColoniaP.getText().trim();
        String ciudad = txtCiudadP.getText().trim();
        String cpostal = txtCPp.getText().trim();
        String estado = txtEstadoP.getText().trim();
        String pais = txtPaisP.getText().trim();

        if (!calle.matches("[A-Za-z0-9 ]{1,100}") || !numero.matches("\\d+")
                || !colonia.matches("[A-Za-z0-9 ]{1,100}") || !ciudad.matches("[A-Za-z ]{1,100}")
                || !cpostal.matches("\\d{4,10}") || !estado.matches("[A-Za-z ]{1,100}") 
                || !pais.matches("[A-Za-z ]{1,100}")) {
            JOptionPane.showMessageDialog(this, "⚠️ Dirección inválida. Verifica caracteres, longitud y números correctos.");
            return;
        }

        // --- 8️⃣ Guardar/actualizar dirección ---
        Map<String, Object> datosDireccion = new LinkedHashMap<>();
        datosDireccion.put("calle", calle);
        datosDireccion.put("numero", numero);
        datosDireccion.put("colonia", colonia);
        datosDireccion.put("ciudad", ciudad);
        datosDireccion.put("cpostal", cpostal);
        datosDireccion.put("estado", estado);
        datosDireccion.put("pais", pais);
        int idDireccion = 0;
        if (idDireccionActual > 0) {
            Conexion.actualizarPorCampo("direccion", datosDireccion, "id_direccion", idDireccionActual);
            idDireccion = idDireccionActual;
        } else {
            boolean exitoDir = Conexion.insertar(
                    "direccion",
                    "calle, numero, colonia, ciudad, cpostal, estado, pais",
                    "?, ?, ?, ?, ?, ?, ?",
                    calle, numero, colonia, ciudad, cpostal, estado, pais
            );
            if (!exitoDir) {
                JOptionPane.showMessageDialog(this, "❌ Error al guardar la dirección.");
                return;
            }
            idDireccion = Conexion.obtenerUltimoId();
        }

        // --- 9️⃣ Guardar/actualizar proveedor ---
        Map<String, Object> datosProveedor = new LinkedHashMap<>();
        datosProveedor.put("rfc", rfc);
        datosProveedor.put("nombre_comercial", nombreComercial);
        datosProveedor.put("telefono", telefono);
        datosProveedor.put("correo", txtCorreo.getText().trim());
        datosProveedor.put("banco", txtBanco.getText().trim());
        datosProveedor.put("clabe", clabe);
        datosProveedor.put("id_direccion", idDireccion);

        if (idProveedorActual > 0) {
            boolean exito = Conexion.actualizarPorCampo("proveedor", datosProveedor, "id_proveedor", idProveedorActual);
            if (exito) {
                JOptionPane.showMessageDialog(this, "✅ Proveedor actualizado correctamente.");
            } else {
                JOptionPane.showMessageDialog(this, "❌ Error al actualizar el proveedor.");
            }
        } else {
            boolean exito = Conexion.insertar(
                    "proveedor",
                    "rfc, nombre_comercial, telefono, correo, banco, clabe, id_direccion",
                    "?, ?, ?, ?, ?, ?, ?",
                    rfc, nombreComercial, telefono, txtCorreo.getText().trim(), txtBanco.getText().trim(), clabe, idDireccion
            );
            if (exito) {
                JOptionPane.showMessageDialog(this, "✅ Proveedor guardado correctamente.");
            } else {
                JOptionPane.showMessageDialog(this, "❌ Error al guardar el proveedor.");
            }
        }

    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "❌ Error inesperado: " + e.getMessage());
        e.printStackTrace();
    }

    }//GEN-LAST:event_btnGuardarActionPerformed

    /**
     * @param args the command line arguments
     */
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnRefrescar;
    private CaptchaPanel captchaPanel;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel53;
    private javax.swing.JLabel jLabel54;
    private javax.swing.JLabel jLabel55;
    private javax.swing.JLabel jLabel57;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private menulateral.SideMenuComponent sideMenu;
    private javax.swing.JTextField txtBanco;
    private javax.swing.JTextField txtCPp;
    private javax.swing.JTextField txtCalleP;
    private javax.swing.JTextField txtCaptcha;
    private javax.swing.JTextField txtCiudadP;
    private javax.swing.JTextField txtClabe;
    private javax.swing.JTextField txtColoniaP;
    private javax.swing.JTextField txtCorreo;
    private javax.swing.JTextField txtEstadoP;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtNumeroP;
    private javax.swing.JTextField txtPaisP;
    private javax.swing.JTextField txtRFC;
    private javax.swing.JTextField txtTelefono;
    // End of variables declaration//GEN-END:variables
}
