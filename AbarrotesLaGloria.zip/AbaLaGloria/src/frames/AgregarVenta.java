/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package frames;

import clases.Sesion;
import clases.SesionVenta;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import paquete.Conexion;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.Map;
import javax.swing.ImageIcon;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;
import menulateral.SideMenuItem;

/**
 *
 * @author ayele
 */
public class AgregarVenta extends javax.swing.JFrame {

    /**
     * Creates new form AgregarVenta
     */
    public AgregarVenta() {
        initComponents();
        cargarProductos();
        cargarMetodo();
        cargarCliente();
        inicializarComponentesAdicionales();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        txtFecha.setText(LocalDate.now().format(formatter));
        
        ImageIcon iconoA = new ImageIcon(getClass().getResource("/imagenes/abajo.png"));
        Image imagenAct = iconoA.getImage().getScaledInstance(32, 32, Image.SCALE_SMOOTH);
        ImageIcon iconoEditar = new ImageIcon(imagenAct);
        btnGuardarVenta.setIcon(iconoEditar);
        btnGuardarVenta.setText("Guardar Información");
        btnGuardarVenta.setHorizontalTextPosition(SwingConstants.RIGHT);  // Texto a la derecha del ícono
        btnGuardarVenta.setVerticalTextPosition(SwingConstants.CENTER);
        
        ImageIcon iconoB = new ImageIcon(getClass().getResource("/imagenes/quitar-del-carrito.png"));
        Image imagenQuitar = iconoB.getImage().getScaledInstance(32, 32, Image.SCALE_SMOOTH);
        ImageIcon iconoQuitarP = new ImageIcon(imagenQuitar);
        BtnQuitarProdu.setIcon(iconoQuitarP);
        BtnQuitarProdu.setText("Eliminar producto");
        BtnQuitarProdu.setHorizontalTextPosition(SwingConstants.RIGHT);  // Texto a la derecha del ícono
        BtnQuitarProdu.setVerticalTextPosition(SwingConstants.CENTER);
        
        ImageIcon iconoC = new ImageIcon(getClass().getResource("/imagenes/factura.png"));
        Image imagenT = iconoC.getImage().getScaledInstance(32, 32, Image.SCALE_SMOOTH);
        ImageIcon iconoTicket = new ImageIcon(imagenT);
        btnTicket.setIcon(iconoTicket);
        btnTicket.setText("Imprimir ticket");
        btnTicket.setHorizontalTextPosition(SwingConstants.RIGHT);  // Texto a la derecha del ícono
        btnTicket.setVerticalTextPosition(SwingConstants.CENTER);
       
         // Obtener rol actual
int rol = Sesion.getRol();

// 🔹 Configurar visibilidad según el rol
for (SideMenuItem item : sideMenu.getModel().getItems()) {

    String nombre = item.getText();

    // Por defecto, todos visibles
    boolean visible = true;

    switch (rol) {
        case 1: // Admin
        case 2: // Gerente
            visible = true; // todos visibles
            break;

        case 3: // Cajero
            visible = nombre.equals("Ventas") ||
                      nombre.equals("Configuración") ||
                      nombre.equals("Ayuda") ||
                      nombre.equals("Salir");
            break;

        case 4: // Almacenista
            visible = nombre.equals("Productos") ||
                      nombre.equals("Configuración") ||
                      nombre.equals("Ayuda") ||
                      nombre.equals("Salir");
            break;
    }

    item.setShown(visible);
    item.setEnabled(visible);

    // 🔹 Caso especial: Configuración → Mi Perfil
    if ("Configuración".equals(nombre)) {
        for (SideMenuItem child : item.getChildren()) {
            if ("Mi Perfil".equals(child.getText())) {

                // Acción de "Mi Perfil"
                sideMenu.setMenuItemAction("Mi Perfil", e -> {
                    new MiPerfil().setVisible(true);
                    this.dispose();
                });

                // Ocultar si no debe verlo
                boolean visiblePerfil = (rol == 1 || rol == 2 || rol == 3 || rol == 4);
                child.setShown(visiblePerfil);
                child.setEnabled(visiblePerfil);
            }
        }
    }
}

// 🔹 Acciones generales de menú

sideMenu.setMenuItemAction("Inicio", e -> {
    
   if (rol == 1) {
            new InicioAdmin().setVisible(true);
        } else {
            new InicioGene().setVisible(true);
        }
        this.dispose();
});


sideMenu.setMenuItemAction("Productos", e -> {
    new Producto().setVisible(true);
    this.dispose();
});

sideMenu.setMenuItemAction("Proveedores", e -> {
    new Proveedor().setVisible(true);
    this.dispose();
});

sideMenu.setMenuItemAction("Compras", e -> {
    new Compra().setVisible(true);
    this.dispose();
});

sideMenu.setMenuItemAction("Ventas", e -> {
    new Venta().setVisible(true);
    this.dispose();
});

sideMenu.setMenuItemAction("Ayuda", e -> {
    new Ayuda().setVisible(true);
    this.dispose();
});

sideMenu.setMenuItemAction("Salir", e -> {
    new Login().setVisible(true);
    this.dispose();
});        


    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        sideMenu = new menulateral.SideMenuComponent();
        jLabel10 = new javax.swing.JLabel();
        txtPrecio = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        BtnQuitarProdu = new javax.swing.JButton();
        txtNombre = new javax.swing.JTextField();
        btnTicket = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        txtMarcaProdu = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txtStockProdu = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        txtCantiProdu = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        txtSubProdu = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        txtTotalProdu = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaDeVenta = new javax.swing.JTable();
        jLabel9 = new javax.swing.JLabel();
        txtFecha = new javax.swing.JTextField();
        btnGuardarVenta = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        tablaDeProductos = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtIdPrdu = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        txtStockMin = new javax.swing.JTextField();
        txtIdVenta = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        cmbMetodo = new javax.swing.JComboBox<>();
        Cliente = new javax.swing.JLabel();
        cmbCliente = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(110, 143, 133));

        sideMenu.setBackgroundColor(new java.awt.Color(228, 255, 212));
        sideMenu.setHoverColor(new java.awt.Color(228, 255, 212));
        sideMenu.setModel(new menulateral.SideMenuModel() {{ addItem(new menulateral.SideMenuItem("Inicio", "C:\\Users\\ayele\\Downloads\\hogar.png", "Ir a Inicio")); addItem(new menulateral.SideMenuItem("Productos", "C:\\Users\\ayele\\Downloads\\abarrotes-tienda.png", "Ir al almacén")); addItem(new menulateral.SideMenuItem("Proveedores", "C:\\Users\\ayele\\Downloads\\gestion-de-la-cadena-de-suministro.png", "Ir a proveedores ")); addItem(new menulateral.SideMenuItem("Compras", "C:\\Users\\ayele\\Downloads\\agregar-producto.png", "Ir a realizar compras")); addItem(new menulateral.SideMenuItem("Ventas", "C:\\Users\\ayele\\Downloads\\carrito-de-compras (1).png", "Ir a realizar ventas ")); addItem(new menulateral.SideMenuItem("Configuración", "C:\\Users\\ayele\\Downloads\\configuracion-del-usuario.png", "Ir a configuración")); menulateral.SideMenuItem item5071 = getItem(5); menulateral.SideMenuItem item5936 = new menulateral.SideMenuItem("Mi Perfil", "C:\\Users\\ayele\\Downloads\\avatar-de-usuario.png", "Ir a mi perfil"); item5071.addChild(item5936); addItem(new menulateral.SideMenuItem("Ayuda", "C:\\Users\\ayele\\Downloads\\ayuda.png", "Ayuda")); addItem(new menulateral.SideMenuItem("Salir", "C:\\Users\\ayele\\Downloads\\cerrar sesion (1).png", "Ir a login")); }});

        jLabel10.setText("Precio");

        txtPrecio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPrecioActionPerformed(evt);
            }
        });

        jLabel3.setText("Nombre");

        BtnQuitarProdu.setBackground(new java.awt.Color(237, 198, 142));
        BtnQuitarProdu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnQuitarProduActionPerformed(evt);
            }
        });

        btnTicket.setBackground(new java.awt.Color(237, 198, 142));
        btnTicket.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTicketActionPerformed(evt);
            }
        });

        jLabel4.setText("Marca");

        jLabel5.setText("Método de pago");

        jLabel6.setText("Cantidad");

        txtCantiProdu.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtCantiProduKeyPressed(evt);
            }
        });

        jLabel7.setText("Subtotal");

        jLabel8.setText("Total");

        tablaDeVenta.setBackground(new java.awt.Color(235, 231, 167));
        tablaDeVenta.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID PRODUCTO", "NOMBRE", "CANTIDAD ", "PRECIO ", "SUBTOTAL"
            }
        ));
        jScrollPane1.setViewportView(tablaDeVenta);

        jLabel9.setText("Fecha");

        btnGuardarVenta.setBackground(new java.awt.Color(237, 198, 142));
        btnGuardarVenta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarVentaActionPerformed(evt);
            }
        });

        tablaDeProductos.setBackground(new java.awt.Color(235, 231, 167));
        tablaDeProductos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID PRODUCTO", "NOMBRE", "MARCA ", "STOCK", "PRECIO"
            }
        ));
        tablaDeProductos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaDeProductosMouseClicked(evt);
            }
        });
        tablaDeProductos.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                tablaDeProductosPropertyChange(evt);
            }
        });
        jScrollPane2.setViewportView(tablaDeProductos);

        jLabel1.setFont(new java.awt.Font("Segoe UI Historic", 1, 18)); // NOI18N
        jLabel1.setText("AGREGAR VENTA ");

        jLabel2.setText("ID del producto");

        jLabel11.setText("Stock");

        txtIdVenta.setBackground(new java.awt.Color(110, 143, 133));

        jLabel12.setText("Stock");

        cmbMetodo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        Cliente.setText("Cliente ");

        cmbCliente.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(sideMenu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 948, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 948, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(119, 119, 119)
                        .addComponent(btnGuardarVenta, javax.swing.GroupLayout.PREFERRED_SIZE, 186, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(115, 115, 115)
                        .addComponent(BtnQuitarProdu, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(106, 106, 106)
                        .addComponent(btnTicket, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(49, 49, 49)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(txtIdVenta, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(293, 293, 293)
                                .addComponent(jLabel1))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                .addComponent(txtIdPrdu, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addComponent(txtCantiProdu, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addGap(38, 38, 38)
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addGap(29, 29, 29)
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(txtMarcaProdu, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addGap(38, 38, 38)
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(txtStockProdu, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addGap(18, 18, 18)
                                                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(txtSubProdu, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(18, 18, 18)
                                                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(txtTotalProdu, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(27, 27, 27)
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(txtFecha, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(29, 29, 29)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(cmbMetodo, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(227, 227, 227)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(txtStockMin, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(41, 41, 41)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(txtPrecio, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(Cliente, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(cmbCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE))))))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(sideMenu, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtIdVenta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(8, 8, 8)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3)
                            .addComponent(jLabel4)
                            .addComponent(jLabel5)
                            .addComponent(jLabel11)
                            .addComponent(jLabel10)
                            .addComponent(jLabel12))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtIdPrdu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtMarcaProdu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtStockProdu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtStockMin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtPrecio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cmbMetodo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(26, 26, 26)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(jLabel9)
                            .addComponent(Cliente))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(txtCantiProdu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(txtSubProdu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel8)
                                .addComponent(txtTotalProdu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(txtFecha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(cmbCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(33, 33, 33)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 249, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 249, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(32, 32, 32)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(BtnQuitarProdu, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnTicket, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnGuardarVenta, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1057, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

     private void cargarMetodo() {
    try {
        // Limpiar cualquier ítem previo del JComboBox
        cmbMetodo.removeAllItems();

        // Usar la clase Conexion para obtener todos los roles
        ResultSet rs = Conexion.consultarTodo("metodo_pago");

        // Agregar los roles al JComboBox
        while (rs != null && rs.next()) {
            cmbMetodo.addItem(rs.getString("nombre_metodo"));
        }

      

    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Error al cargar los metodos: " + e.getMessage());
    }
}
     
        private void inicializarComponentesAdicionales() {
    txtIdVenta = new javax.swing.JTextField();
    txtIdVenta.setVisible(true); // Lo hacemos invisible
    txtNombre.add(txtIdVenta); // Lo agregamos al panel principal
}
    private void txtPrecioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPrecioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPrecioActionPerformed

   private void cargarCliente() {
    try {
        // Limpiar cualquier ítem previo del JComboBox
        cmbCliente.removeAllItems();

        // Agregar opción para "Público en general"
        cmbCliente.addItem("Público en general");

        // Usar la clase Conexion para obtener todos los clientes
        ResultSet rs = Conexion.consultarTodo("cliente");

        // Agregar los clientes al JComboBox
        while (rs != null && rs.next()) {
            String nombreCliente = rs.getString("nombre");
            cmbCliente.addItem(nombreCliente);
        }

    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Error al cargar los clientes: " + e.getMessage());
    }
}


   private void agregarProductoATabla() {
    try {
        // 1) Leer y normalizar entradas (evitar caracteres extraños)
        String sId = txtIdPrdu.getText().trim();
        String sNombre = txtNombre.getText().trim();
        String sCantidad = txtCantiProdu.getText().trim();
        String sStock = txtStockProdu.getText().trim();
        String sPrecio = txtPrecio.getText().trim();

        // 1.1) Validar no vacíos
        if (sId.isEmpty() || sNombre.isEmpty() || sCantidad.isEmpty() || sStock.isEmpty() || sPrecio.isEmpty()) {
            JOptionPane.showMessageDialog(this, "⚠️ Debes llenar todos los campos antes de agregar el producto.");
            return;
        }

        // 2) Validar y parsear numéricos con mensajes claros
        int idProducto;
        int cantidad;
        int stockBD;
        double precio;
        try {
            idProducto = Integer.parseInt(sId);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "⚠️ ID de producto inválido: " + sId);
            return;
        }
        try {
            cantidad = Integer.parseInt(sCantidad);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "⚠️ Cantidad inválida: " + sCantidad);
            return;
        }
        try {
            stockBD = Integer.parseInt(sStock);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "⚠️ Stock inválido: " + sStock);
            return;
        }
        try {
            // permitir formatos con coma o punto en precio
            String sp = sPrecio.replace(",", ".");
            precio = Double.parseDouble(sp);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "⚠️ Precio inválido: " + sPrecio);
            return;
        }

        if (cantidad <= 0) {
            JOptionPane.showMessageDialog(this, "⚠️ La cantidad debe ser mayor a cero.");
            return;
        }

        // 3) Consultar BD para obtener stock/estado real — corregir nombre de tabla si hace falta
        // OJO: unifica el nombre de tu tabla, aquí uso "producto" (ajusta si tu tabla se llama "productos")
        ResultSet rs = Conexion.buscarPorId("producto", "id_producto", idProducto);
        if (rs == null || !rs.next()) {
            JOptionPane.showMessageDialog(this, "❌ No se encontró el producto en la base de datos (ID: " + idProducto + ").");
            return;
        }

        String nombreBD = rs.getString("nombre");
        int estado = rs.getInt("estatus");
        int stockRealBD = rs.getInt("stock");

        if (estado == 0) {
            JOptionPane.showMessageDialog(this, "🚫 El producto está inactivo o suspendido.");
            return;
        }

        // usar el stock que viene de BD como referencia absoluta
        if (cantidad > stockRealBD) {
            JOptionPane.showMessageDialog(this,
                "⚠️ La cantidad (" + cantidad + ") supera el stock disponible (" + stockRealBD + ").",
                "Stock insuficiente", JOptionPane.WARNING_MESSAGE);

            String mensaje = "El producto '" + nombreBD + "' (ID " + idProducto + ") tiene stock insuficiente (" + stockRealBD + " unidades).";
            registrarAlertaStock(idProducto, mensaje);
            return;
        }

        if (stockRealBD <= 5) {
            String mensaje = "El producto '" + nombreBD + "' tiene stock bajo (" + stockRealBD + " unidades).";
            registrarAlertaStock(idProducto, mensaje);
            // no retornamos; permitimos agregar si hay stock
        }

        // 6) Calcular subtotal para la cantidad que se agrega ahora
        double subtotalAgregar = cantidad * precio;

        // 7) Agregar/actualizar fila en tabla de venta (carrito)
        DefaultTableModel modeloVenta = (DefaultTableModel) tablaDeVenta.getModel();
        boolean yaExiste = false;

        for (int i = 0; i < modeloVenta.getRowCount(); i++) {
            int idExistente = Integer.parseInt(modeloVenta.getValueAt(i, 0).toString());
            if (idExistente == idProducto) {
                int cantActual = Integer.parseInt(modeloVenta.getValueAt(i, 2).toString());
                int nuevaCant = cantActual + cantidad;

                if (nuevaCant > stockRealBD) {
                    JOptionPane.showMessageDialog(this,
                        "⚠️ La cantidad total (" + nuevaCant + ") supera el stock disponible (" + stockRealBD + ").");
                    return;
                }

                modeloVenta.setValueAt(nuevaCant, i, 2);
                modeloVenta.setValueAt(String.format("%.2f", nuevaCant * precio), i, 4);
                yaExiste = true;
                break;
            }
        }

        if (!yaExiste) {
            modeloVenta.addRow(new Object[]{idProducto, nombreBD, cantidad, precio, String.format("%.2f", subtotalAgregar)});
        }

        // 8) Recalcular total general (usar valores del modelo)
        double total = 0.0;
        for (int i = 0; i < modeloVenta.getRowCount(); i++) {
            String sSub = modeloVenta.getValueAt(i, 4).toString().replace(",", ".");
            try {
                total += Double.parseDouble(sSub);
            } catch (NumberFormatException ex) {
                // si algo raro está en la celda, saltar y registrar
                System.err.println("Subtotal inválido en fila " + i + ": " + sSub);
            }
        }
        txtTotalProdu.setText(String.format("%.2f", total));
        txtSubProdu.setText(String.format("%.2f", subtotalAgregar));

        // 9) Actualizar stock visible en tablaDeProductos (restar la cantidad agregada)
        DefaultTableModel modeloProductos = (DefaultTableModel) tablaDeProductos.getModel();
        for (int i = 0; i < modeloProductos.getRowCount(); i++) {
            int idTabla = Integer.parseInt(modeloProductos.getValueAt(i, 0).toString());
            if (idTabla == idProducto) {
                int stockVisible = Integer.parseInt(modeloProductos.getValueAt(i, 3).toString());
                modeloProductos.setValueAt(stockVisible - cantidad, i, 3);
                break;
            }
        }

        // 10) Limpiar campo cantidad (no borrar datos del producto seleccionado)
        txtCantiProdu.setText("");

    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(this, "❌ Error al agregar producto (SQL): " + ex.getMessage());
        ex.printStackTrace();
    } catch (Exception ex) {
        JOptionPane.showMessageDialog(this, "⚠️ Error inesperado: " + ex.getMessage());
        ex.printStackTrace();
    }
}


private void registrarAlertaStock(int idProducto, String mensaje) {
    try {
        String tabla = "alerta_stock";
        String columnas = "id_producto, mensaje, atendida";
        String valores = "?, ?, ?";

        boolean insertado = Conexion.insertar(tabla, columnas, valores, idProducto, mensaje, 0);

        if (insertado) {
            JOptionPane.showMessageDialog(this,
                "📦 Se registró una alerta en el almacén:\n" + mensaje,
                "Alerta de Stock", JOptionPane.INFORMATION_MESSAGE);
        } else {
            System.err.println("No se pudo insertar alerta_stock para id " + idProducto);
        }
    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "❌ Error al registrar alerta: " + e.getMessage());
        e.printStackTrace();
    }
}


 private void recalcularTotales() {
    DefaultTableModel modeloVenta = (DefaultTableModel) tablaDeVenta.getModel();
    double total = 0.0;
    
    for (int i = 0; i < modeloVenta.getRowCount(); i++) {
        int cantidad = Integer.parseInt(modeloVenta.getValueAt(i, 2).toString());
        double precio = Double.parseDouble(modeloVenta.getValueAt(i, 3).toString());
        double subtotal = cantidad * precio;
        total += subtotal;
    }
    
    // Si hay productos, mostrar subtotal del último (opcional)
    if (modeloVenta.getRowCount() > 0) {
        int ultimaFila = modeloVenta.getRowCount() - 1;
        int cantidad = Integer.parseInt(modeloVenta.getValueAt(ultimaFila, 2).toString());
        double precio = Double.parseDouble(modeloVenta.getValueAt(ultimaFila, 3).toString());
        txtSubProdu.setText(String.format("%.2f", cantidad * precio));
    } else {
        txtSubProdu.setText("0.00");
    }
    
    txtTotalProdu.setText(String.format("%.2f", total));
    }


    private void BtnQuitarProduActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnQuitarProduActionPerformed
        // TODO add your handling code here:
        int filaSeleccionada = tablaDeVenta.getSelectedRow();

        if (filaSeleccionada == -1) {
            JOptionPane.showMessageDialog(this, "Por favor seleccione un producto para quitar", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            // Obtener datos del producto a quitar
            int idProducto = Integer.parseInt(tablaDeVenta.getValueAt(filaSeleccionada, 0).toString());
            int cantidad = Integer.parseInt(tablaDeVenta.getValueAt(filaSeleccionada, 2).toString());

            // Quitar de la tabla de venta
            DefaultTableModel modeloVenta = (DefaultTableModel) tablaDeVenta.getModel();
            modeloVenta.removeRow(filaSeleccionada);

            // Actualizar el stock en la tabla de productos (sumar la cantidad devuelta)
            DefaultTableModel modeloProductos = (DefaultTableModel) tablaDeProductos.getModel();
            for (int i = 0; i < modeloProductos.getRowCount(); i++) {
                int idTabla = Integer.parseInt(modeloProductos.getValueAt(i, 0).toString());
                if (idTabla == idProducto) {
                    int stockActual = Integer.parseInt(modeloProductos.getValueAt(i, 3).toString());
                    modeloProductos.setValueAt(stockActual + cantidad, i, 3);
                    break;
                }
            }

            // Recalcular totales
            recalcularTotales();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al quitar producto: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_BtnQuitarProduActionPerformed

    private void btnTicketActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTicketActionPerformed
        // TODO add your handling code here:
                                         

    // 1️⃣ Validar que haya una venta registrada
    int idVenta = SesionVenta.getUltimoIdVenta(); // ← OBTIENE EL ÚLTIMO ID REGISTRADO

    if (idVenta <= 0) {
        JOptionPane.showMessageDialog(this,
            "No hay una venta registrada recientemente.\nPor favor registre una venta primero.",
            "Advertencia", JOptionPane.WARNING_MESSAGE);
        return;
    }

    try {
        // 2️⃣ Obtener datos principales de la venta
        ResultSet rsVenta = Conexion.buscarPorCampos(
            "venta", 
            new String[]{"id_venta"}, 
            new Object[]{idVenta}
        );

        if (rsVenta == null || !rsVenta.next()) {
            JOptionPane.showMessageDialog(this, 
                "No se encontró la venta con ID: " + idVenta, 
                "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String fecha = rsVenta.getString("fecha");
        double totalVenta = rsVenta.getDouble("total");

        // 3️⃣ Obtener el cambio guardado en memoria
        double cambio = SesionVenta.getCambioVenta();

        // 4️⃣ Obtener detalles de la venta
        ResultSet rsDetalles = Conexion.buscarPorCampos(
            "detalle_venta", 
            new String[]{"id_venta"}, 
            new Object[]{idVenta}
        );

        if (rsDetalles == null || !rsDetalles.isBeforeFirst()) {
            JOptionPane.showMessageDialog(this, 
                "La venta existe pero no tiene productos asociados", 
                "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // 5️⃣ Construir ticket
        StringBuilder ticket = new StringBuilder();
        ticket.append("============ TICKET DE VENTA ============\n");
        ticket.append("N° Venta: ").append(idVenta).append("\n");
        ticket.append("Fecha: ").append(fecha).append("\n");
        ticket.append("=========================================\n");
        ticket.append(String.format("%-5s %-20s %-8s %-10s\n", 
                "Cant.", "Producto", "P.Unit", "Subtotal"));

        while (rsDetalles.next()) {
            int idProducto = rsDetalles.getInt("id_producto");
            int cantidad = rsDetalles.getInt("cantidad");
            double pUnit = rsDetalles.getDouble("precio_unitario");
            double subtotal = rsDetalles.getDouble("subtotal");

            // Obtener nombre del producto desde BD
            ResultSet rsProducto = Conexion.buscarPorCampos(
                "producto", 
                new String[]{"id_producto"}, 
                new Object[]{idProducto}
            );

            String nombre = "Desconocido";
            if (rsProducto != null && rsProducto.next()) {
                nombre = rsProducto.getString("nombre");
            }

            ticket.append(String.format("%-5d %-20s $%-7.2f $%-9.2f\n", 
                    cantidad, nombre, pUnit, subtotal));
        }

        ticket.append("=========================================\n");
        ticket.append(String.format("TOTAL:  $%.2f\n", totalVenta));
        ticket.append(String.format("CAMBIO: $%.2f\n", cambio)); // ← SE AGREGA AL TICKET
        ticket.append("=========================================\n");

        // 6️⃣ Mostrar ticket
        JTextArea textArea = new JTextArea(ticket.toString());
        textArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new Dimension(400, 400));
        JOptionPane.showMessageDialog(this, scrollPane, 
                "Ticket de Venta #" + idVenta, 
                JOptionPane.INFORMATION_MESSAGE);

    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, 
                "Error al generar ticket: " + e.getMessage(), 
                "Error", JOptionPane.ERROR_MESSAGE);
        e.printStackTrace();
    }

    }//GEN-LAST:event_btnTicketActionPerformed

    private void txtCantiProduKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCantiProduKeyPressed
        // TODO add your handling code here:
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
        if (!txtCantiProdu.getText().trim().isEmpty()) {
            agregarProductoATabla();
        } else {
            JOptionPane.showMessageDialog(this, "⚠️ Ingresa una cantidad antes de continuar.");
        }
    }

    }//GEN-LAST:event_txtCantiProduKeyPressed

    private void btnGuardarVentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarVentaActionPerformed
        // TODO add your handling code here                                               
    if (tablaDeVenta.getRowCount() == 0) {
    JOptionPane.showMessageDialog(this, "No hay productos agregados a la venta", "Error", JOptionPane.ERROR_MESSAGE);
    return;
}

try {
    // Validar total de venta
    double total;
    try {
        total = Double.parseDouble(txtTotalProdu.getText().trim());
        if (total <= 0) {
            JOptionPane.showMessageDialog(this, "El total de la venta debe ser mayor a 0.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(this, "Total de venta inválido.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    Conexion.iniciarTransaccion(); // Inicia transacción

    int idUsuario = Sesion.getIdUsuario();
    Integer idCliente = null; 
    String clienteSeleccionado = cmbCliente.getSelectedItem().toString().trim();

    // Validar cliente
    if (!clienteSeleccionado.equals("Público en general")) {
        ResultSet rsCliente = Conexion.buscarPorCampos("cliente", new String[]{"nombre"}, new Object[]{clienteSeleccionado});
        if (rsCliente != null && rsCliente.next()) {
            idCliente = rsCliente.getInt("id_cliente");
        } else {
            JOptionPane.showMessageDialog(this, "Cliente seleccionado no existe.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
    }

    // Validar método de pago
    if (cmbMetodo.getSelectedIndex() < 0) {
        JOptionPane.showMessageDialog(this, "Debe seleccionar un método de pago.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }
    String metodoPago = cmbMetodo.getSelectedItem().toString().trim();
    ResultSet rsMetodo = Conexion.buscarPorCampos("metodo_pago", new String[]{"nombre_metodo"}, new Object[]{metodoPago});
    int idMetodoPago = -1;
    if (rsMetodo != null && rsMetodo.next()) {
        idMetodoPago = rsMetodo.getInt("id_metodo_pago");
    } else {
        JOptionPane.showMessageDialog(this, "Método de pago no válido.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    // Insertar venta
    boolean ventaInsertada = Conexion.insertar(
        "venta",
        "id_usuario, id_cliente, id_metodo_pago, fecha, total",
        "?, ?, ?, ?, ?",
        idUsuario,
        idCliente,
        idMetodoPago,
        txtFecha.getText(),
        total
    );

    if (!ventaInsertada) throw new Exception("Error al insertar la venta.");

    int idVenta = Conexion.obtenerUltimoId();
    txtIdVenta.setText(String.valueOf(idVenta));
    SesionVenta.setUltimoIdVenta(idVenta);

    DefaultTableModel modeloVenta = (DefaultTableModel) tablaDeVenta.getModel();
    for (int i = 0; i < modeloVenta.getRowCount(); i++) {
        int idProducto = Integer.parseInt(modeloVenta.getValueAt(i, 0).toString());

        // Validar cantidad
        int cantidad;
        try {
            cantidad = Integer.parseInt(modeloVenta.getValueAt(i, 2).toString());
            if (cantidad <= 0) {
                throw new NumberFormatException("Cantidad debe ser mayor a 0.");
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Cantidad inválida en fila " + (i+1) + ": " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            Conexion.revertirTransaccion();
            return;
        }

        // Validar precio unitario
        double precioUnitario;
        try {
            precioUnitario = Double.parseDouble(modeloVenta.getValueAt(i, 3).toString());
            if (precioUnitario < 0) {
                throw new NumberFormatException("Precio unitario no puede ser negativo.");
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Precio unitario inválido en fila " + (i+1) + ": " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            Conexion.revertirTransaccion();
            return;
        }

        // Validar subtotal
        double subtotal;
        try {
            subtotal = Double.parseDouble(modeloVenta.getValueAt(i, 4).toString());
            if (subtotal < 0) {
                throw new NumberFormatException("Subtotal no puede ser negativo.");
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Subtotal inválido en fila " + (i+1) + ": " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            Conexion.revertirTransaccion();
            return;
        }

        // Insertar detalle venta
        Conexion.insertar(
            "detalle_venta",
            "id_venta, id_producto, cantidad, precio_unitario, subtotal",
            "?, ?, ?, ?, ?",
            idVenta, idProducto, cantidad, precioUnitario, subtotal
        );

        // Actualizar stock
        ResultSet rs = Conexion.buscarPorCampos("producto", new String[]{"id_producto"}, new Object[]{idProducto});
        int stockActual = 0;
        if (rs != null && rs.next()) stockActual = rs.getInt("stock");
        int nuevoStock = stockActual - cantidad;
        if (nuevoStock < 0) {
            JOptionPane.showMessageDialog(this, "Stock insuficiente para el producto ID " + idProducto, "Error", JOptionPane.ERROR_MESSAGE);
            Conexion.revertirTransaccion();
            return;
        }
        Conexion.actualizar("producto", "stock = ?", "id_producto = ?", nuevoStock, idProducto);

        // Crear alerta si stock crítico
        if (nuevoStock <= 5) {
            Conexion.insertar("alerta_stock", "id_producto, mensaje, atendida", "?, ?, ?", idProducto, "Stock crítico producto " + idProducto, 0);
        }
    }

    Conexion.confirmarTransaccion(); // Commit

    // Abrir JDialog de PagoVenta
    PagoVenta pagoDialog = new PagoVenta(this, true, total, metodoPago);
    pagoDialog.setVisible(true);

    double pago = pagoDialog.getPago(); 
    double cambio = pago - total;
    SesionVenta.setCambioVenta(cambio);

    limpiarCampos();

} catch (Exception ex) {
    try { Conexion.revertirTransaccion(); } catch (SQLException e) { e.printStackTrace(); }
    JOptionPane.showMessageDialog(this, "Error al registrar la venta: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    ex.printStackTrace();
}

    }//GEN-LAST:event_btnGuardarVentaActionPerformed


private void limpiarCampos() {
    txtIdPrdu.setText("");
    txtNombre.setText("");
    txtMarcaProdu.setText("");
    txtStockProdu.setText("");
    txtCantiProdu.setText("");
    txtPrecio.setText("");
    txtSubProdu.setText("");
    txtTotalProdu.setText(""); 
    txtIdVenta.setText("");
    ((DefaultTableModel) tablaDeVenta.getModel()).setRowCount(0);
    cargarProductos(); // Refrescar la lista de productos con nuevos stocks
}
    
    private void cargarProductos() {
    DefaultTableModel modelo = (DefaultTableModel) tablaDeProductos.getModel();
    modelo.setRowCount(0);

    try {
        ResultSet rs = Conexion.consultarTodo("producto");
        while (rs != null && rs.next()) {
            modelo.addRow(new Object[]{
                rs.getInt("id_producto"),
                rs.getString("nombre"),
                rs.getString("marca"),
                rs.getInt("stock"),
                rs.getDouble("precio")
            });
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
}

    
    private void tablaDeProductosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaDeProductosMouseClicked
        // TODO add your handling code here:
        int fila = tablaDeProductos.getSelectedRow();
        if (fila != -1) {
            txtIdPrdu.setText(tablaDeProductos.getValueAt(fila, 0).toString());
            txtNombre.setText(tablaDeProductos.getValueAt(fila, 1).toString());
            txtMarcaProdu.setText(tablaDeProductos.getValueAt(fila, 2).toString());
            txtStockProdu.setText(tablaDeProductos.getValueAt(fila, 3).toString());
            txtPrecio.setText(tablaDeProductos.getValueAt(fila, 4).toString());
        }
        // 🔥 LLAMADA A LA VALIDACIÓN AUTOMÁTICA
        int idProducto = Integer.parseInt(txtIdPrdu.getText());
        validarStockYReabastecer(idProducto);
    }//GEN-LAST:event_tablaDeProductosMouseClicked

    private void validarStockYReabastecer(int idProducto) {
    try {
        ResultSet rs = Conexion.buscarPorCampos(
                "producto",
                new String[]{"id_producto"},
                new Object[]{idProducto}
        );

        if (rs == null || !rs.next()) return;

        int stock = rs.getInt("stock");
        int stockMinimo = rs.getInt("stock_minimo");
        int existencia = rs.getInt("stock_existencia");

        // 1) Si el stock es menor al mínimo → alerta
        if (stock < stockMinimo) {
            JOptionPane.showMessageDialog(this,
                "⚠ STOCK BAJO\n" +
                "Stock actual: " + stock + "\n" +
                "Stock mínimo: " + stockMinimo,
                "Alerta de stock",
                JOptionPane.WARNING_MESSAGE);

            int faltante = stockMinimo - stock;

            // 2) Reabastecer automáticamente desde existencia
            if (existencia >= faltante) {

                int nuevoStock = stock + faltante;
                int nuevaExistencia = existencia - faltante;

                // Actualizar BD
                Conexion.actualizar(
                        "producto",
                        "stock = ?, stock_existencia = ?",
                        "id_producto = ?",
                        nuevoStock, nuevaExistencia, idProducto
                );

                JOptionPane.showMessageDialog(this,
                        "✔ STOCK REABASTECIDO AUTOMÁTICAMENTE\n" +
                        "Nuevo stock: " + nuevoStock + "\n" +
                        "Existencia restante: " + nuevaExistencia);

                // Refrescar tabla
                cargarProductos();
            } else {
                JOptionPane.showMessageDialog(this,
                    "❌ EXISTENCIA INSUFICIENTE\n" +
                    "Existencia disponible: " + existencia,
                    "Reabastecimiento incompleto",
                    JOptionPane.ERROR_MESSAGE);
            }
        }

    } catch (Exception e) {
        JOptionPane.showMessageDialog(this,
                "Error al validar stock: " + e.getMessage());
    }
}

    private void tablaDeProductosPropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_tablaDeProductosPropertyChange
        // TODO add your handling code here:
    }//GEN-LAST:event_tablaDeProductosPropertyChange

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AgregarVenta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AgregarVenta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AgregarVenta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AgregarVenta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AgregarVenta().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BtnQuitarProdu;
    private javax.swing.JLabel Cliente;
    private javax.swing.JButton btnGuardarVenta;
    private javax.swing.JButton btnTicket;
    private javax.swing.JComboBox<String> cmbCliente;
    private javax.swing.JComboBox<String> cmbMetodo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private menulateral.SideMenuComponent sideMenu;
    private javax.swing.JTable tablaDeProductos;
    private javax.swing.JTable tablaDeVenta;
    private javax.swing.JTextField txtCantiProdu;
    private javax.swing.JTextField txtFecha;
    private javax.swing.JTextField txtIdPrdu;
    private javax.swing.JTextField txtIdVenta;
    private javax.swing.JTextField txtMarcaProdu;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtPrecio;
    private javax.swing.JTextField txtStockMin;
    private javax.swing.JTextField txtStockProdu;
    private javax.swing.JTextField txtSubProdu;
    private javax.swing.JTextField txtTotalProdu;
    // End of variables declaration//GEN-END:variables
}
