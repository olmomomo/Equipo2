/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package frames;

import clases.Sesion;
import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import menulateral.SideMenuItem;
import paquete.Conexion;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;


/**
 *
 * @author ayele
 */
public class AgregarProducto extends javax.swing.JFrame {

   private Map<String, Integer> mapaProveedores = new HashMap<>();
private Map<String, Integer> mapaTiposProducto = new HashMap<>();

    /**
     * Creates new form AgregarProducto
     */
    public AgregarProducto() {
        initComponents();
          cargarComboProveedores();
          cargarTiposProducto();
        ImageIcon icono=new ImageIcon(getClass().getResource("/imagenes/agregar-producto (1).png"));
        Image imagenEscalada=icono.getImage().getScaledInstance(40, 40, Image.SCALE_SMOOTH);
        ImageIcon iconoFinal = new ImageIcon(imagenEscalada);
        lblFondo.setIcon(iconoFinal);
        
        ImageIcon iconoA = new ImageIcon(getClass().getResource("/imagenes/abajo.png"));
        Image imagenAct = iconoA.getImage().getScaledInstance(32, 32, Image.SCALE_SMOOTH);
        ImageIcon iconoEditar = new ImageIcon(imagenAct);
        btnGuardar.setIcon(iconoEditar);
        btnGuardar.setText("Guardar Información");
        btnGuardar.setHorizontalTextPosition(SwingConstants.RIGHT);  // Texto a la derecha del ícono
        btnGuardar.setVerticalTextPosition(SwingConstants.CENTER);
        
         // Obtener rol actual
int rol = Sesion.getRol();

// 🔹 Configurar visibilidad según el rol
for (SideMenuItem item : sideMenu.getModel().getItems()) {

    String nombre = item.getText();

    // Por defecto, todos visibles
    boolean visible = true;

    switch (rol) {
        case 1: // Admin
        case 2: // Gerente
            visible = true; // todos visibles
            break;

        case 3: // Cajero
            visible = nombre.equals("Ventas") ||
                      nombre.equals("Configuración") ||
                      nombre.equals("Ayuda") ||
                      nombre.equals("Salir");
            break;

        case 4: // Almacenista
            visible = nombre.equals("Productos") ||
                      nombre.equals("Configuración") ||
                      nombre.equals("Ayuda") ||
                      nombre.equals("Salir");
            break;
    }

    item.setShown(visible);
    item.setEnabled(visible);

    // 🔹 Caso especial: Configuración → Mi Perfil
    if ("Configuración".equals(nombre)) {
        for (SideMenuItem child : item.getChildren()) {
            if ("Mi Perfil".equals(child.getText())) {

                // Acción de "Mi Perfil"
                sideMenu.setMenuItemAction("Mi Perfil", e -> {
                    new MiPerfil().setVisible(true);
                    this.dispose();
                });

                // Ocultar si no debe verlo
                boolean visiblePerfil = (rol == 1 || rol == 2 || rol == 3 || rol == 4);
                child.setShown(visiblePerfil);
                child.setEnabled(visiblePerfil);
            }
        }
    }
}

// 🔹 Acciones generales de menú
sideMenu.setMenuItemAction("Inicio", e -> {
    
    if (rol == 1) {
            new InicioAdmin().setVisible(true);
        } else {
            new InicioGene().setVisible(true);
        }
        this.dispose();
});


sideMenu.setMenuItemAction("Productos", e -> {
    new Producto().setVisible(true);
    this.dispose();
});

sideMenu.setMenuItemAction("Proveedores", e -> {
    new Proveedor().setVisible(true);
    this.dispose();
});

sideMenu.setMenuItemAction("Compras", e -> {
    new Compra().setVisible(true);
    this.dispose();
});

sideMenu.setMenuItemAction("Ventas", e -> {
    new Venta().setVisible(true);
    this.dispose();
});

sideMenu.setMenuItemAction("Ayuda", e -> {
    new Ayuda().setVisible(true);
    this.dispose();
});

sideMenu.setMenuItemAction("Salir", e -> {
    new Login().setVisible(true);
    this.dispose();
});

    }
    
    
private void cargarComboProveedores() {
    mapaProveedores.clear();
    cmbProveedor.removeAllItems();

    try {
        ResultSet rsProv = Conexion.consultarTodo("proveedor");
        while (rsProv != null && rsProv.next()) {
            String nombre = rsProv.getString("nombre_comercial").trim();
            int id = rsProv.getInt("id_proveedor");

            mapaProveedores.put(nombre, id);
            cmbProveedor.addItem(nombre); // Solo mostramos el nombre
        }
        if (rsProv != null) rsProv.close();
    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Error al cargar proveedores: " + e.getMessage());
    }
}


private void cargarTiposProducto() {
    mapaTiposProducto.clear();
    cmbTipoProdu.removeAllItems();

    try {
        ResultSet rsTipo = Conexion.consultarTodo("tipo_producto");
        while (rsTipo != null && rsTipo.next()) {
            String nombre = rsTipo.getString("nombre_tipo").trim();
            int id = rsTipo.getInt("id_tipo_producto");

            mapaTiposProducto.put(nombre, id);
            cmbTipoProdu.addItem(nombre); // Solo mostramos el nombre
        }
        if (rsTipo != null) rsTipo.close();
    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Error al cargar tipos de producto: " + e.getMessage());
    }
}


private int obtenerIdProveedorSeleccionado() {
    String nombreSeleccionado = (String) cmbProveedor.getSelectedItem();
    if (nombreSeleccionado == null) return -1;
    return mapaProveedores.getOrDefault(nombreSeleccionado.trim(), -1);
}

private int obtenerIdTipoProductoSeleccionado() {
    String nombreSeleccionado = (String) cmbTipoProdu.getSelectedItem();
    if (nombreSeleccionado == null) return -1;
    return mapaTiposProducto.getOrDefault(nombreSeleccionado.trim(), -1);
}




    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        sideMenu = new menulateral.SideMenuComponent();
        lblFondo = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        txtStock = new javax.swing.JTextField();
        txtPrecio = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txtNombreP = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        txtStockMin = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        txtMarca = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtDescripcion = new javax.swing.JTextArea();
        cmbProveedor = new javax.swing.JComboBox<>();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        cmbTipoProdu = new javax.swing.JComboBox<>();
        btnGuardar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(164, 158, 126));

        sideMenu.setBackgroundColor(new java.awt.Color(228, 255, 212));
        sideMenu.setHoverColor(new java.awt.Color(228, 255, 212));
        sideMenu.setModel(new menulateral.SideMenuModel() {{ addItem(new menulateral.SideMenuItem("Inicio", "C:\\Users\\ayele\\Downloads\\hogar.png", "Ir a Inicio")); addItem(new menulateral.SideMenuItem("Productos", "C:\\Users\\ayele\\Downloads\\abarrotes-tienda.png", "Ir al almacén")); addItem(new menulateral.SideMenuItem("Proveedores", "C:\\Users\\ayele\\Downloads\\gestion-de-la-cadena-de-suministro.png", "Ir a proveedores ")); addItem(new menulateral.SideMenuItem("Compras", "C:\\Users\\ayele\\Downloads\\agregar-producto.png", "Ir a realizar compras")); addItem(new menulateral.SideMenuItem("Ventas", "C:\\Users\\ayele\\Downloads\\carrito-de-compras (1).png", "Ir a realizar ventas ")); addItem(new menulateral.SideMenuItem("Configuración", "C:\\Users\\ayele\\Downloads\\configuracion-del-usuario.png", "Ir a configuración")); menulateral.SideMenuItem item907 = getItem(5); menulateral.SideMenuItem item88 = new menulateral.SideMenuItem("Mi Perfil", "C:\\Users\\ayele\\Downloads\\avatar-de-usuario.png", "Ir a mi perfil"); item907.addChild(item88); addItem(new menulateral.SideMenuItem("Ayuda", "C:\\Users\\ayele\\Downloads\\ayuda.png", "Ayuda")); addItem(new menulateral.SideMenuItem("Salir", "C:\\Users\\ayele\\Downloads\\cerrar sesion (1).png", "Ir a login")); }});

        jLabel1.setFont(new java.awt.Font("Perpetua", 0, 18)); // NOI18N
        jLabel1.setText("AGREGAR PRODUCTO");

        txtStock.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtStockActionPerformed(evt);
            }
        });

        jLabel16.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        jLabel16.setText("Precio");

        jLabel5.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        jLabel5.setText("Nombre");

        jLabel7.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        jLabel7.setText("Stock mínimo");

        jLabel8.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        jLabel8.setText("Marca");

        txtMarca.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtMarcaActionPerformed(evt);
            }
        });

        jLabel9.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        jLabel9.setText("Proveedor");

        jLabel10.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        jLabel10.setText("Descripción");

        txtDescripcion.setColumns(20);
        txtDescripcion.setRows(5);
        jScrollPane1.setViewportView(txtDescripcion);

        cmbProveedor.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cmbProveedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbProveedorActionPerformed(evt);
            }
        });

        jLabel11.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        jLabel11.setText("Tipo producto");

        jLabel12.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        jLabel12.setText("Stock");

        cmbTipoProdu.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        btnGuardar.setBackground(new java.awt.Color(237, 198, 142));
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(sideMenu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(237, 237, 237)
                        .addComponent(lblFondo, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel1)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(56, 56, 56)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(cmbProveedor, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(txtPrecio, javax.swing.GroupLayout.DEFAULT_SIZE, 309, Short.MAX_VALUE)
                                    .addComponent(txtNombreP, javax.swing.GroupLayout.DEFAULT_SIZE, 309, Short.MAX_VALUE)
                                    .addComponent(txtMarca, javax.swing.GroupLayout.DEFAULT_SIZE, 309, Short.MAX_VALUE)
                                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtStockMin, javax.swing.GroupLayout.DEFAULT_SIZE, 309, Short.MAX_VALUE)
                                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 215, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jScrollPane1))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 69, Short.MAX_VALUE)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(txtStock, javax.swing.GroupLayout.DEFAULT_SIZE, 309, Short.MAX_VALUE)
                                        .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(cmbTipoProdu, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                    .addComponent(btnGuardar, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(55, 55, 55))))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(sideMenu, javax.swing.GroupLayout.PREFERRED_SIZE, 730, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblFondo, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(31, 31, 31)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(jLabel12))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtNombreP, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtStock, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(jLabel11))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmbTipoProdu, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtMarca, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jLabel9)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cmbProveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(2, 2, 2)
                        .addComponent(btnGuardar, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel16)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtPrecio, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtStockMin, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel1, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtStockActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtStockActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtStockActionPerformed

    private void txtMarcaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtMarcaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtMarcaActionPerformed

    private void cmbProveedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbProveedorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbProveedorActionPerformed

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
        // TODO add your handling code here:
     try {
        // Obtener datos de los campos
        String nombre = txtNombreP.getText().trim();
        String descripcion = txtDescripcion.getText().trim();
        String marca = txtMarca.getText().trim();
        double precio = Double.parseDouble(txtPrecio.getText().trim());
        int stockMinimo = Integer.parseInt(txtStockMin.getText().trim());
        int stock = Integer.parseInt(txtStock.getText().trim());

        // Validar campos de texto obligatorios y longitud
        if (nombre.isEmpty() || descripcion.isEmpty() || marca.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor, completa todos los campos obligatorios.");
            return;
        }

        if (nombre.length() > 100 || descripcion.length() > 100 || marca.length() > 100) {
            JOptionPane.showMessageDialog(this, "Cada campo de texto debe tener máximo 100 caracteres.");
            return;
        }

        // Validar que no sean solo números
        if (nombre.matches("\\d+") || descripcion.matches("\\d+") || marca.matches("\\d+")) {
            JOptionPane.showMessageDialog(this, "Los campos de texto no pueden ser solo números.");
            return;
        }

        // Validar caracteres permitidos (letras, números, espacios, guiones, puntos y comas)
        String patronValido = "^[a-zA-Z0-9áéíóúÁÉÍÓÚñÑ .,\\-]+$";
        if (!nombre.matches(patronValido) || !descripcion.matches(patronValido) || !marca.matches(patronValido)) {
            JOptionPane.showMessageDialog(this, "Los campos de texto contienen caracteres no permitidos.");
            return;
        }

        // Validar valores numéricos no negativos
        if (precio < 0 || stockMinimo < 0 || stock < 0) {
            JOptionPane.showMessageDialog(this, "Los valores numéricos no pueden ser negativos.");
            return;
        }

        // Validar límite razonable de precio (opcional)
        if (precio > 1000000) {
            JOptionPane.showMessageDialog(this, "El precio es demasiado alto. Verifica el valor.");
            return;
        }

        // Obtener IDs desde los combos usando mapas
        int idProveedor = obtenerIdProveedorSeleccionado();
        int idTipoProducto = obtenerIdTipoProductoSeleccionado();

        if (idProveedor == -1 || idTipoProducto == -1) {
            JOptionPane.showMessageDialog(this, "Por favor, selecciona un proveedor y un tipo de producto válido.");
            return;
        }

        // Verificar si el nombre del producto ya existe
        ResultSet rs = Conexion.buscarPorCampos("producto", new String[]{"nombre"}, new Object[]{nombre});
        if (rs != null && rs.next()) {
            JOptionPane.showMessageDialog(this, "⚠️ El producto con este nombre ya existe. No se pueden duplicar productos.");
            return;
        }

        // Insertar producto usando tu método genérico de Conexion
        boolean exito = Conexion.insertar(
            "producto",
            "nombre, descripcion, marca, id_proveedor, precio, stock_minimo, stock, id_tipo_producto",
            "?, ?, ?, ?, ?, ?, ?, ?",
            nombre, descripcion, marca, idProveedor, precio, stockMinimo, stock, idTipoProducto
        );

        if (exito) {
            JOptionPane.showMessageDialog(this, "✅ Producto guardado correctamente.");
            limpiarCampos();
        } else {
            JOptionPane.showMessageDialog(this, "❌ Error al guardar el producto.");
        }

    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(this, "Por favor, verifica los datos numéricos. Deben ser números válidos.");
    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error inesperado: " + e.getMessage());
    }
    }//GEN-LAST:event_btnGuardarActionPerformed

    private void limpiarCampos() {
    txtNombreP.setText("");
    txtDescripcion.setText("");
    txtMarca.setText("");
    txtPrecio.setText("");
    txtStockMin.setText("");
    txtStock.setText("");
    cmbProveedor.setSelectedIndex(-1);
    cmbTipoProdu.setSelectedIndex(-1);
}

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AgregarProducto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AgregarProducto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AgregarProducto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AgregarProducto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AgregarProducto().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnGuardar;
    private javax.swing.JComboBox<String> cmbProveedor;
    private javax.swing.JComboBox<String> cmbTipoProdu;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblFondo;
    private menulateral.SideMenuComponent sideMenu;
    private javax.swing.JTextArea txtDescripcion;
    private javax.swing.JTextField txtMarca;
    private javax.swing.JTextField txtNombreP;
    private javax.swing.JTextField txtPrecio;
    private javax.swing.JTextField txtStock;
    private javax.swing.JTextField txtStockMin;
    // End of variables declaration//GEN-END:variables
}
