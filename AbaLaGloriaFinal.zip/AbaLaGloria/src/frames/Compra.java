/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package frames;

import clases.Sesion;
import java.awt.Image;
import javax.swing.JOptionPane;
import javax.swing.RowFilter;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import menulateral.SideMenuItem;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;
import paquete.Conexion;
import java.sql.ResultSet;
import javax.swing.ListSelectionModel;

/**
 *
 * @author ayele
 */
public class Compra extends javax.swing.JFrame {

     private TableRowSorter<DefaultTableModel> sorter;
    /**
     * Creates new form Compra
     */
    public Compra() {
       
        initComponents();
         cargarCompras("id_compra", "ASC");
        int rol = Sesion.getRol();

// 🔹 Configurar visibilidad según el rol
for (SideMenuItem item : sideMenu.getModel().getItems()) {

    String nombre = item.getText();

    // Por defecto, todos visibles
    boolean visible = true;

    switch (rol) {
        case 1: // Admin
        case 2: // Gerente
            visible = true; // todos visibles
            break;

        case 3: // Cajero
            visible = nombre.equals("Ventas") ||
                      nombre.equals("Configuración") ||
                      nombre.equals("Ayuda") ||
                      nombre.equals("Salir");
            break;

        case 4: // Almacenista
            visible = nombre.equals("Productos") ||
                      nombre.equals("Configuración") ||
                      nombre.equals("Ayuda") ||
                      nombre.equals("Salir");
            break;
    }

    item.setShown(visible);
    item.setEnabled(visible);

    // 🔹 Caso especial: Configuración → Mi Perfil
    if ("Configuración".equals(nombre)) {
        for (SideMenuItem child : item.getChildren()) {
            if ("Mi Perfil".equals(child.getText())) {

                // Acción de "Mi Perfil"
                sideMenu.setMenuItemAction("Mi Perfil", e -> {
                    new MiPerfil().setVisible(true);
                    this.dispose();
                });

                // Ocultar si no debe verlo
                boolean visiblePerfil = (rol == 1 || rol == 2 || rol == 3 || rol == 4);
                child.setShown(visiblePerfil);
                child.setEnabled(visiblePerfil);
            }
        }
}}
        // 🔹 Acciones generales de menú
sideMenu.setMenuItemAction("Inicio", e -> {
    
    if (rol == 1) {
            new InicioAdmin().setVisible(true);
        } else {
            new InicioGene().setVisible(true);
        }
        this.dispose();
});


sideMenu.setMenuItemAction("Productos", e -> {
    new Producto().setVisible(true);
    this.dispose();
});

sideMenu.setMenuItemAction("Proveedores", e -> {
    new Proveedor().setVisible(true);
    this.dispose();
});

sideMenu.setMenuItemAction("Compras", e -> {
    new Compra().setVisible(true);
    this.dispose();
});

sideMenu.setMenuItemAction("Ventas", e -> {
    new Venta().setVisible(true);
    this.dispose();
});

sideMenu.setMenuItemAction("Ayuda", e -> {
    new Ayuda().setVisible(true);
    this.dispose();
});

sideMenu.setMenuItemAction("Salir", e -> {
    new Login().setVisible(true);
    this.dispose();
});

     DefaultTableModel modelo = (DefaultTableModel) tabCompra.getModel();
sorter = new TableRowSorter<>(modelo);
tabCompra.setRowSorter(sorter);

txtBuscar.getDocument().addDocumentListener(new DocumentListener() {
    @Override
    public void insertUpdate(DocumentEvent e) { filtrar(); }
    @Override
    public void removeUpdate(DocumentEvent e) { filtrar(); }
    @Override
    public void changedUpdate(DocumentEvent e) { filtrar(); }

    private void filtrar() {
        String texto = txtBuscar.getText().trim().toLowerCase();

        if (texto.isEmpty()) {
            sorter.setRowFilter(null);
        } else {
            sorter.setRowFilter(new RowFilter<TableModel, Integer>() {
                @Override
                public boolean include(RowFilter.Entry<? extends TableModel, ? extends Integer> entry) {
                    for (int i = 0; i < entry.getValueCount(); i++) {
                        Object valor = entry.getValue(i);
                        if (valor != null && valor.toString().toLowerCase().contains(texto)) {
                            return true;
                        }
                    }
                    return false;
                }
            });
        }

        // Verificar si hay resultados después de filtrar
        if (tabCompra.getRowCount() == 0 && !texto.isEmpty()) {
            JOptionPane.showMessageDialog(null, "⚠️ Sin resultados para: " + texto, 
                                          "Búsqueda", JOptionPane.INFORMATION_MESSAGE);
        }
    }
});

        configurarOrdenamiento();
        
        ImageIcon iconoOriginal = new ImageIcon(getClass().getResource("/imagenes/anadir-al-carrito.png"));
        Image imagen = iconoOriginal.getImage().getScaledInstance(32, 32, Image.SCALE_SMOOTH);
        ImageIcon iconoRegistrar = new ImageIcon(imagen);
        btnRealizarCompra.setIcon(iconoRegistrar);
        btnRealizarCompra.setText("Agregar Compra");
        btnRealizarCompra.setHorizontalTextPosition(SwingConstants.RIGHT);  // Texto a la derecha del ícono
        btnRealizarCompra.setVerticalTextPosition(SwingConstants.CENTER); 
        
     
        
        ImageIcon iconoB = new ImageIcon(getClass().getResource("/imagenes/ojo.png"));
        Image imagenVer = iconoB.getImage().getScaledInstance(32, 32, Image.SCALE_SMOOTH);
        ImageIcon iconoVer = new ImageIcon(imagenVer);
        btnVerCompra.setIcon(iconoVer);
        btnVerCompra.setText("Ver información de la compra");
        btnVerCompra.setHorizontalTextPosition(SwingConstants.RIGHT);  // Texto a la derecha del ícono
        btnVerCompra.setVerticalTextPosition(SwingConstants.CENTER);
        
        
}

    private void configurarOrdenamiento() {
    
          cmbFiltro.addActionListener(e -> {
    String seleccion = (String) cmbFiltro.getSelectedItem();
    if (seleccion == null || seleccion.equals("Ordenar por")) return;

    switch (seleccion) {
        case "ID: menor-mayor":
            cargarComprasConProductos("id_compra", "ASC");
            break;
        case "ID: mayor-menor":
            cargarComprasConProductos("id_compra", "DESC");
            break;
        case "Nombre: A-Z":
            cargarComprasConProductos("productos", "ASC");
            break;
        case "Nombre: Z-A":
            cargarComprasConProductos("productos", "DESC");
            break;
    }
});
    
}
   
private void cargarComprasConProductos(String columnaOrden, String orden) {
    DefaultTableModel modelo = new DefaultTableModel(new Object[][] {}, 
        new String[] {"ID Compra", "Fecha", "Productos", "Total"}) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false; // tabla solo lectura
        }
    };

    try {
        ResultSet rs = Conexion.obtenerComprasConProductosOrdenadas(columnaOrden, orden);

        while (rs != null && rs.next()) {
            modelo.addRow(new Object[]{
                rs.getInt("id_compra"),
                rs.getString("fecha"),
                rs.getString("productos"),
                String.format("$%.2f", rs.getDouble("total"))
            });
        }

        tabCompra.setModel(modelo);

        // Mantener selección de fila
        tabCompra.setRowSelectionAllowed(true);
        tabCompra.setColumnSelectionAllowed(false);
        tabCompra.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(null, "❌ Error al cargar compras: " + e.getMessage());
    }
}



     private void cargarCompras(String columnaOrden, String orden) {
    // Crear un modelo solo lectura
    DefaultTableModel modelo = new DefaultTableModel(new Object[][] {}, 
        new String[] {"ID Compra", "Fecha", "Productos", "Total"}) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false; // ninguna celda editable
        }
    };

    try {
        ResultSet rsCompras = Conexion.buscarTodosOrdenado("compra", columnaOrden, orden);

        while (rsCompras != null && rsCompras.next()) {
            int idCompra = rsCompras.getInt("id_compra");
            String fecha = rsCompras.getString("fecha");
            double total = rsCompras.getDouble("total");

            // Obtener productos de esta compra
            String[] campos = {"id_compra"};
            Object[] valores = {idCompra};
            ResultSet rsDetalles = Conexion.buscarPorCampos("detalle_compra", campos, valores);

            StringBuilder productos = new StringBuilder();
            while (rsDetalles != null && rsDetalles.next()) {
                int idProducto = rsDetalles.getInt("id_producto");
                int cantidad = rsDetalles.getInt("cantidad");

                ResultSet rsProducto = Conexion.buscarPorId("producto", "id_producto", idProducto);
                if (rsProducto != null && rsProducto.next()) {
                    String nombre = rsProducto.getString("nombre");
                    productos.append(nombre).append(" x").append(cantidad).append(", ");
                }
            }

            if (productos.length() > 0) {
                productos.setLength(productos.length() - 2); // quitar última coma
            }

            modelo.addRow(new Object[]{
                idCompra,
                fecha,
                productos.toString(),
                String.format("$%.2f", total)
            });
        }

        tabCompra.setModel(modelo);

        // Mantener selección de fila y solo lectura
        tabCompra.setRowSelectionAllowed(true);
        tabCompra.setColumnSelectionAllowed(false);
        tabCompra.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(null, "❌ Error al cargar las compras: " + e.getMessage());
    }
}


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        sideMenu = new menulateral.SideMenuComponent();
        cmbFiltro = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        txtBuscar = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabCompra = new javax.swing.JTable();
        btnRealizarCompra = new javax.swing.JButton();
        btnVerCompra = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(110, 143, 133));

        sideMenu.setBackgroundColor(new java.awt.Color(228, 255, 212));
        sideMenu.setHoverColor(new java.awt.Color(228, 255, 212));
        sideMenu.setModel(new menulateral.SideMenuModel() {{ addItem(new menulateral.SideMenuItem("Inicio", "C:\\Users\\ayele\\Downloads\\hogar.png", "Ir a Inicio")); addItem(new menulateral.SideMenuItem("Productos", "C:\\Users\\ayele\\Downloads\\abarrotes-tienda.png", "Ir al almacén")); addItem(new menulateral.SideMenuItem("Proveedores", "C:\\Users\\ayele\\Downloads\\gestion-de-la-cadena-de-suministro.png", "Ir a proveedores ")); addItem(new menulateral.SideMenuItem("Compras", "C:\\Users\\ayele\\Downloads\\agregar-producto.png", "Ir a realizar compras")); addItem(new menulateral.SideMenuItem("Ventas", "C:\\Users\\ayele\\Downloads\\carrito-de-compras (1).png", "Ir a realizar ventas ")); addItem(new menulateral.SideMenuItem("Configuración", "C:\\Users\\ayele\\Downloads\\configuracion-del-usuario.png", "Ir a configuración")); menulateral.SideMenuItem item739 = getItem(5); menulateral.SideMenuItem item2568 = new menulateral.SideMenuItem("Mi Perfil", "C:\\Users\\ayele\\Downloads\\avatar-de-usuario.png", "Ir a mi perfil"); item739.addChild(item2568); addItem(new menulateral.SideMenuItem("Ayuda", "C:\\Users\\ayele\\Downloads\\ayuda.png", "Ayuda")); addItem(new menulateral.SideMenuItem("Salir", "C:\\Users\\ayele\\Downloads\\cerrar sesion (1).png", "Ir a login")); }});

        cmbFiltro.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Ordenar por", "ID: mayor-menor", "ID: menor-mayor", "Nombre: A-Z", "Nombre: Z-A" }));
        cmbFiltro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbFiltroActionPerformed(evt);
            }
        });

        jLabel1.setText("Buscar");

        jLabel2.setFont(new java.awt.Font("Segoe UI Historic", 1, 24)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("COMPRA");

        jScrollPane1.setBackground(new java.awt.Color(235, 231, 167));

        tabCompra.setBackground(new java.awt.Color(235, 231, 167));
        tabCompra.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "id", "Fecha", "Producto", "Monto"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Double.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        tabCompra.setGridColor(new java.awt.Color(122, 100, 72));
        tabCompra.setSelectionBackground(new java.awt.Color(122, 100, 72));
        jScrollPane1.setViewportView(tabCompra);

        btnRealizarCompra.setBackground(new java.awt.Color(237, 198, 142));
        btnRealizarCompra.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRealizarCompraActionPerformed(evt);
            }
        });

        btnVerCompra.setBackground(new java.awt.Color(237, 198, 142));
        btnVerCompra.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVerCompraActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(sideMenu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(193, 193, 193)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(39, 39, 39)
                                .addComponent(cmbFiltro, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(88, 88, 88)
                                .addComponent(btnRealizarCompra, javax.swing.GroupLayout.PREFERRED_SIZE, 259, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(44, 44, 44)
                                .addComponent(btnVerCompra, javax.swing.GroupLayout.PREFERRED_SIZE, 285, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(46, 46, 46)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 702, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addContainerGap(80, Short.MAX_VALUE))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(sideMenu, javax.swing.GroupLayout.DEFAULT_SIZE, 631, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cmbFiltro, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1)
                    .addComponent(txtBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(14, 14, 14)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 380, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnRealizarCompra, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnVerCompra, javax.swing.GroupLayout.DEFAULT_SIZE, 38, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel1, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cmbFiltroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbFiltroActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbFiltroActionPerformed

    private void btnRealizarCompraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRealizarCompraActionPerformed
        // TODO add your handling code here:
        new AgregarCompra().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnRealizarCompraActionPerformed

    private void btnVerCompraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVerCompraActionPerformed
        // TODO add your handling code here:
        int filaSeleccionada = tabCompra.getSelectedRow();

    if (filaSeleccionada != -1) {
        // Obtener el ID del usuario seleccionado (asumiendo que está en la columna 0)
        int idCompra = (int) tabCompra.getValueAt(filaSeleccionada, 0);

        // Abrir la ventana VerUsuario con el ID
        VerCompra ventanaVer = new VerCompra(idCompra);
        ventanaVer.setVisible(true);

        this.dispose(); // Cierra la ventana actual si todo va bien
    } else {
        JOptionPane.showMessageDialog(this, "Por favor selecciona una compra para ver.");
    }
    }//GEN-LAST:event_btnVerCompraActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Compra.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Compra.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Compra.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Compra.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Compra().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnRealizarCompra;
    private javax.swing.JButton btnVerCompra;
    private javax.swing.JComboBox<String> cmbFiltro;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private menulateral.SideMenuComponent sideMenu;
    private javax.swing.JTable tabCompra;
    private javax.swing.JTextField txtBuscar;
    // End of variables declaration//GEN-END:variables
}
