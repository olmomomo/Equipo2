/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package frames;

import clases.Sesion;
import java.awt.Image;
import java.sql.Connection;
import java.util.Collections;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.RowFilter;
import javax.swing.RowSorter;
import javax.swing.SortOrder;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import menulateral.SideMenuItem;
import paquete.Conexion;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.ListSelectionModel;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.TableModel;

/**
 *
 * @author ayele
 */
public class Venta extends javax.swing.JFrame {

    private TableRowSorter<DefaultTableModel> sorter;
    /**
     * Creates new form Venta
     */
    public Venta() {
        initComponents();
        cargarVentas("id_venta", "ASC");
        configurarOrdenamiento();
        ImageIcon icon=new ImageIcon(getClass().getResource("/imagenes/buscar.png"));
        Image imagenEsc=icon.getImage().getScaledInstance(20, 20, Image.SCALE_SMOOTH);
        ImageIcon iconoFin = new ImageIcon(imagenEsc);
        lblBuscar.setIcon(iconoFin);
        
       int rol = Sesion.getRol();

// 🔹 Configurar visibilidad según el rol
for (SideMenuItem item : sideMenu.getModel().getItems()) {

    String nombre = item.getText();

    // Por defecto, todos visibles
    boolean visible = true;

    switch (rol) {
        case 1: // Admin
        case 2: // Gerente
            visible = true; // todos visibles
            break;

        case 3: // Cajero
            visible = nombre.equals("Ventas") ||
                      nombre.equals("Configuración") ||
                      nombre.equals("Ayuda") ||
                      nombre.equals("Salir");
            break;

        case 4: // Almacenista
            visible = nombre.equals("Productos") ||
                      nombre.equals("Configuración") ||
                      nombre.equals("Ayuda") ||
                      nombre.equals("Salir");
            break;
    }

    item.setShown(visible);
    item.setEnabled(visible);

    // 🔹 Caso especial: Configuración → Mi Perfil
    if ("Configuración".equals(nombre)) {
        for (SideMenuItem child : item.getChildren()) {
            if ("Mi Perfil".equals(child.getText())) {

                // Acción de "Mi Perfil"
                sideMenu.setMenuItemAction("Mi Perfil", e -> {
                    new MiPerfil().setVisible(true);
                    this.dispose();
                });

                // Ocultar si no debe verlo
                boolean visiblePerfil = (rol == 1 || rol == 2 || rol == 3 || rol == 4);
                child.setShown(visiblePerfil);
                child.setEnabled(visiblePerfil);
            }
        }
}}
        // 🔹 Acciones generales de menú
sideMenu.setMenuItemAction("Inicio", e -> {
    
    if (rol == 1) {
            new InicioAdmin().setVisible(true);
        } else {
            new InicioGene().setVisible(true);
        }
        this.dispose();
});


sideMenu.setMenuItemAction("Productos", e -> {
    new Producto().setVisible(true);
    this.dispose();
});

sideMenu.setMenuItemAction("Proveedores", e -> {
    new Proveedor().setVisible(true);
    this.dispose();
});

sideMenu.setMenuItemAction("Compras", e -> {
    new Compra().setVisible(true);
    this.dispose();
});

sideMenu.setMenuItemAction("Ventas", e -> {
    new Venta().setVisible(true);
    this.dispose();
});

sideMenu.setMenuItemAction("Ayuda", e -> {
    new Ayuda().setVisible(true);
    this.dispose();
});

sideMenu.setMenuItemAction("Salir", e -> {
    new Login().setVisible(true);
    this.dispose();
});


        ImageIcon iconoOriginal = new ImageIcon(getClass().getResource("/imagenes/anadir-al-carrito.png"));
        Image imagen = iconoOriginal.getImage().getScaledInstance(32, 32, Image.SCALE_SMOOTH);
        ImageIcon iconoRegistrar = new ImageIcon(imagen);
        btnAgregar.setIcon(iconoRegistrar);
        btnAgregar.setText("Agregar Venta");
        btnAgregar.setHorizontalTextPosition(SwingConstants.RIGHT);  // Texto a la derecha del ícono
        btnAgregar.setVerticalTextPosition(SwingConstants.CENTER); 
        
        
        ImageIcon iconoB = new ImageIcon(getClass().getResource("/imagenes/ojo.png"));
        Image imagenVer = iconoB.getImage().getScaledInstance(32, 32, Image.SCALE_SMOOTH);
        ImageIcon iconoVer = new ImageIcon(imagenVer);
        btnVer.setIcon(iconoVer);
        btnVer.setText("Ver información de la venta");
        btnVer.setHorizontalTextPosition(SwingConstants.RIGHT);  // Texto a la derecha del ícono
        btnVer.setVerticalTextPosition(SwingConstants.CENTER); 
        
     DefaultTableModel modelo = (DefaultTableModel) tabVenta.getModel();
sorter = new TableRowSorter<>(modelo);
tabVenta.setRowSorter(sorter);

txtBuscar.getDocument().addDocumentListener(new DocumentListener() {
    @Override
    public void insertUpdate(DocumentEvent e) { filtrar(); }
    @Override
    public void removeUpdate(DocumentEvent e) { filtrar(); }
    @Override
    public void changedUpdate(DocumentEvent e) { filtrar(); }

    private void filtrar() {
        String texto = txtBuscar.getText().trim().toLowerCase();

        if (texto.isEmpty()) {
            sorter.setRowFilter(null);
        } else {
            sorter.setRowFilter(new RowFilter<TableModel, Integer>() {
                @Override
                public boolean include(RowFilter.Entry<? extends TableModel, ? extends Integer> entry) {
                    for (int i = 0; i < entry.getValueCount(); i++) {
                        Object valor = entry.getValue(i);
                        if (valor != null && valor.toString().toLowerCase().contains(texto)) {
                            return true;
                        }
                    }
                    return false;
                }
            });
        }

        // Verificar si hay resultados después de filtrar
        if (tabVenta.getRowCount() == 0 && !texto.isEmpty()) {
            JOptionPane.showMessageDialog(null, "⚠️ Sin resultados para: " + texto, 
                                          "Búsqueda", JOptionPane.INFORMATION_MESSAGE);
        }
    }
});
    }

     private void configurarOrdenamiento() {
    
          cmbFiltro.addActionListener(e -> {
    String seleccion = (String) cmbFiltro.getSelectedItem();
    if (seleccion == null || seleccion.equals("Ordenar por")) return;

    

    switch (seleccion) {
        case "ID: menor-mayor":
            cargarVentasConProductos("id_venta", "ASC");
            break;
        case "ID: mayor-menor":
            cargarVentasConProductos("id_venta", "DESC");
            break;
        case "Nombre: A-Z":
            cargarVentasConProductos("productos", "ASC");
            break;
        case "Nombre: Z-A":
            cargarVentasConProductos("productos", "DESC");
            break;

}
});
    
}
     private void cargarVentasConProductos(String columnaOrden, String orden) {

    // 🔹 Modelo no editable
    DefaultTableModel modelo = new DefaultTableModel(
        new Object[]{"ID Venta", "Fecha", "Productos", "Total"}, 0
    ) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };

    try {
        ResultSet rs = Conexion.obtenerVentasConProductosOrdenadas(columnaOrden, orden);

        while (rs != null && rs.next()) {

            modelo.addRow(new Object[]{
                rs.getInt("id_venta"),
                rs.getString("fecha"),
                rs.getString("productos"),
                String.format("$%.2f", rs.getDouble("total"))
            });
        }

        tabVenta.setModel(modelo);

        // 🔹 Configurar selección de fila
        tabVenta.setRowSelectionAllowed(true);
        tabVenta.setColumnSelectionAllowed(false);
        tabVenta.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(null, "Error al cargar ventas: " + e.getMessage());
    }
}

     private void cargarVentas(String columnaOrden, String orden) {

    // 🔹 Modelo no editable
    DefaultTableModel modelo = new DefaultTableModel(
        new Object[]{"ID Venta", "Fecha", "Productos", "Total"}, 0
    ) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };

    try {
        ResultSet rsCompras = Conexion.buscarTodosOrdenado("venta", columnaOrden, orden);

        while (rsCompras != null && rsCompras.next()) {

            int idVenta = rsCompras.getInt("id_venta");
            String fecha = rsCompras.getString("fecha");
            double total = rsCompras.getDouble("total");

            StringBuilder productos = new StringBuilder();

            ResultSet rsDetalles = Conexion.buscarPorCampos(
                "detalle_venta",
                new String[]{"id_venta"},
                new Object[]{idVenta}
            );

            while (rsDetalles != null && rsDetalles.next()) {

                int idProducto = rsDetalles.getInt("id_producto");
                int cantidad = rsDetalles.getInt("cantidad");

                ResultSet rsProducto = Conexion.buscarPorId("producto", "id_producto", idProducto);

                if (rsProducto != null && rsProducto.next()) {
                    productos.append(rsProducto.getString("nombre"))
                             .append(" x").append(cantidad).append(", ");
                }
            }

            if (productos.length() > 0)
                productos.setLength(productos.length() - 2);

            modelo.addRow(new Object[]{
                idVenta,
                fecha,
                productos.toString(),
                String.format("$%.2f", total)
            });
        }

        tabVenta.setModel(modelo);

        // 🔹 Permitir selección de fila
        tabVenta.setRowSelectionAllowed(true);
        tabVenta.setColumnSelectionAllowed(false);
        tabVenta.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(null, "❌ Error al cargar las compras: " + e.getMessage());
    }
}

     
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabVenta = new javax.swing.JTable();
        btnAgregar = new javax.swing.JButton();
        btnVer = new javax.swing.JButton();
        sideMenu = new menulateral.SideMenuComponent();
        cmbFiltro = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        lblBuscar = new javax.swing.JLabel();
        txtBuscar = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(164, 158, 126));

        tabVenta.setBackground(new java.awt.Color(235, 231, 167));
        tabVenta.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "ID Venta ", "Fecha", "Productos ", "Monto "
            }
        ));
        jScrollPane1.setViewportView(tabVenta);

        btnAgregar.setBackground(new java.awt.Color(237, 198, 142));
        btnAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarActionPerformed(evt);
            }
        });

        btnVer.setBackground(new java.awt.Color(237, 198, 142));
        btnVer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVerActionPerformed(evt);
            }
        });

        sideMenu.setBackgroundColor(new java.awt.Color(228, 255, 212));
        sideMenu.setHoverColor(new java.awt.Color(228, 255, 212));
        sideMenu.setModel(new menulateral.SideMenuModel() {{ addItem(new menulateral.SideMenuItem("Inicio", "C:\\Users\\ayele\\Downloads\\hogar.png", "Ir a Inicio")); addItem(new menulateral.SideMenuItem("Productos", "C:\\Users\\ayele\\Downloads\\abarrotes-tienda.png", "Ir al almacén")); addItem(new menulateral.SideMenuItem("Proveedores", "C:\\Users\\ayele\\Downloads\\gestion-de-la-cadena-de-suministro.png", "Ir a proveedores ")); addItem(new menulateral.SideMenuItem("Compras", "C:\\Users\\ayele\\Downloads\\agregar-producto.png", "Ir a realizar compras")); addItem(new menulateral.SideMenuItem("Ventas", "C:\\Users\\ayele\\Downloads\\carrito-de-compras (1).png", "Ir a realizar ventas ")); addItem(new menulateral.SideMenuItem("Configuración", "C:\\Users\\ayele\\Downloads\\configuracion-del-usuario.png", "Ir a configuración")); menulateral.SideMenuItem item4063 = getItem(5); menulateral.SideMenuItem item9706 = new menulateral.SideMenuItem("Mi Perfil", "C:\\Users\\ayele\\Downloads\\avatar-de-usuario.png", "Ir a mi perfil"); item4063.addChild(item9706); addItem(new menulateral.SideMenuItem("Ayuda", "C:\\Users\\ayele\\Downloads\\ayuda.png", "Ayuda")); addItem(new menulateral.SideMenuItem("Salir", "C:\\Users\\ayele\\Downloads\\cerrar sesion (1).png", "Ir a login")); }});

        cmbFiltro.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Ordenar por:", "Nombre: A-Z", "Nombre: Z-A", "ID: menor-mayor", "ID: mayor-menor" }));
        cmbFiltro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbFiltroActionPerformed(evt);
            }
        });

        jLabel2.setText("Filtrar por:");

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Ventas");

        txtBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtBuscarActionPerformed(evt);
            }
        });
        txtBuscar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtBuscarKeyReleased(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(sideMenu, javax.swing.GroupLayout.DEFAULT_SIZE, 275, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(287, 287, 287)
                        .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(9, 9, 9)
                        .addComponent(jScrollPane1)
                        .addContainerGap())
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(74, 74, 74)
                        .addComponent(btnAgregar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(106, 106, 106)
                        .addComponent(btnVer, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(110, 110, 110))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(117, 117, 117)
                        .addComponent(txtBuscar, javax.swing.GroupLayout.DEFAULT_SIZE, 122, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, 113, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cmbFiltro, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(213, 213, 213))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(sideMenu, javax.swing.GroupLayout.DEFAULT_SIZE, 660, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cmbFiltro)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(lblBuscar, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtBuscar, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addGap(53, 53, 53)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 418, Short.MAX_VALUE)
                .addGap(59, 59, 59)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnAgregar, javax.swing.GroupLayout.DEFAULT_SIZE, 45, Short.MAX_VALUE)
                    .addComponent(btnVer, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel1, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarActionPerformed
        // TODO add your handling code here:
        new AgregarVenta().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnAgregarActionPerformed

    private void btnVerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVerActionPerformed
        // TODO add your handling code here:
        int filaSeleccionada = tabVenta.getSelectedRow();

        if (filaSeleccionada != -1) {
            // Obtener el ID del usuario seleccionado (asumiendo que está en la columna 0)
            int idProducto = (int) tabVenta.getValueAt(filaSeleccionada, 0);

            // Abrir la ventana VerUsuario con el ID
            VerVenta ventanaVer = new VerVenta(idProducto);
            ventanaVer.setVisible(true);

            this.dispose(); // Cierra la ventana actual si todo va bien
        } else {
            JOptionPane.showMessageDialog(this, "Por favor selecciona una venta para ver.");
        }
    }//GEN-LAST:event_btnVerActionPerformed

    private void cmbFiltroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbFiltroActionPerformed
        // TODO add your handling code here:
        configurarOrdenamiento();
    }//GEN-LAST:event_cmbFiltroActionPerformed

    private void txtBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtBuscarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtBuscarActionPerformed

    private void txtBuscarKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtBuscarKeyReleased
        // TODO add your handling code here:
        String texto = txtBuscar.getText().trim();

        if (texto.length() == 0) {
            sorter.setRowFilter(null); // Mostrar todo
        } else {
            sorter.setRowFilter(RowFilter.regexFilter("(?i)" + texto)); // Filtrado con ignore case
        }
    }//GEN-LAST:event_txtBuscarKeyReleased

   

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Venta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Venta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Venta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Venta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Venta().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAgregar;
    private javax.swing.JButton btnVer;
    private javax.swing.JComboBox<String> cmbFiltro;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblBuscar;
    private menulateral.SideMenuComponent sideMenu;
    private javax.swing.JTable tabVenta;
    private javax.swing.JTextField txtBuscar;
    // End of variables declaration//GEN-END:variables
}
