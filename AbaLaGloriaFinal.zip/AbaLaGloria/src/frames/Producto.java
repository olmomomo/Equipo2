/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package frames;

import clases.Sesion;
import java.awt.Image;
import java.sql.Connection;
import java.util.Collections;
import javax.swing.ImageIcon;
import javax.swing.JTable;
import javax.swing.RowFilter;
import javax.swing.RowSorter;
import javax.swing.SortOrder;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import menulateral.SideMenuItem;
import paquete.Conexion;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.TableModel;

/**
 *
 * @author ayele
 */
public class Producto extends javax.swing.JFrame {

    
    private TableRowSorter<DefaultTableModel> sorter;
    /**
     * Creates new form Producto
     */
    public Producto() {
        initComponents();
        cargarProductosEnTabla(tabProducto);
        ImageIcon icon=new ImageIcon(getClass().getResource("/imagenes/buscar.png"));
        Image imagenEsc=icon.getImage().getScaledInstance(20, 20, Image.SCALE_SMOOTH);
        ImageIcon iconoFin = new ImageIcon(imagenEsc);
        lblBuscar.setIcon(iconoFin);
        
        // Obtener rol actual
int rol = Sesion.getRol();

// 🔹 Configurar visibilidad según el rol
for (SideMenuItem item : sideMenu.getModel().getItems()) {

    String nombre = item.getText();

    // Por defecto, todos visibles
    boolean visible = true;

    switch (rol) {
        case 1: // Admin
        case 2: // Gerente
            visible = true; // todos visibles
            break;

        case 3: // Cajero
            visible = nombre.equals("Ventas") ||
                      nombre.equals("Configuración") ||
                      nombre.equals("Ayuda") ||
                      nombre.equals("Salir");
            break;

        case 4: // Almacenista
            visible = nombre.equals("Productos") ||
                      nombre.equals("Configuración") ||
                      nombre.equals("Ayuda") ||
                      nombre.equals("Salir");
            break;
    }

    item.setShown(visible);
    item.setEnabled(visible);

    // 🔹 Caso especial: Configuración → Mi Perfil
    if ("Configuración".equals(nombre)) {
        for (SideMenuItem child : item.getChildren()) {
            if ("Mi Perfil".equals(child.getText())) {

                // Acción de "Mi Perfil"
                sideMenu.setMenuItemAction("Mi Perfil", e -> {
                    new MiPerfil().setVisible(true);
                    this.dispose();
                });

                // Ocultar si no debe verlo
                boolean visiblePerfil = (rol == 1 || rol == 2 || rol == 3 || rol == 4);
                child.setShown(visiblePerfil);
                child.setEnabled(visiblePerfil);
            }
        }
}}
        // 🔹 Acciones generales de menú
sideMenu.setMenuItemAction("Inicio", e -> {
    
   if (rol == 1) {
            new InicioAdmin().setVisible(true);
        } else {
            new InicioGene().setVisible(true);
        }
        this.dispose();
});


sideMenu.setMenuItemAction("Productos", e -> {
    new Producto().setVisible(true);
    this.dispose();
});

sideMenu.setMenuItemAction("Proveedores", e -> {
    new Proveedor().setVisible(true);
    this.dispose();
});

sideMenu.setMenuItemAction("Compras", e -> {
    new Compra().setVisible(true);
    this.dispose();
});

sideMenu.setMenuItemAction("Ventas", e -> {
    new Venta().setVisible(true);
    this.dispose();
});

sideMenu.setMenuItemAction("Ayuda", e -> {
    new Ayuda().setVisible(true);
    this.dispose();
});

sideMenu.setMenuItemAction("Salir", e -> {
    new Login().setVisible(true);
    this.dispose();
});

        ImageIcon iconoOriginal = new ImageIcon(getClass().getResource("/imagenes/agregar-producto (1).png"));
        Image imagen = iconoOriginal.getImage().getScaledInstance(32, 32, Image.SCALE_SMOOTH);
        ImageIcon iconoRegistrar = new ImageIcon(imagen);
        btnAgregar.setIcon(iconoRegistrar);
        btnAgregar.setText("Agregar Producto");
        btnAgregar.setHorizontalTextPosition(SwingConstants.RIGHT);  // Texto a la derecha del ícono
        btnAgregar.setVerticalTextPosition(SwingConstants.CENTER); 
        
        ImageIcon iconoA = new ImageIcon(getClass().getResource("/imagenes/producto (1).png"));
        Image imagenAct = iconoA.getImage().getScaledInstance(32, 32, Image.SCALE_SMOOTH);
        ImageIcon iconoEditar = new ImageIcon(imagenAct);
        btnSuspender.setIcon(iconoEditar);
        btnSuspender.setText("Suspender Producto");
        btnSuspender.setHorizontalTextPosition(SwingConstants.RIGHT);  // Texto a la derecha del ícono
        btnSuspender.setVerticalTextPosition(SwingConstants.CENTER); 
        
        ImageIcon iconoB = new ImageIcon(getClass().getResource("/imagenes/ojo.png"));
        Image imagenVer = iconoB.getImage().getScaledInstance(32, 32, Image.SCALE_SMOOTH);
        ImageIcon iconoVer = new ImageIcon(imagenVer);
        btnVer.setIcon(iconoVer);
        btnVer.setText("Ver información del producto");
        btnVer.setHorizontalTextPosition(SwingConstants.RIGHT);  // Texto a la derecha del ícono
        btnVer.setVerticalTextPosition(SwingConstants.CENTER); 
        
          DefaultTableModel modelo = (DefaultTableModel) tabProducto.getModel();
sorter = new TableRowSorter<>(modelo);
tabProducto.setRowSorter(sorter);


txtBuscar.getDocument().addDocumentListener(new DocumentListener() {
    @Override
    public void insertUpdate(DocumentEvent e) { filtrar(); }
    @Override
    public void removeUpdate(DocumentEvent e) { filtrar(); }
    @Override
    public void changedUpdate(DocumentEvent e) { filtrar(); }

    private void filtrar() {
        String texto = txtBuscar.getText().trim().toLowerCase();

        if (texto.isEmpty()) {
            sorter.setRowFilter(null);
        } else {
            sorter.setRowFilter(new RowFilter<TableModel, Integer>() {
                @Override
                public boolean include(RowFilter.Entry<? extends TableModel, ? extends Integer> entry) {
                    for (int i = 0; i < entry.getValueCount(); i++) {
                        Object valor = entry.getValue(i);
                        if (valor != null && valor.toString().toLowerCase().contains(texto)) {
                            return true;
                        }
                    }
                    return false;
                }
            });
        }

        // Verificar si hay resultados después de filtrar
        if (tabProducto.getRowCount() == 0 && !texto.isEmpty()) {
            JOptionPane.showMessageDialog(null, "⚠️ Sin resultados para: " + texto, 
                                          "Búsqueda", JOptionPane.INFORMATION_MESSAGE);
        }
    }
});


    }

 private void aplicarFiltroYOrdenProductos() {
    String opcion = (String) cmbFiltro.getSelectedItem();

    if (sorter == null) return;

    switch (opcion) {
        case "Nombre: A-Z":
            sorter.setSortKeys(Collections.singletonList(
                new RowSorter.SortKey(1, SortOrder.ASCENDING) // columna 1 = Nombre
            ));
            sorter.sort();
            break;

        case "Nombre: Z-A":
            sorter.setSortKeys(Collections.singletonList(
                new RowSorter.SortKey(1, SortOrder.DESCENDING) // columna 1 = Nombre
            ));
            sorter.sort();
            break;

        case "Id producto ASC":
            sorter.setSortKeys(Collections.singletonList(
                new RowSorter.SortKey(0, SortOrder.ASCENDING) // columna 0 = ID
            ));
            sorter.sort();
            break;

        case "Id producto DESC":
            sorter.setSortKeys(Collections.singletonList(
                new RowSorter.SortKey(0, SortOrder.DESCENDING) // columna 0 = ID
            ));
            sorter.sort();
            break;

        case "Precio ASC":
            sorter.setSortKeys(Collections.singletonList(
                new RowSorter.SortKey(6, SortOrder.ASCENDING) // columna 6 = Precio
            ));
            sorter.sort();
            break;

        case "Precio DESC":
            sorter.setSortKeys(Collections.singletonList(
                new RowSorter.SortKey(6, SortOrder.DESCENDING) // columna 6 = Precio
            ));
            sorter.sort();
            break;

        default:
            sorter.setSortKeys(null);
            break;
    }
}





    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        sideMenu = new menulateral.SideMenuComponent();
        cmbFiltro = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        lblBuscar = new javax.swing.JLabel();
        txtBuscar = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabProducto = new javax.swing.JTable();
        btnAgregar = new javax.swing.JButton();
        btnVer = new javax.swing.JButton();
        btnSuspender = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(110, 143, 133));

        sideMenu.setBackgroundColor(new java.awt.Color(228, 255, 212));
        sideMenu.setHoverColor(new java.awt.Color(228, 255, 212));
        sideMenu.setModel(new menulateral.SideMenuModel() {{ addItem(new menulateral.SideMenuItem("Inicio", "C:\\Users\\ayele\\Downloads\\hogar.png", "Ir a Inicio")); addItem(new menulateral.SideMenuItem("Productos", "C:\\Users\\ayele\\Downloads\\abarrotes-tienda.png", "Ir al almacén")); addItem(new menulateral.SideMenuItem("Proveedores", "C:\\Users\\ayele\\Downloads\\gestion-de-la-cadena-de-suministro.png", "Ir a proveedores ")); addItem(new menulateral.SideMenuItem("Compras", "C:\\Users\\ayele\\Downloads\\agregar-producto.png", "Ir a realizar compras")); addItem(new menulateral.SideMenuItem("Ventas", "C:\\Users\\ayele\\Downloads\\carrito-de-compras (1).png", "Ir a realizar ventas ")); addItem(new menulateral.SideMenuItem("Configuración", "C:\\Users\\ayele\\Downloads\\configuracion-del-usuario.png", "Ir a configuración")); menulateral.SideMenuItem item6274 = getItem(5); menulateral.SideMenuItem item6068 = new menulateral.SideMenuItem("Mi Perfil", "C:\\Users\\ayele\\Downloads\\avatar-de-usuario.png", "Ir a mi perfil"); item6274.addChild(item6068); addItem(new menulateral.SideMenuItem("Ayuda", "C:\\Users\\ayele\\Downloads\\ayuda.png", "Ayuda")); addItem(new menulateral.SideMenuItem("Salir", "C:\\Users\\ayele\\Downloads\\cerrar sesion (1).png", "Ir a login")); }});

        cmbFiltro.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Nombre: A-Z", "Nombre: Z-A", "Id producto ASC", "Id producto DESC", "Precio ASC", "Precio DESC" }));
        cmbFiltro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbFiltroActionPerformed(evt);
            }
        });

        jLabel2.setText("Filtrar por:");

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Productos");

        txtBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtBuscarActionPerformed(evt);
            }
        });
        txtBuscar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtBuscarKeyReleased(evt);
            }
        });

        tabProducto.setBackground(new java.awt.Color(228, 255, 212));
        tabProducto.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "ID Producto ", "Nombre", "Descripción ", "Proveedor", "Stock", "Stock mínimo", "Precio", "Estatus"
            }
        ));
        jScrollPane1.setViewportView(tabProducto);

        btnAgregar.setBackground(new java.awt.Color(237, 198, 142));
        btnAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarActionPerformed(evt);
            }
        });

        btnVer.setBackground(new java.awt.Color(237, 198, 142));
        btnVer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVerActionPerformed(evt);
            }
        });

        btnSuspender.setBackground(new java.awt.Color(237, 198, 142));
        btnSuspender.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSuspenderActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(sideMenu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(287, 287, 287)
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 281, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(117, 117, 117)
                                .addComponent(txtBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 281, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lblBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(cmbFiltro, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(44, 44, 44)
                        .addComponent(btnAgregar, javax.swing.GroupLayout.PREFERRED_SIZE, 254, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(56, 56, 56)
                        .addComponent(btnVer, javax.swing.GroupLayout.PREFERRED_SIZE, 236, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(43, 43, 43)
                        .addComponent(btnSuspender, javax.swing.GroupLayout.PREFERRED_SIZE, 227, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(32, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(9, 9, 9)
                        .addComponent(jScrollPane1)
                        .addContainerGap())))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(sideMenu, javax.swing.GroupLayout.PREFERRED_SIZE, 730, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2)
                    .addComponent(cmbFiltro, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(53, 53, 53)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(59, 59, 59)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnVer, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnAgregar, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnSuspender, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

     public void cargarProductosEnTabla(JTable tablaProductos) {

    // 🔹 Crear un modelo NO editable
    DefaultTableModel modelo = new DefaultTableModel(
        new Object[]{"ID", "Nombre", "Descripción", "Proveedor", "Stock", "Stock Mínimo", "Precio", "Estatus"}, 0
    ) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false; // Evita ediciones
        }
    };

    try {
        ResultSet rsProductos = Conexion.consultarTodo("producto");

        while (rsProductos != null && rsProductos.next()) {

            int idProducto = rsProductos.getInt("id_producto");
            String nombre = rsProductos.getString("nombre");
            String descripcion = rsProductos.getString("descripcion");

            int idProveedor = rsProductos.getInt("id_proveedor");
            String nombreProveedor = "DESCONOCIDO";

            // 🔹 Obtener nombre del proveedor
            ResultSet rsProveedor = Conexion.buscarPorId("proveedor", "id_proveedor", idProveedor);
            if (rsProveedor != null && rsProveedor.next()) {
                nombreProveedor = rsProveedor.getString("nombre_comercial");
            }
            if (rsProveedor != null) rsProveedor.close();

            int stock = rsProductos.getInt("stock");
            int stockMinimo = rsProductos.getInt("stock_minimo");
            double precio = rsProductos.getDouble("precio");
            int estatusInt = rsProductos.getInt("estatus");
            String estatus = (estatusInt == 1) ? "ACTIVO" : "INACTIVO";

            modelo.addRow(new Object[]{idProducto, nombre, descripcion, nombreProveedor, stock, stockMinimo, precio, estatus});
        }

        if (rsProductos != null) rsProductos.close();

    } catch (SQLException e) {
        System.err.println("Error al cargar productos: " + e.getMessage());
    }

    // 🔹 Asignar el modelo NO editable
    tablaProductos.setModel(modelo);

    // 🔹 Configurar sorter
    sorter = new TableRowSorter<>(modelo);
    tablaProductos.setRowSorter(sorter);

    // 🔹 Permitir seleccionar una fila (pero no editar)
    tablaProductos.setRowSelectionAllowed(true);
    tablaProductos.setColumnSelectionAllowed(false);
    tablaProductos.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
}



    private void cmbFiltroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbFiltroActionPerformed
        // TODO add your handling code here:
        aplicarFiltroYOrdenProductos();
    }//GEN-LAST:event_cmbFiltroActionPerformed

    private void txtBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtBuscarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtBuscarActionPerformed

    private void txtBuscarKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtBuscarKeyReleased
        // TODO add your handling code here:
        String texto = txtBuscar.getText().trim();

        if (texto.length() == 0) {
            sorter.setRowFilter(null); // Mostrar todo
        } else {
            sorter.setRowFilter(RowFilter.regexFilter("(?i)" + texto)); // Filtrado con ignore case
        }
    }//GEN-LAST:event_txtBuscarKeyReleased

    private void btnAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarActionPerformed
        // TODO add your handling code here:
        new AgregarProducto().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnAgregarActionPerformed

    private void btnVerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVerActionPerformed
        // TODO add your handling code here:
        int filaSeleccionada = tabProducto.getSelectedRow();

    if (filaSeleccionada != -1) {
        // Obtener el ID del usuario seleccionado (asumiendo que está en la columna 0)
        int idProducto = (int) tabProducto.getValueAt(filaSeleccionada, 0);

        // Abrir la ventana VerUsuario con el ID
        VerInfoProducto ventanaVer = new VerInfoProducto(idProducto);
        ventanaVer.setVisible(true);

        this.dispose(); // Cierra la ventana actual si todo va bien
    } else {
        JOptionPane.showMessageDialog(this, "Por favor selecciona un producto para ver.");
    }
    }//GEN-LAST:event_btnVerActionPerformed

    private void btnSuspenderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSuspenderActionPerformed
        // TODO add your handling code here:
        // Verifica si hay una fila seleccionada
    int fila = tabProducto.getSelectedRow();
    if (fila == -1) {
        JOptionPane.showMessageDialog(this, "⚠️ Selecciona un producto primero.");
        return;
    }

    // Se asume que la columna 0 es el ID del producto
    int idProducto = (int) tabProducto.getValueAt(fila, 0);
    // Y que la columna 8 o similar (ajusta según tu tabla) muestra "ACTIVO"/"SUSPENDIDO"
    String estadoActual = tabProducto.getValueAt(fila, 7).toString().trim(); 

    System.out.println("Estado leído en tabla (columna 7): '" + estadoActual + "'");

    // Si el producto está activo, lo suspendemos (1 → 0), si está suspendido, lo activamos (0 → 1)
    int nuevoEstado = estadoActual.equalsIgnoreCase("ACTIVO") ? 0 : 1;
    String mensajeConfirmacion = estadoActual.equalsIgnoreCase("ACTIVO")
            ? "¿Deseas suspender este producto?"
            : "El producto está suspendido. ¿Deseas activarlo de nuevo?";

    int respuesta = JOptionPane.showConfirmDialog(this, mensajeConfirmacion, "Confirmar acción", JOptionPane.YES_NO_OPTION);
    if (respuesta == JOptionPane.YES_OPTION) {
        // Llamada al método actualizar (misma estructura que en usuarios)
        boolean actualizado = Conexion.actualizar(
            "producto",
            "estatus = ?",
            "id_producto = ?",
            nuevoEstado,
            idProducto
        );

        if (actualizado) {
            String mensajeExito = (nuevoEstado == 0) ? "🟠 Producto suspendido." : "🟢 Producto activado.";
            JOptionPane.showMessageDialog(this, mensajeExito);
            cargarProductosEnTabla(tabProducto); // refresca la tabla
        } else {
            JOptionPane.showMessageDialog(this, "❌ No se pudo actualizar el estado del producto.");
        }
    }
    }//GEN-LAST:event_btnSuspenderActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Producto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Producto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Producto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Producto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Producto().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAgregar;
    private javax.swing.JButton btnSuspender;
    private javax.swing.JButton btnVer;
    private javax.swing.JComboBox<String> cmbFiltro;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblBuscar;
    private menulateral.SideMenuComponent sideMenu;
    private javax.swing.JTable tabProducto;
    private javax.swing.JTextField txtBuscar;
    // End of variables declaration//GEN-END:variables
}
