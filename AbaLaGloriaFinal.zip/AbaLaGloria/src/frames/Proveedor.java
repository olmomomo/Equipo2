/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package frames;

import clases.Sesion;
import java.awt.Image;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collections;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.RowFilter;
import javax.swing.RowSorter;
import javax.swing.SortOrder;
import javax.swing.SwingConstants;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import menulateral.SideMenuItem;
import paquete.Conexion;

/**
 *
 * @author ayele
 */
public class Proveedor extends javax.swing.JFrame {

     private TableRowSorter<DefaultTableModel> sorter;
    /**
     * Creates new form Proveedor
     */
    public Proveedor() {
        initComponents();
        int rol = Sesion.getRol();
        cargarProveedorEnTabla(tabProv);
        ImageIcon icon=new ImageIcon(getClass().getResource("/imagenes/buscar.png"));
        Image imagenEsc=icon.getImage().getScaledInstance(20, 20, Image.SCALE_SMOOTH);
        ImageIcon iconoFin = new ImageIcon(imagenEsc);
        lblBuscar.setIcon(iconoFin);

// 🔹 Configurar visibilidad según el rol
for (SideMenuItem item : sideMenu.getModel().getItems()) {

    String nombre = item.getText();

    // Por defecto, todos visibles
    boolean visible = true;

    switch (rol) {
        case 1: // Admin
        case 2: // Gerente
            visible = true; // todos visibles
            break;

        case 3: // Cajero
            visible = nombre.equals("Ventas") ||
                      nombre.equals("Configuración") ||
                      nombre.equals("Ayuda") ||
                      nombre.equals("Salir");
            break;

        case 4: // Almacenista
            visible = nombre.equals("Productos") ||
                      nombre.equals("Configuración") ||
                      nombre.equals("Ayuda") ||
                      nombre.equals("Salir");
            break;
    }

    item.setShown(visible);
    item.setEnabled(visible);

    // 🔹 Caso especial: Configuración → Mi Perfil
    if ("Configuración".equals(nombre)) {
        for (SideMenuItem child : item.getChildren()) {
            if ("Mi Perfil".equals(child.getText())) {

                // Acción de "Mi Perfil"
                sideMenu.setMenuItemAction("Mi Perfil", e -> {
                    new MiPerfil().setVisible(true);
                    this.dispose();
                });

                // Ocultar si no debe verlo
                boolean visiblePerfil = (rol == 1 || rol == 2 || rol == 3 || rol == 4);
                child.setShown(visiblePerfil);
                child.setEnabled(visiblePerfil);
            }
        }
}}
        // 🔹 Acciones generales de menú
sideMenu.setMenuItemAction("Inicio", e -> {
    
    if (rol == 1) {
            new InicioAdmin().setVisible(true);
        } else {
            new InicioGene().setVisible(true);
        }
        this.dispose();
});


sideMenu.setMenuItemAction("Productos", e -> {
    new Producto().setVisible(true);
    this.dispose();
});

sideMenu.setMenuItemAction("Proveedores", e -> {
    new Proveedor().setVisible(true);
    this.dispose();
});

sideMenu.setMenuItemAction("Compras", e -> {
    new Compra().setVisible(true);
    this.dispose();
});

sideMenu.setMenuItemAction("Ventas", e -> {
    new Venta().setVisible(true);
    this.dispose();
});

sideMenu.setMenuItemAction("Ayuda", e -> {
    new Ayuda().setVisible(true);
    this.dispose();
});

sideMenu.setMenuItemAction("Salir", e -> {
    new Login().setVisible(true);
    this.dispose();
});

ImageIcon iconoA = new ImageIcon(getClass().getResource("/imagenes/suspendido.png"));
        Image imagenAct = iconoA.getImage().getScaledInstance(32, 32, Image.SCALE_SMOOTH);
        ImageIcon iconoEditar = new ImageIcon(imagenAct);
        btnSusPro.setIcon(iconoEditar);
        btnSusPro.setText("Suspender Proveedor");
        btnSusPro.setHorizontalTextPosition(SwingConstants.RIGHT);  // Texto a la derecha del ícono
        btnSusPro.setVerticalTextPosition(SwingConstants.CENTER); 
        
        ImageIcon iconoB = new ImageIcon(getClass().getResource("/imagenes/vista.png"));
        Image imagenVer = iconoB.getImage().getScaledInstance(32, 32, Image.SCALE_SMOOTH);
        ImageIcon iconoVer = new ImageIcon(imagenVer);
        btnVerInfoP.setIcon(iconoVer);
        btnVerInfoP.setText("Ver información del proveedor");
        btnVerInfoP.setHorizontalTextPosition(SwingConstants.RIGHT);  // Texto a la derecha del ícono
        btnVerInfoP.setVerticalTextPosition(SwingConstants.CENTER); 
        
        ImageIcon iconoC = new ImageIcon(getClass().getResource("/imagenes/agregar.png"));
        Image imagenAgregar = iconoC.getImage().getScaledInstance(32, 32, Image.SCALE_SMOOTH);
        ImageIcon iconoAgregar = new ImageIcon(imagenAgregar);
        btnAgrPro.setIcon(iconoAgregar);
        btnAgrPro.setText("Agregar proveedor");
        btnAgrPro.setHorizontalTextPosition(SwingConstants.RIGHT);  // Texto a la derecha del ícono
        btnAgrPro.setVerticalTextPosition(SwingConstants.CENTER); 

   DefaultTableModel modelo = (DefaultTableModel) tabProv.getModel();
sorter = new TableRowSorter<>(modelo);
tabProv.setRowSorter(sorter);

txtBuscar.getDocument().addDocumentListener(new DocumentListener() {
    @Override
    public void insertUpdate(DocumentEvent e) { filtrar(); }
    @Override
    public void removeUpdate(DocumentEvent e) { filtrar(); }
    @Override
    public void changedUpdate(DocumentEvent e) { filtrar(); }

    private void filtrar() {
        String texto = txtBuscar.getText().trim().toLowerCase();

        if (texto.isEmpty()) {
            sorter.setRowFilter(null);
        } else {
            sorter.setRowFilter(new RowFilter<TableModel, Integer>() {
                @Override
                public boolean include(RowFilter.Entry<? extends TableModel, ? extends Integer> entry) {
                    for (int i = 0; i < entry.getValueCount(); i++) {
                        Object valor = entry.getValue(i);
                        if (valor != null && valor.toString().toLowerCase().contains(texto)) {
                            return true;
                        }
                    }
                    return false;
                }
            });
        }

        // Verificar si hay resultados después de filtrar
        if (tabProv.getRowCount() == 0 && !texto.isEmpty()) {
            JOptionPane.showMessageDialog(null, "⚠️ Sin resultados para: " + texto, 
                                          "Búsqueda", JOptionPane.INFORMATION_MESSAGE);
        }
    }
});
}
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblBuscarPro = new javax.swing.JPanel();
        txtBuscar = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        cmbFiltro = new javax.swing.JComboBox<>();
        jScrollPane2 = new javax.swing.JScrollPane();
        tabProv = new javax.swing.JTable();
        jLabel3 = new javax.swing.JLabel();
        btnAgrPro = new javax.swing.JButton();
        btnSusPro = new javax.swing.JButton();
        btnVerInfoP = new javax.swing.JButton();
        sideMenu = new menulateral.SideMenuComponent();
        jLabel2 = new javax.swing.JLabel();
        lblBuscar = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        lblBuscarPro.setBackground(new java.awt.Color(110, 143, 133));

        txtBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtBuscarActionPerformed(evt);
            }
        });
        txtBuscar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtBuscarKeyReleased(evt);
            }
        });

        jLabel1.setText("Filtrar por:");

        cmbFiltro.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Nombre A-Z", "Nombre: Z-A", "Estado", " " }));
        cmbFiltro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbFiltroActionPerformed(evt);
            }
        });

        tabProv.setBackground(new java.awt.Color(235, 231, 167));
        tabProv.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "id Proveedor", "RFC", "Nombre Comercial", "Telefono", "Correo", "Banco", "Estado"
            }
        ));
        jScrollPane2.setViewportView(tabProv);

        btnAgrPro.setBackground(new java.awt.Color(237, 198, 142));
        btnAgrPro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgrProActionPerformed(evt);
            }
        });

        btnSusPro.setBackground(new java.awt.Color(237, 198, 142));
        btnSusPro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSusProActionPerformed(evt);
            }
        });

        btnVerInfoP.setBackground(new java.awt.Color(237, 198, 142));
        btnVerInfoP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVerInfoPActionPerformed(evt);
            }
        });

        sideMenu.setBackgroundColor(new java.awt.Color(228, 255, 212));
        sideMenu.setHoverColor(new java.awt.Color(228, 255, 212));
        sideMenu.setModel(new menulateral.SideMenuModel() {{ addItem(new menulateral.SideMenuItem("Inicio", "C:\\Users\\ayele\\Downloads\\hogar.png", "Ir a Inicio")); addItem(new menulateral.SideMenuItem("Productos", "C:\\Users\\ayele\\Downloads\\abarrotes-tienda.png", "Ir al almacén")); addItem(new menulateral.SideMenuItem("Proveedores", "C:\\Users\\ayele\\Downloads\\gestion-de-la-cadena-de-suministro.png", "Ir a proveedores ")); addItem(new menulateral.SideMenuItem("Compras", "C:\\Users\\ayele\\Downloads\\agregar-producto.png", "Ir a realizar compras")); addItem(new menulateral.SideMenuItem("Ventas", "C:\\Users\\ayele\\Downloads\\carrito-de-compras (1).png", "Ir a realizar ventas ")); addItem(new menulateral.SideMenuItem("Configuración", "C:\\Users\\ayele\\Downloads\\configuracion-del-usuario.png", "Ir a configuración")); menulateral.SideMenuItem item6731 = getItem(5); menulateral.SideMenuItem item3585 = new menulateral.SideMenuItem("Mi Perfil", "C:\\Users\\ayele\\Downloads\\avatar-de-usuario.png", "Ir a mi perfil"); item6731.addChild(item3585); addItem(new menulateral.SideMenuItem("Ayuda", "C:\\Users\\ayele\\Downloads\\ayuda.png", "Ayuda")); addItem(new menulateral.SideMenuItem("Salir", "C:\\Users\\ayele\\Downloads\\cerrar sesion (1).png", "Ir a login")); }});

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Proveedores");

        javax.swing.GroupLayout lblBuscarProLayout = new javax.swing.GroupLayout(lblBuscarPro);
        lblBuscarPro.setLayout(lblBuscarProLayout);
        lblBuscarProLayout.setHorizontalGroup(
            lblBuscarProLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, lblBuscarProLayout.createSequentialGroup()
                .addComponent(sideMenu, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(127, 127, 127)
                .addGroup(lblBuscarProLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(lblBuscarProLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 681, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(lblBuscarProLayout.createSequentialGroup()
                            .addComponent(btnAgrPro, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(64, 64, 64)
                            .addComponent(btnVerInfoP, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnSusPro, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(lblBuscarProLayout.createSequentialGroup()
                        .addGroup(lblBuscarProLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(lblBuscarProLayout.createSequentialGroup()
                                .addGap(169, 169, 169)
                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 281, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(lblBuscarProLayout.createSequentialGroup()
                                .addComponent(txtBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 286, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(lblBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(lblBuscarProLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(cmbFiltro, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(90, Short.MAX_VALUE))
        );
        lblBuscarProLayout.setVerticalGroup(
            lblBuscarProLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, lblBuscarProLayout.createSequentialGroup()
                .addGroup(lblBuscarProLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(lblBuscarProLayout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnSusPro, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(lblBuscarProLayout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(lblBuscarProLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(lblBuscarProLayout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(lblBuscarProLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(txtBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(cmbFiltro, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(lblBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 315, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 77, Short.MAX_VALUE)
                        .addGroup(lblBuscarProLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnAgrPro, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnVerInfoP, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(77, 77, 77))
            .addComponent(sideMenu, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        getContentPane().add(lblBuscarPro, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtBuscarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtBuscarActionPerformed

    private void txtBuscarKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtBuscarKeyReleased
        // TODO add your handling code here:
     
    }//GEN-LAST:event_txtBuscarKeyReleased

 
public void cargarProveedorEnTabla(JTable tablaProveedor) {
    // Crear un modelo solo lectura
    DefaultTableModel modelo = new DefaultTableModel(
        new Object[]{"ID", "RFC", "Nombre Comercial", "Teléfono", "Correo", "Banco", "Estado"}, 0
    ) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false; // Ninguna celda editable
        }
    };

    try {
        ResultSet rsProveedor = Conexion.consultarTodo("proveedor");

        while (rsProveedor != null && rsProveedor.next()) {
            int idPro = rsProveedor.getInt("id_proveedor");
            String rfc = rsProveedor.getString("rfc");
            String nombre = rsProveedor.getString("nombre_comercial");
            String tel = rsProveedor.getString("telefono");
            String correo = rsProveedor.getString("correo");
            String banco = rsProveedor.getString("banco");
            int estadoInt = rsProveedor.getInt("estatus");
            String estado = (estadoInt == 1) ? "ACTIVO" : "INACTIVO";

            Object[] fila = {idPro, rfc, nombre, tel, correo, banco, estado};
            modelo.addRow(fila);
        }

        if (rsProveedor != null) rsProveedor.close();

    } catch (SQLException e) {
        System.err.println("Error al cargar proveedores: " + e.getMessage());
    }

    tablaProveedor.setModel(modelo);

    // 🔹 Configurar selección de filas
    tablaProveedor.setRowSelectionAllowed(true);
    tablaProveedor.setColumnSelectionAllowed(false);
    tablaProveedor.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

    // 🔹 Asignar sorter (ordenamiento de columnas)
    TableRowSorter<TableModel> sorter = new TableRowSorter<>(modelo);
    tablaProveedor.setRowSorter(sorter);
}

    
    private void cmbFiltroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbFiltroActionPerformed
        // TODO add your handling code here:
        aplicarFiltroYOrden();
    }//GEN-LAST:event_cmbFiltroActionPerformed

     private void aplicarFiltroYOrden() {
    String opcion = (String) cmbFiltro.getSelectedItem();

    if (sorter == null) return;

    switch (opcion) {
        case "Nombre: A-Z":
            sorter.setSortKeys(Collections.singletonList(
                new RowSorter.SortKey(2, SortOrder.ASCENDING) // columna 2 = Nombre
            ));
            sorter.sort();
            break;

        case "Nombre: Z-A":
            sorter.setSortKeys(Collections.singletonList(
                new RowSorter.SortKey(2, SortOrder.DESCENDING)
            ));
            sorter.sort();
            break;


        case "Estado":
            sorter.setSortKeys(Collections.singletonList(
                new RowSorter.SortKey(6, SortOrder.ASCENDING) // columna 6 = Estado
            ));
            sorter.sort();
            break;

        default:
            sorter.setSortKeys(null);
            break;
    }
}
    private void btnAgrProActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgrProActionPerformed
        // TODO add your handling code here:
        new AgregarProveedor().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnAgrProActionPerformed

    private void btnSusProActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSusProActionPerformed
        // TODO add your handling code here:
        int fila = tabProv.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(this, "Selecciona un Proveedor primero.");
            return;
        }

        int idProveedor = (int) tabProv.getValueAt(fila, 0); // Columna 0 = id
        String estadoActual = tabProv.getValueAt(fila, 6).toString(); // Columna 3 = ACTIVO/INACTIVO
        System.out.println("Estado leído en tabla (columna 6): '" + estadoActual + "'");

        int nuevoEstado = estadoActual.equalsIgnoreCase("ACTIVO") ? 0 : 1;
        String mensajeConfirmacion = estadoActual.equalsIgnoreCase("ACTIVO")
        ? "¿Deseas suspender al proveedor?"
        : "El Proveedor está suspendido. ¿Deseas activarlo de nuevo?";

        int respuesta = JOptionPane.showConfirmDialog(this, mensajeConfirmacion, "Confirmar", JOptionPane.YES_NO_OPTION);

        if (respuesta == JOptionPane.YES_OPTION) {
            boolean actualizado = Conexion.actualizar(
                "proveedor",
                "estatus = ?",
                "id_proveedor = ?",
                nuevoEstado,
                idProveedor
            );

            if (actualizado) {
                String mensajeExito = (nuevoEstado == 0) ? "Proveedor suspendido." : "Proveedor activado.";
                JOptionPane.showMessageDialog(this, mensajeExito);

                // Refrescar tabla
                cargarProveedorEnTabla(tabProv);
            } else {
                JOptionPane.showMessageDialog(this, "No se pudo actualizar el estado.");
            }
        }
    }//GEN-LAST:event_btnSusProActionPerformed

    private void btnVerInfoPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVerInfoPActionPerformed
        // TODO add your handling code here:
     int filaSeleccionada = tabProv.getSelectedRow();

    if (filaSeleccionada != -1) {
        // Obtener el ID del usuario seleccionado (asumiendo que está en la columna 0)
        int idProveedor = (int) tabProv.getValueAt(filaSeleccionada, 0);

        // Abrir la ventana VerUsuario con el ID
        VerProveedor ventanaVer = new VerProveedor(idProveedor);
        ventanaVer.setVisible(true);

        this.dispose(); // Cierra la ventana actual si todo va bien
    } else {
        JOptionPane.showMessageDialog(this, "Por favor selecciona un proveedor para ver.");
    }
    }//GEN-LAST:event_btnVerInfoPActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Proveedor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Proveedor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Proveedor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Proveedor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Proveedor().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAgrPro;
    private javax.swing.JButton btnSusPro;
    private javax.swing.JButton btnVerInfoP;
    private javax.swing.JComboBox<String> cmbFiltro;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lblBuscar;
    private javax.swing.JPanel lblBuscarPro;
    private menulateral.SideMenuComponent sideMenu;
    private javax.swing.JTable tabProv;
    private javax.swing.JTextField txtBuscar;
    // End of variables declaration//GEN-END:variables
}
